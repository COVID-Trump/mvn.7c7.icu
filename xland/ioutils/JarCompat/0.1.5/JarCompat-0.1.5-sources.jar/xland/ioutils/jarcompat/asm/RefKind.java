package xland.ioutils.jarcompat.asm;

/**
 * Kind of a symbolic reference extracted from a program class file.
 */
public enum RefKind {
    CLASS,
    FIELD,
    METHOD
}
