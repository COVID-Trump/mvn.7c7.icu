package xland.ioutils.jarcompat.resolve;

/**
 * Tri-state answer for questions that may be undecidable because part of the classpath is not
 * provided (external black boxes).
 */
public enum Certainty {
    /** Provably true. */
    YES,
    /** Provably false. */
    NO,
    /** Undecidable: the hierarchy leaves the analysed inputs. */
    UNKNOWN;

    public boolean isYes() {
        return this == YES;
    }

    /** {@code true} unless the answer is a provable NO. */
    public boolean notProvablyNo() {
        return this != NO;
    }
}
