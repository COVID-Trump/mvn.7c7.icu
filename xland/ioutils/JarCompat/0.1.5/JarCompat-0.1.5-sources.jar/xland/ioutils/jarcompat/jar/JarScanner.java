package xland.ioutils.jarcompat.jar;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.jspecify.annotations.Nullable;

import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.JarCompatException;
import xland.ioutils.jarcompat.model.ClassOrigin;
import xland.ioutils.jarcompat.model.ScanIssue;

/**
 * Reads JAR archives <em>as data</em>: no class is ever loaded, linked or executed.
 *
 * <p>Responsibilities:</p>
 * <ul>
 *   <li>enumerate {@code .class} entries (root, fat-JAR prefixed and multi-release aware);</li>
 *   <li>select, for each class name, the highest {@code META-INF/versions/N} variant with
 *       {@code N <= runtime version} (falling back to the root entry);</li>
 *   <li>detect and skip nested JARs, reporting a {@code WARN};</li>
 *   <li>report duplicated class names, sealed packages and multi-release overrides;</li>
 *   <li>hand every selected class file to a {@link ClassFileHandler}.</li>
 * </ul>
 */
public final class JarScanner {

    private static final String VERSIONS_PREFIX = "META-INF/versions/";
    private static final String[] FAT_CLASS_PREFIXES = {"BOOT-INF/classes/", "WEB-INF/classes/"};

    private JarScanner() {
    }

    /** Receives one selected class file. */
    @FunctionalInterface
    public interface ClassFileHandler {
        void accept(String internalName, byte[] bytes, ClassOrigin origin) throws IOException;
    }

    /** Describes one scan. */
    public record Request(List<Path> jars, String side, int runtimeVersion) {
    }

    /** Outcome of one scan. */
    public static final class ScanReport {
        private final List<String> jars = new ArrayList<>();
        private final Map<String, ManifestInfo> manifests = new LinkedHashMap<>();
        private final Map<String, List<String>> sealedPackages = new LinkedHashMap<>();
        private final List<ScanIssue> issues = new ArrayList<>();
        private int classCount;
        private @Nullable String mainClass;

        /** JAR file names, in classpath order. */
        public List<String> jars() {
            return List.copyOf(jars);
        }

        /** Per-JAR manifest information. */
        public Map<String, ManifestInfo> manifests() {
            return Map.copyOf(manifests);
        }

        /** Sealed package (dotted) to the JARs that declare it sealed, in classpath order. */
        public Map<String, List<String>> sealedPackages() {
            return Map.copyOf(sealedPackages);
        }

        /** Issues discovered while scanning. */
        public List<ScanIssue> issues() {
            return List.copyOf(issues);
        }

        public int classCount() {
            return classCount;
        }

        /** First {@code Main-Class} found, dotted name, or {@code null}. */
        public @Nullable String mainClass() {
            return mainClass;
        }
    }

    /**
     * Scans the given JARs in classpath order and feeds every selected class file to {@code handler}.
     * The order of {@code jars} is never changed: it defines which duplicate class wins.
     */
    public static ScanReport scan(Request request, ClassFileHandler handler) {
        ScanReport report = new ScanReport();
        for (Path jar : request.jars()) {
            scanOne(jar, request, handler, report);
        }
        return report;
    }

    private static void scanOne(Path jarPath, Request request, ClassFileHandler handler, ScanReport report) {
        if (!Files.isRegularFile(jarPath)) {
            throw new JarCompatException("输入 JAR 不存在或不是普通文件: " + jarPath);
        }
        String jarName = jarPath.getFileName().toString();
        report.jars.add(jarName);
        try (ZipFile zip = new ZipFile(jarPath.toFile())) {
            ManifestInfo manifest = readManifest(zip, jarName, report);
            report.manifests.put(jarName, manifest);
            if (manifest.sealed()) {
                report.sealedPackages.computeIfAbsent("*", k -> new ArrayList<>()).add(jarName);
            }
            for (String pkg : manifest.sealedPackages()) {
                report.sealedPackages.computeIfAbsent(pkg, k -> new ArrayList<>()).add(jarName);
            }
            if (manifest.mainClass() != null && report.mainClass == null) {
                report.mainClass = manifest.mainClass();
            }

            Map<String, Candidate> selected = selectClasses(zip, jarName, manifest, request.runtimeVersion(), report);
            for (Candidate candidate : selected.values()) {
                ZipEntry entry = zip.getEntry(candidate.entry());
                if (entry == null) {
                    continue;
                }
                byte[] bytes;
                try (InputStream in = zip.getInputStream(entry)) {
                    bytes = in.readAllBytes();
                }
                ClassOrigin origin = new ClassOrigin(request.side(), jarName, jarPath.toString(), candidate.entry());
                handler.accept(candidate.className(), bytes, origin);
                report.classCount++;
            }
        } catch (ZipException e) {
            throw new JarCompatException("无法读取 JAR (不是有效的 ZIP/JAR 文件): " + jarPath, e);
        } catch (IOException e) {
            throw new JarCompatException("读取 JAR 失败: " + jarPath, e);
        }
    }

    private static ManifestInfo readManifest(ZipFile zip, String jarName, ScanReport report) throws IOException {
        ZipEntry entry = zip.getEntry("META-INF/MANIFEST.MF");
        if (entry == null) {
            return ManifestInfo.absent();
        }
        try (InputStream in = zip.getInputStream(entry)) {
            Manifest manifest = new Manifest(in);
            Attributes main = manifest.getMainAttributes();
            String mainClass = main.getValue(Attributes.Name.MAIN_CLASS);
            String multiRelease = main.getValue("Multi-Release");
            boolean sealed = Boolean.parseBoolean(String.valueOf(main.getValue("Sealed")).trim());
            Set<String> sealedPackages = new LinkedHashSet<>();
            for (Map.Entry<String, Attributes> section : manifest.getEntries().entrySet()) {
                String value = section.getValue().getValue("Sealed");
                if (value != null && Boolean.parseBoolean(value.trim())) {
                    String name = section.getKey();
                    if (name.endsWith("/")) {
                        name = name.substring(0, name.length() - 1);
                    }
                    sealedPackages.add(name.replace('/', '.'));
                }
            }
            if (multiRelease != null && !Boolean.parseBoolean(multiRelease.trim())) {
                report.issues.add(ScanIssue.info(IncompatibilityKind.MULTI_RELEASE,
                        jarName + ": 声明了 Multi-Release: " + multiRelease + "，META-INF/versions 下的类将被忽略。", jarName));
            }
            return ManifestInfo.of(mainClass, multiRelease, sealed, sealedPackages);
        }
    }

    private record Candidate(String className, String entry, int version) {
    }

    private static Map<String, Candidate> selectClasses(ZipFile zip, String jarName, ManifestInfo manifest,
                                                        int runtimeVersion, ScanReport report) {
        Map<String, Candidate> best = new LinkedHashMap<>();
        int nestedJars = 0;
        List<String> nestedExamples = new ArrayList<>();
        int fatPrefixed = 0;
        boolean sawVersioned = false;
        boolean sawIgnoredVersioned = false;

        Enumeration<? extends ZipEntry> entries = zip.entries();
        while (entries.hasMoreElements()) {
            ZipEntry entry = entries.nextElement();
            if (entry.isDirectory()) {
                continue;
            }
            String rawName = entry.getName();
            String lower = rawName.toLowerCase(Locale.ROOT);
            if (lower.endsWith(".jar")) {
                nestedJars++;
                if (nestedExamples.size() < 3) {
                    nestedExamples.add(rawName);
                }
                continue;
            }
            if (!lower.endsWith(".class")) {
                continue;
            }
            String name = rawName;
            for (String prefix : FAT_CLASS_PREFIXES) {
                if (name.startsWith(prefix)) {
                    name = name.substring(prefix.length());
                    fatPrefixed++;
                    break;
                }
            }
            if (name.equals("module-info.class") || name.endsWith("/module-info.class")) {
                continue;
            }
            int version = 0;
            String effective = name;
            if (name.startsWith(VERSIONS_PREFIX)) {
                int slash = name.indexOf('/', VERSIONS_PREFIX.length());
                if (slash < 0) {
                    continue;
                }
                String versionPart = name.substring(VERSIONS_PREFIX.length(), slash);
                int parsed;
                try {
                    parsed = Integer.parseInt(versionPart);
                } catch (NumberFormatException e) {
                    continue;
                }
                sawVersioned = true;
                if (!manifest.multiRelease()) {
                    sawIgnoredVersioned = true;
                    continue;
                }
                if (parsed > runtimeVersion || parsed < 9) {
                    continue;
                }
                version = parsed;
                effective = name.substring(slash + 1);
                if (effective.equals("module-info.class")) {
                    continue;
                }
            }
            String className = effective.substring(0, effective.length() - ".class".length());
            Candidate candidate = new Candidate(className, rawName, version);
            @Nullable Candidate previous = best.get(className);
            if (previous == null || candidate.version() > previous.version()) {
                best.put(className, candidate);
            }
        }

        for (Candidate candidate : best.values()) {
            if (candidate.version() > 0) {
                report.issues.add(ScanIssue.info(IncompatibilityKind.MULTI_RELEASE,
                        jarName + ": " + candidate.className().replace('/', '.')
                                + " 采用 META-INF/versions/" + candidate.version() + " 版本 (运行版本 "
                                + runtimeVersion + ")。", jarName));
            }
        }
        if (nestedJars > 0) {
            report.issues.add(ScanIssue.warn(IncompatibilityKind.NESTED_JAR,
                    jarName + ": 检测到 " + nestedJars + " 个 nested JAR（例如 " + String.join(", ", nestedExamples)
                            + "），已跳过。已知限制：不展开 fat JAR / nested JAR，其中的类不参与分析。", jarName));
        }
        if (fatPrefixed > 0) {
            report.issues.add(ScanIssue.warn(IncompatibilityKind.NESTED_JAR,
                    jarName + ": 检测到 fat JAR 布局 (BOOT-INF/classes 或 WEB-INF/classes)，已按运行时布局剥离前缀处理 "
                            + fatPrefixed + " 个类。", jarName));
        }
        if (sawVersioned && sawIgnoredVersioned && !manifest.multiRelease()) {
            report.issues.add(ScanIssue.info(IncompatibilityKind.MULTI_RELEASE,
                    jarName + ": 存在 META-INF/versions 条目但清单未声明 Multi-Release: true，已忽略这些条目。", jarName));
        }
        return best;
    }
}
