/**
 * Hand written command line parsing: option values, usage text and exit codes.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable} — the optional {@code
 * --entry} and {@code --output} options of {@link xland.ioutils.jarcompat.cli.CliOptions}.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.cli;

import org.jspecify.annotations.NullMarked;
