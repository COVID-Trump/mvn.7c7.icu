package xland.ioutils.jarcompat.model;

/**
 * Class-file access flags and their textual rendering. The constants are the raw JVM class-file
 * bits (JVMS §4.1/§4.5/§4.6); this package deliberately does not depend on any bytecode library.
 */
public final class Access {
    public static final int PUBLIC = 0x0001;
    public static final int PRIVATE = 0x0002;
    public static final int PROTECTED = 0x0004;
    public static final int STATIC = 0x0008;
    public static final int FINAL = 0x0010;
    public static final int SYNCHRONIZED = 0x0020;
    public static final int VOLATILE = 0x0040;
    public static final int BRIDGE = 0x0040;
    public static final int TRANSIENT = 0x0080;
    public static final int VARARGS = 0x0080;
    public static final int NATIVE = 0x0100;
    public static final int INTERFACE = 0x0200;
    public static final int ABSTRACT = 0x0400;
    public static final int STRICT = 0x0800;
    public static final int SYNTHETIC = 0x1000;
    public static final int ANNOTATION = 0x2000;
    public static final int ENUM = 0x4000;
    public static final int MODULE = 0x8000;
    public static final int RECORD = 0x10000;

    private Access() {
    }

    public static boolean isPublic(int access) {
        return (access & PUBLIC) != 0;
    }

    public static boolean isPrivate(int access) {
        return (access & PRIVATE) != 0;
    }

    public static boolean isProtected(int access) {
        return (access & PROTECTED) != 0;
    }

    /** No public/protected/private flag: package-private (default) access. */
    public static boolean isPackagePrivate(int access) {
        return (access & (PUBLIC | PROTECTED | PRIVATE)) == 0;
    }

    public static boolean isStatic(int access) {
        return (access & STATIC) != 0;
    }

    public static boolean isFinal(int access) {
        return (access & FINAL) != 0;
    }

    public static boolean isAbstract(int access) {
        return (access & ABSTRACT) != 0;
    }

    public static boolean isInterface(int access) {
        return (access & INTERFACE) != 0;
    }

    public static boolean isAnnotation(int access) {
        return (access & ANNOTATION) != 0;
    }

    public static boolean isEnum(int access) {
        return (access & ENUM) != 0;
    }

    public static boolean isRecord(int access) {
        return (access & RECORD) != 0;
    }

    public static boolean isSynthetic(int access) {
        return (access & SYNTHETIC) != 0;
    }

    public static boolean isBridge(int access) {
        return (access & BRIDGE) != 0;
    }

    public static boolean isNative(int access) {
        return (access & NATIVE) != 0;
    }

    public static boolean isVarargs(int access) {
        return (access & VARARGS) != 0;
    }

    public static boolean isVolatile(int access) {
        return (access & VOLATILE) != 0;
    }

    /** {@code public}, {@code protected}, {@code private} or {@code package-private}. */
    public static String visibility(int access) {
        if (isPublic(access)) {
            return "public";
        }
        if (isProtected(access)) {
            return "protected";
        }
        if (isPrivate(access)) {
            return "private";
        }
        return "package-private";
    }

    /** Renders the relevant flags of a class, e.g. {@code public final class}. */
    public static String describeClass(int access) {
        StringBuilder sb = new StringBuilder(visibility(access));
        if (isAnnotation(access)) {
            sb.append(" @interface");
        } else if (isInterface(access)) {
            sb.append(" interface");
        } else if (isEnum(access)) {
            sb.append(" enum");
        } else {
            sb.append(" class");
        }
        if (isAbstract(access) && !isInterface(access)) {
            sb.append(" (abstract)");
        }
        if (isFinal(access)) {
            sb.append(" (final)");
        }
        if (isSynthetic(access)) {
            sb.append(" (synthetic)");
        }
        return sb.toString();
    }

    /** Renders the relevant flags of a field, e.g. {@code public static final}. */
    public static String describeField(int access) {
        StringBuilder sb = new StringBuilder(visibility(access));
        if (isStatic(access)) {
            sb.append(" static");
        }
        if (isFinal(access)) {
            sb.append(" final");
        }
        if (isVolatile(access)) {
            sb.append(" volatile");
        }
        if ((access & TRANSIENT) != 0) {
            sb.append(" transient");
        }
        return sb.toString();
    }

    /** Renders the relevant flags of a method, e.g. {@code public static}. */
    public static String describeMethod(int access) {
        StringBuilder sb = new StringBuilder(visibility(access));
        if (isStatic(access)) {
            sb.append(" static");
        }
        if (isAbstract(access)) {
            sb.append(" abstract");
        }
        if (isFinal(access)) {
            sb.append(" final");
        }
        if (isNative(access)) {
            sb.append(" native");
        }
        if (isBridge(access)) {
            sb.append(" bridge");
        }
        if (isSynthetic(access)) {
            sb.append(" synthetic");
        }
        return sb.toString();
    }
}
