package xland.ioutils.jarcompat.api;

/**
 * Classification of a single finding. The kind is stable API: callers may switch on it to build
 * their own reports or to gate builds.
 */
public enum IncompatibilityKind {

    /** A class referenced by the program (or by lib-a) is absent from lib-b. */
    MISSING_CLASS,

    /** The superclass / superinterface relation of a program type became invalid in lib-b. */
    SUPERCLASS_INCOMPATIBLE,
    /**
     * A subtype relation between two library types that the program relies on (typically a cast to
     * an interface the class no longer implements) no longer holds in lib-b.
     */
    HIERARCHY_RELATION_LOST,
    /** A method referenced by the program is not resolvable in lib-b. */
    MISSING_METHOD,
    /** A field referenced by the program is not resolvable in lib-b. */
    MISSING_FIELD,
    /**
     * A member still exists by name, but with a different (erased) descriptor: the JVM resolves
     * members by name <em>and</em> descriptor, so this behaves exactly like a missing member.
     */
    DESCRIPTOR_CHANGED,
    /** The member changed between static and instance while the program's opcode expects the other. */
    MEMBER_STATIC_MISMATCH,
    /** A type changed between class and interface. */
    CLASS_KIND_CHANGED,
    /** The member (or class) exists but is no longer accessible from the program. */
    ACCESS_REDUCED,
    /** A member that was extensible/implementable in lib-a is final/private in lib-b. */
    FINAL_VIOLATION,
    /** A concrete program type no longer implements all abstract methods required by lib-b. */
    ABSTRACT_METHOD_MISSING,
    /** The reference could not even be resolved against lib-a; nothing can be concluded. */
    UNRESOLVED_IN_A,
    /** Same class name defined by several JARs of the same side. */
    DUPLICATE_CLASS,
    /** A sealed package of lib-a is split across several lib-b JARs ({@code SecurityException} risk). */
    SEALED_PACKAGE_SPLIT,
    /** A nested (fat) JAR was detected and skipped. */
    NESTED_JAR,
    /** Multi-release JAR metadata was detected / applied. */
    MULTI_RELEASE,
    /** The reference is not reachable from the entry point: potential, not definite, breakage. */
    UNREACHABLE_REFERENCE,
    /** No entry point was available, so reachability could not be computed. */
    REACHABILITY_UNKNOWN,
    /** Dynamic linking mechanisms (reflection, ServiceLoader, proxies, JNI) are out of scope. */
    DYNAMIC_CALLS_NOT_COVERED,
    /** A referenced class lives outside program/lib-a/lib-b and was treated as an opaque black box. */
    EXTERNAL_DEPENDENCY_UNCHECKED,
    /** Informational note. */
    NOTE
}
