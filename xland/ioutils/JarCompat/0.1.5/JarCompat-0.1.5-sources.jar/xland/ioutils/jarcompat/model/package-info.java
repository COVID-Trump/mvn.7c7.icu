/**
 * The ASM-free domain model: class-file symbols ({@code ClassInfo}, {@code FieldInfo}, {@code
 * MethodInfo}), logical repositories ({@code Repo}) and descriptor helpers.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable} — {@code java/lang/Object}
 * has no superclass, a class need not be a nest host, and an issue need not name a symbol.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.model;

import org.jspecify.annotations.NullMarked;
