/**
 * Public, ASM-free API of JarCompat: the {@link xland.ioutils.jarcompat.api.JarCompat} entry point,
 * the immutable {@link xland.ioutils.jarcompat.api.CheckRequest} / {@link
 * xland.ioutils.jarcompat.api.CheckReport} value objects and the enums describing findings.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable} — most notably {@link
 * xland.ioutils.jarcompat.api.CheckRequest#entryClass()} and the optional halves of an {@link
 * xland.ioutils.jarcompat.api.Incompatibility}.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.api;

import org.jspecify.annotations.NullMarked;
