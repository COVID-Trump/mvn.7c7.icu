package xland.ioutils.jarcompat.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jspecify.annotations.Nullable;

/**
 * Immutable symbol-table entry for one class: shape flags, hierarchy, fields and methods.
 * Built by {@code xland.ioutils.jarcompat.asm.ClassInfoReader}.
 */
public final class ClassInfo {

    private final String name;
    private final @Nullable String superName;
    private final List<String> interfaces;
    private final int access;
    private final ClassOrigin origin;
    private final Map<String, FieldInfo> fields;
    private final Map<String, List<FieldInfo>> fieldsByName;
    private final Map<String, MethodInfo> methods;
    private final Map<String, List<MethodInfo>> methodsByName;
    private final @Nullable String nestHost;
    private final Set<String> nestMembers;
    private final List<String> permittedSubclasses;

    private ClassInfo(Builder b) {
        this.name = b.name;
        this.superName = b.superName;
        this.interfaces = List.copyOf(b.interfaces);
        this.access = b.access;
        this.origin = b.origin;
        this.fields = Map.copyOf(b.fields);
        this.methods = Map.copyOf(b.methods);
        this.nestHost = b.nestHost;
        this.nestMembers = Set.copyOf(b.nestMembers);
        this.permittedSubclasses = List.copyOf(b.permittedSubclasses);
        Map<String, List<FieldInfo>> byName = new LinkedHashMap<>();
        for (FieldInfo f : b.fields.values()) {
            byName.computeIfAbsent(f.name(), _ -> new ArrayList<>()).add(f);
        }
        byName.replaceAll((k, v) -> List.copyOf(v));
        this.fieldsByName = Map.copyOf(byName);
        Map<String, List<MethodInfo>> methodsByName = new LinkedHashMap<>();
        for (MethodInfo m : b.methods.values()) {
            methodsByName.computeIfAbsent(m.name(), _ -> new ArrayList<>()).add(m);
        }
        methodsByName.replaceAll((k, v) -> List.copyOf(v));
        this.methodsByName = Map.copyOf(methodsByName);
    }

    public static Builder builder(String name, int access, ClassOrigin origin) {
        return new Builder(name, access, origin);
    }

    /** Internal (slash separated) class name. */
    public String name() {
        return name;
    }

    /** Internal name of the superclass; {@code null} only for {@code java/lang/Object}. */
    public @Nullable String superName() {
        return superName;
    }

    /** Internal names of the directly implemented interfaces. */
    public List<String> interfaces() {
        return interfaces;
    }

    public int access() {
        return access;
    }

    /** Which side / JAR / entry this class was read from. */
    public ClassOrigin origin() {
        return origin;
    }

    /** Simple name of the originating JAR, for reports. */
    public String originJar() {
        return origin == null ? "?" : origin.jar();
    }

    /** Internal name of the nest host, or {@code null}. */
    public @Nullable String nestHost() {
        return nestHost;
    }

    /** Internal names of the nest members, or empty. */
    public Set<String> nestMembers() {
        return nestMembers;
    }

    /** Internal names listed in the {@code PermittedSubclasses} attribute, or empty. */
    public List<String> permittedSubclasses() {
        return permittedSubclasses;
    }

    /** Whether this class or interface is sealed ({@code PermittedSubclasses} is present). */
    public boolean isSealed() {
        return !permittedSubclasses.isEmpty();
    }

    /** Whether {@code subclass} is explicitly permitted to extend/implement this sealed type. */
    public boolean permits(String subclass) {
        return permittedSubclasses.contains(subclass);
    }

    /** All declared fields. */
    public Collection<FieldInfo> fields() {
        return fields.values();
    }

    /** All declared methods. */
    public Collection<MethodInfo> methods() {
        return methods.values();
    }

    /** Exact field lookup by name and erased descriptor. */
    public FieldInfo findField(String name, String descriptor) {
        return fields.get(name + ':' + descriptor);
    }

    /** All fields with the given name, whatever their descriptor. */
    public List<FieldInfo> fieldsNamed(String name) {
        return fieldsByName.getOrDefault(name, List.of());
    }

    /** Exact method lookup by name and erased descriptor. */
    public MethodInfo findMethod(String name, String descriptor) {
        return methods.get(name + descriptor);
    }

    /** All methods with the given name, whatever their descriptor. */
    public List<MethodInfo> methodsNamed(String name) {
        return methodsByName.getOrDefault(name, List.of());
    }

    public boolean isInterface() {
        return Access.isInterface(access);
    }

    public boolean isAnnotation() {
        return Access.isAnnotation(access);
    }

    public boolean isEnum() {
        return Access.isEnum(access);
    }

    public boolean isRecord() {
        return Access.isRecord(access);
    }

    public boolean isAbstract() {
        return Access.isAbstract(access);
    }

    public boolean isFinal() {
        return Access.isFinal(access);
    }

    public boolean isPublic() {
        return Access.isPublic(access);
    }

    public boolean isPrivate() {
        return Access.isPrivate(access);
    }

    public boolean isProtected() {
        return Access.isProtected(access);
    }

    public boolean isPackagePrivate() {
        return Access.isPackagePrivate(access);
    }

    public boolean isSynthetic() {
        return Access.isSynthetic(access);
    }

    /** Package in dotted form, {@code ""} for the default package. */
    public String packageName() {
        return Descriptors.packageOf(name).replace('/', '.');
    }

    /** Binary name, e.g. {@code lib.a.Service}. */
    public String dottedName() {
        return Descriptors.toDotted(name);
    }

    /** {@code true} when {@code other} is {@code java/lang/Object}. */
    public boolean isObject() {
        return "java/lang/Object".equals(name);
    }

    /** Short declaration used in reports, e.g. {@code public class lib.a.Service extends lib.a.Base}. */
    public String declaration() {
        StringBuilder sb = new StringBuilder(Access.describeClass(access)).append(' ').append(dottedName());
        if (superName != null && !isInterface()) {
            sb.append(" extends ").append(Descriptors.toDotted(superName));
        }
        if (!interfaces.isEmpty()) {
            sb.append(isInterface() ? " extends " : " implements ");
            for (int i = 0; i < interfaces.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(Descriptors.toDotted(interfaces.get(i)));
            }
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return name + " (" + originJar() + ")";
    }

    /** Fluent builder used by the class-file reader. */
    public static final class Builder {
        private final String name;
        private final int access;
        private final ClassOrigin origin;
        private @Nullable String superName;
        private final List<String> interfaces = new ArrayList<>();
        private final Map<String, FieldInfo> fields = new LinkedHashMap<>();
        private final Map<String, MethodInfo> methods = new LinkedHashMap<>();
        private @Nullable String nestHost;
        private final Set<String> nestMembers = new java.util.LinkedHashSet<>();
        private final List<String> permittedSubclasses = new ArrayList<>();

        private Builder(String name, int access, ClassOrigin origin) {
            this.name = name;
            this.access = access;
            this.origin = origin;
        }

        /** Internal name of the superclass; {@code null} for {@code java/lang/Object}. */
        public Builder superName(@Nullable String superName) {
            this.superName = superName;
            return this;
        }

        public Builder interfaceName(String interfaceName) {
            this.interfaces.add(interfaceName);
            return this;
        }

        public Builder interfaces(List<String> names) {
            this.interfaces.addAll(names);
            return this;
        }

        public Builder field(FieldInfo field) {
            this.fields.put(field.key(), field);
            return this;
        }

        public Builder method(MethodInfo method) {
            this.methods.put(method.key(), method);
            return this;
        }

        /** Internal name of the nest host; {@code null} when the class is not a nest member. */
        public Builder nestHost(@Nullable String nestHost) {
            this.nestHost = nestHost;
            return this;
        }

        public Builder nestMember(String member) {
            this.nestMembers.add(member);
            return this;
        }

        public Builder permittedSubclass(String subclass) {
            this.permittedSubclasses.add(subclass);
            return this;
        }

        public ClassInfo build() {
            return new ClassInfo(this);
        }
    }
}
