package xland.ioutils.jarcompat.api;

import java.util.*;

import org.jspecify.annotations.Nullable;

/**
 * A single finding of a compatibility check. Immutable; built through {@link Builder}.
 *
 * <p>An instance never exposes bytecode-library types: it carries only plain domain values
 * (severity, kind, symbol text, locations, declarations and human readable explanations).</p>
 *
 * <p>Every textual part except the severity and the kind is optional: classpath hygiene findings
 * carry no symbol, no side and no expected error.</p>
 */
public final class Incompatibility {

    private final Severity severity;
    private final IncompatibilityKind kind;
    private final @Nullable String symbol;
    private final List<Location> locations;
    private final int occurrences;
    private final @Nullable Side sideA;
    private final @Nullable Side sideB;
    private final @Nullable String reason;
    private final @Nullable String suggestion;
    private final @Nullable String expectedError;
    private final @Nullable String expectedMessage;

    private Incompatibility(Builder b) {
        this.severity = b.severity;
        this.kind = b.kind;
        this.symbol = b.symbol;
        this.locations = List.copyOf(b.locations);
        this.occurrences = Math.max(b.occurrences, this.locations.size());
        this.sideA = b.sideA;
        this.sideB = b.sideB;
        this.reason = b.reason;
        this.suggestion = b.suggestion;
        this.expectedError = b.expectedError;
        this.expectedMessage = b.expectedMessage;
    }

    /** Severity of the finding. */
    public Severity severity() {
        return severity;
    }

    /** Classification of the finding. */
    public IncompatibilityKind kind() {
        return kind;
    }

    /** The referenced symbol as written in the program's constant pool, e.g. {@code lib/a/Service.run(I)Ljava/lang/String;}. */
    public @Nullable String symbol() {
        return symbol;
    }

    /** Program locations that trigger the finding (possibly truncated, see {@link #occurrences()}). */
    public List<Location> locations() {
        return locations;
    }

    /** Total number of program sites that trigger the finding. */
    public int occurrences() {
        return occurrences;
    }

    /** The lib-a side of the symbol; may be {@code null} for classpath hygiene findings. */
    public @Nullable Side sideA() {
        return sideA;
    }

    /** The lib-b side of the symbol; may be {@code null} for classpath hygiene findings. */
    public @Nullable Side sideB() {
        return sideB;
    }

    /** Why this is a problem. */
    public @Nullable String reason() {
        return reason;
    }

    /** What the user can do about it. */
    public @Nullable String suggestion() {
        return suggestion;
    }

    /**
     * Fully qualified name of the {@link LinkageError} (or other {@link Throwable}) the JVM is
     * expected to throw, e.g. {@code java.lang.NoSuchMethodError}; {@code null} when the finding
     * does not correspond to a runtime failure.
     */
    public @Nullable String expectedError() {
        return expectedError;
    }

    /**
     * The expected exception message, e.g. {@code java.lang.NoSuchMethodError: 'java.lang.String lib.a.Service.run(int)'}.
     */
    public @Nullable String expectedMessage() {
        return expectedMessage;
    }

    /**
     * JAR of the lib-b side the finding is attributed to (used for the per-JAR statistics).
     */
    public String attributedJar() {
        if (sideB != null && sideB.jar() != null) {
            return sideB.jar();
        }
        if (sideA != null && sideA.jar() != null) {
            return sideA.jar();
        }
        return "(unknown)";
    }

    @Override
    public String toString() {
        return "[" + severity + "] " + kind + " " + symbol;
    }

    /** Fluent builder for {@link Incompatibility}. */
    public static final class Builder {
        private Severity severity = Severity.WARN;
        private IncompatibilityKind kind = IncompatibilityKind.NOTE;
        private @Nullable String symbol;
        private final List<Location> locations = new ArrayList<>();
        private int occurrences;
        private @Nullable Side sideA;
        private @Nullable Side sideB;
        private @Nullable String reason;
        private @Nullable String suggestion;
        private @Nullable String expectedError;
        private @Nullable String expectedMessage;

        public Builder() {
        }

        public Builder severity(Severity severity) {
            this.severity = Objects.requireNonNull(severity);
            return this;
        }

        public Builder kind(IncompatibilityKind kind) {
            this.kind = Objects.requireNonNull(kind);
            return this;
        }

        /** Symbol text; {@code null} for findings that have no constant-pool symbol. */
        public Builder symbol(@Nullable String symbol) {
            this.symbol = symbol;
            return this;
        }

        /** Program location; ignored when {@code null} or already recorded. */
        public Builder location(@Nullable Location location) {
            if (location != null && !locations.contains(location)) {
                locations.add(location);
            }
            return this;
        }

        public Builder locations(List<Location> locations) {
            locations.forEach(this::location);
            return this;
        }

        public Builder occurrences(int occurrences) {
            this.occurrences = occurrences;
            return this;
        }

        public Builder sideA(@Nullable Side sideA) {
            this.sideA = sideA;
            return this;
        }

        public Builder sideB(@Nullable Side sideB) {
            this.sideB = sideB;
            return this;
        }

        public Builder reason(@Nullable String reason) {
            this.reason = reason;
            return this;
        }

        public Builder suggestion(@Nullable String suggestion) {
            this.suggestion = suggestion;
            return this;
        }

        public Builder expectedError(@Nullable String expectedError) {
            this.expectedError = expectedError;
            return this;
        }

        public Builder expectedMessage(@Nullable String expectedMessage) {
            this.expectedMessage = expectedMessage;
            return this;
        }

        public Incompatibility build() {
            return new Incompatibility(this);
        }
    }

    /** Sorted, unmodifiable view helper used by the renderers. */
    public static List<Incompatibility> sorted(List<Incompatibility> items) {
        List<Incompatibility> copy = new ArrayList<>(Objects.requireNonNull(items, "items"));
        copy.sort(Comparator.comparing((Incompatibility x) -> x.severity)
                .thenComparing(x -> x.kind)
                .thenComparing(x -> String.valueOf(x.symbol))
        );
        return Collections.unmodifiableList(copy);
    }
}
