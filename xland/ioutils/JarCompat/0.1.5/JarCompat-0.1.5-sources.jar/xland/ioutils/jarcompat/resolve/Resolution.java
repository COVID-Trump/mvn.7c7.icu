package xland.ioutils.jarcompat.resolve;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

import org.jspecify.annotations.Nullable;

import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.ClassOrigin;

/**
 * Result of a JVM field/method resolution (JVMS §5.4.3.2 / §5.4.3.3).
 *
 * <p>Only a {@link Status#RESOLVED} outcome fills in the declaring class and the member; the failure
 * outcomes leave them {@code null} and may instead name the class that could not be found.</p>
 *
 * @param <T> {@code FieldInfo} or {@code MethodInfo}
 */
public final class Resolution<T> {

    /** Resolution outcome. */
    public enum Status {
        /** The member was found. */
        RESOLVED,
        /** The owner class itself does not exist on this side. */
        OWNER_MISSING,
        /** The owner (and its hierarchy) exists, but the member does not. */
        MEMBER_MISSING,
        /** While walking the hierarchy an intermediate supertype was missing. */
        HIERARCHY_MISSING
    }

    private final Status status;
    private final @Nullable ClassInfo owner;
    private final @Nullable ClassInfo declaringClass;
    private final @Nullable T member;
    private final @Nullable String missingClass;
    private final Set<String> traversedSides;

    private Resolution(Status status, @Nullable ClassInfo owner, @Nullable ClassInfo declaringClass,
                       @Nullable T member, @Nullable String missingClass, Set<String> traversedSides) {
        this.status = status;
        this.owner = owner;
        this.declaringClass = declaringClass;
        this.member = member;
        this.missingClass = missingClass;
        this.traversedSides = Collections.unmodifiableSet(traversedSides);
    }

    static <T> Resolution<T> resolved(ClassInfo owner, ClassInfo declaringClass, T member,
                                      Set<String> sides) {
        return new Resolution<>(Status.RESOLVED, owner, declaringClass, member, null, sides);
    }

    static <T> Resolution<T> ownerMissing(@Nullable ClassInfo owner, String missingClass, Set<String> sides) {
        return new Resolution<>(Status.OWNER_MISSING, owner, null, null, missingClass, sides);
    }

    static <T> Resolution<T> memberMissing(ClassInfo owner, Set<String> sides) {
        return new Resolution<>(Status.MEMBER_MISSING, owner, null, null, null, sides);
    }

    static <T> Resolution<T> hierarchyMissing(ClassInfo owner, String missingClass, Set<String> sides) {
        return new Resolution<>(Status.HIERARCHY_MISSING, owner, null, null, missingClass, sides);
    }

    public Status status() {
        return status;
    }

    public boolean isResolved() {
        return status == Status.RESOLVED;
    }

    /** The class the reference was anchored at; possibly {@code null} when it does not exist. */
    public @Nullable ClassInfo owner() {
        return owner;
    }

    /** The class that actually declares the member (may be a supertype of the owner); {@code null} unless resolved. */
    public @Nullable ClassInfo declaringClass() {
        return declaringClass;
    }

    /** The resolved member, or {@code null}. */
    public @Nullable T member() {
        return member;
    }

    /** Internal name of the class that could not be found (owner or intermediate supertype). */
    public @Nullable String missingClass() {
        return missingClass;
    }

    /** Side labels (program / lib-a / lib-b / jdk) that the resolution walked through. */
    public Set<String> traversedSides() {
        return traversedSides;
    }

    /** Whether resolution walked through at least one class of the given side. */
    public boolean traversed(String side) {
        return traversedSides.contains(side);
    }

    /** Convenience: whether resolution touched the lib-a side. */
    public boolean viaLibA() {
        return traversed(ClassOrigin.LIB_A);
    }

    /** Convenience: whether resolution touched the lib-b side. */
    public boolean viaLibB() {
        return traversed(ClassOrigin.LIB_B);
    }

    /** Side of the declaring class, or {@code null}. */
    public @Nullable String declaringSide() {
        return declaringClass == null || declaringClass.origin() == null
                ? null : declaringClass.origin().side();
    }

    static Set<String> sides() {
        return new LinkedHashSet<>();
    }

    @Override
    public String toString() {
        return status + (member != null ? " " + member : "") + (missingClass != null ? " (missing " + missingClass + ")" : "");
    }
}
