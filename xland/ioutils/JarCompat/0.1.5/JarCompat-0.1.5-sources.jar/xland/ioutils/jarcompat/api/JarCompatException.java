package xland.ioutils.jarcompat.api;

/**
 * Thrown when a compatibility check cannot be carried out at all (unreadable JAR, malformed
 * classpath, {@link ClasspathOrder#ERROR} duplicate class, ...).
 *
 * <p>Individual incompatibilities are <em>not</em> signalled through exceptions; they are part of
 * the returned {@link CheckReport}.</p>
 */
public class JarCompatException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public JarCompatException(String message) {
        super(message);
    }

    public JarCompatException(String message, Throwable cause) {
        super(message, cause);
    }
}
