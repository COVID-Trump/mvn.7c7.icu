package xland.ioutils.jarcompat.asm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jspecify.annotations.Nullable;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LookupSwitchInsnNode;
import org.objectweb.asm.tree.LineNumberNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.MultiANewArrayInsnNode;
import org.objectweb.asm.tree.RecordComponentNode;
import org.objectweb.asm.tree.TableSwitchInsnNode;
import org.objectweb.asm.tree.TryCatchBlockNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Extracts every symbolic reference that can trigger JVM linking from a program class file:
 * classes ({@code new}, {@code checkcast}, {@code instanceof}, signatures, catch types, class
 * literals, ...), fields, methods (all five invocation flavours), {@code invokedynamic} bootstrap
 * handles and arguments, {@code ConstantDynamic}, {@code MethodHandle}/{@code MethodType} constants
 * and annotation values.
 *
 * <p>Line numbers are preserved: each reference is attributed to the source line of the instruction
 * that carries it.</p>
 */
public final class ReferenceCollector {

    private final String programJar;
    private final String className;
    private final List<SymbolicRef> refs = new ArrayList<>();
    private final Set<String> seen = new HashSet<>();
    private @Nullable String methodName;
    private @Nullable String methodDescriptor;
    private int line = -1;

    private ReferenceCollector(String programJar, String className) {
        this.programJar = programJar;
        this.className = className;
    }

    /** Collects all references of one fully parsed class. */
    public static List<SymbolicRef> collect(ClassNode node, String programJar) {
        ReferenceCollector collector = new ReferenceCollector(programJar, node.name);
        collector.collectClass(node);
        return List.copyOf(collector.refs);
    }

    // ------------------------------------------------------------------ class level

    private void collectClass(ClassNode node) {
        this.methodName = null;
        this.methodDescriptor = null;
        this.line = -1;

        if (node.superName != null) {
            classRef(node.superName, 0, false, "superclass 声明");
        }
        if (node.interfaces != null) {
            for (String itf : node.interfaces) {
                classRef(itf, 0, false, "implements/extends 声明");
            }
        }
        if (node.nestHostClass != null) {
            classRef(node.nestHostClass, 0, true, "NestHost 属性");
        }
        if (node.nestMembers != null) {
            for (String member : node.nestMembers) {
                classRef(member, 0, true, "NestMembers 属性");
            }
        }
        if (node.permittedSubclasses != null) {
            for (String permitted : node.permittedSubclasses) {
                classRef(permitted, 0, true, "PermittedSubclasses 属性");
            }
        }
        if (node.outerClass != null) {
            classRef(node.outerClass, 0, true, "OuterClass 属性");
        }
        if (node.innerClasses != null) {
            node.innerClasses.forEach(inner -> {
                if (inner.name != null) {
                    classRef(inner.name, 0, true, "InnerClasses 属性");
                }
                if (inner.outerName != null) {
                    classRef(inner.outerName, 0, true, "InnerClasses 属性");
                }
            });
        }
        if (node.fields != null) {
            for (FieldNode field : node.fields) {
                // A field_info descriptor is not a symbolic reference: the JVM resolves it only
                // when the field is actually read/written (and then through that instruction).
                descriptorTypes(field.desc, 0, true, "字段类型 " + field.name);
                annotations(field.visibleAnnotations, true, "字段注解 " + field.name);
                annotations(field.invisibleAnnotations, true, "字段注解 " + field.name);
                typeAnnotations(field.visibleTypeAnnotations, "字段类型注解 " + field.name);
                typeAnnotations(field.invisibleTypeAnnotations, "字段类型注解 " + field.name);
                if (field.value instanceof Type type) {
                    classRef(type.getInternalName(), 0, true, "常量字段值 " + field.name);
                }
            }
        }
        if (node.recordComponents != null) {
            for (RecordComponentNode component : node.recordComponents) {
                descriptorTypes(component.descriptor, 0, true, "record 组件 " + component.name);
                annotations(component.visibleAnnotations, true, "record 组件注解");
                annotations(component.invisibleAnnotations, true, "record 组件注解");
            }
        }
        if (node.methods != null) {
            for (MethodNode method : node.methods) {
                methodReferences(method);
            }
        }
        annotations(node.visibleAnnotations, true, "类注解");
        annotations(node.invisibleAnnotations, true, "类注解");
        typeAnnotations(node.visibleTypeAnnotations, "类类型注解");
        typeAnnotations(node.invisibleTypeAnnotations, "类类型注解");
    }

    // ------------------------------------------------------------------ method level

    private void methodReferences(MethodNode method) {
        this.methodName = method.name;
        this.methodDescriptor = method.desc;
        this.line = -1;

        // Likewise, a method_info descriptor is not resolved by merely loading the class: only the
        // call sites (captured as METHOD references) resolve parameter and return types.
        descriptorTypes(method.desc, 0, true, "方法签名 " + method.name);
        if (method.exceptions != null) {
            for (String exception : method.exceptions) {
                classRef(exception, 0, true, "throws 声明 " + method.name);
            }
        }
        annotations(method.visibleAnnotations, true, "方法注解 " + method.name);
        annotations(method.invisibleAnnotations, true, "方法注解 " + method.name);
        typeAnnotations(method.visibleTypeAnnotations, "方法类型注解 " + method.name);
        typeAnnotations(method.invisibleTypeAnnotations, "方法类型注解 " + method.name);
        if (method.visibleParameterAnnotations != null) {
            for (List<AnnotationNode> parameter : method.visibleParameterAnnotations) {
                annotations(parameter, true, "参数注解 " + method.name);
            }
        }
        if (method.invisibleParameterAnnotations != null) {
            for (List<AnnotationNode> parameter : method.invisibleParameterAnnotations) {
                annotations(parameter, true, "参数注解 " + method.name);
            }
        }
        if (method.annotationDefault != null) {
            annotationValue(method.annotationDefault, false, "注解默认值 " + method.name);
        }
        if (method.tryCatchBlocks != null) {
            for (TryCatchBlockNode block : method.tryCatchBlocks) {
                if (block.type != null) {
                    classRef(block.type, 0, false, "catch 类型 " + method.name);
                }
            }
        }
        if (method.instructions == null) {
            return;
        }
        NullTracking nulls = new NullTracking(method);
        for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            if (insn instanceof LineNumberNode lineNumber) {
                this.line = lineNumber.line;
                continue;
            }
            boolean operandIsNull = nulls.stackTopIsNull();
            instruction(insn, operandIsNull);
            nulls.accept(insn);
        }
    }

    private void instruction(AbstractInsnNode insn, boolean operandIsNull) {
        switch (insn.getType()) {
            case AbstractInsnNode.TYPE_INSN -> {
                TypeInsnNode typeInsn = (TypeInsnNode) insn;
                String detail = switch (typeInsn.getOpcode()) {
                    case Opcodes.NEW -> "new " + typeInsn.desc;
                    case Opcodes.ANEWARRAY -> "anewarray " + typeInsn.desc;
                    case Opcodes.CHECKCAST -> "checkcast " + typeInsn.desc;
                    case Opcodes.INSTANCEOF -> "instanceof " + typeInsn.desc;
                    default -> "类型指令 " + typeInsn.desc;
                };
                // `checkcast`/`instanceof` on a null value never resolves the type at run time
                boolean nullOperand = (typeInsn.getOpcode() == Opcodes.CHECKCAST
                        || typeInsn.getOpcode() == Opcodes.INSTANCEOF) && operandIsNull;
                classRef(typeInsn.desc, typeInsn.getOpcode(), nullOperand,
                        nullOperand ? detail + "（操作数确定为 null）" : detail);
            }
            case AbstractInsnNode.FIELD_INSN -> {
                FieldInsnNode fieldInsn = (FieldInsnNode) insn;
                add(new SymbolicRef(RefKind.FIELD, fieldInsn.owner, fieldInsn.name, fieldInsn.desc,
                        fieldInsn.getOpcode(), false, false, site(opcodeName(fieldInsn.getOpcode()))));
            }
            case AbstractInsnNode.METHOD_INSN -> {
                MethodInsnNode methodInsn = (MethodInsnNode) insn;
                add(new SymbolicRef(RefKind.METHOD, methodInsn.owner, methodInsn.name, methodInsn.desc,
                        methodInsn.getOpcode(), methodInsn.itf, false,
                        site(opcodeName(methodInsn.getOpcode()) + (methodInsn.itf ? " (interface)" : ""))));
            }
            case AbstractInsnNode.INVOKE_DYNAMIC_INSN -> {
                InvokeDynamicInsnNode indy = (InvokeDynamicInsnNode) insn;
                descriptorTypes(indy.desc, 0, false, "invokedynamic 描述符");
                handle(indy.bsm, false, "invokedynamic bootstrap " + indy.name);
                if (indy.bsmArgs != null) {
                    for (Object arg : indy.bsmArgs) {
                        constant(arg, false, "invokedynamic 参数 " + indy.name);
                    }
                }
            }
            case AbstractInsnNode.LDC_INSN -> constant(((LdcInsnNode) insn).cst, false, "常量 (ldc)");
            case AbstractInsnNode.MULTIANEWARRAY_INSN -> {
                MultiANewArrayInsnNode array = (MultiANewArrayInsnNode) insn;
                classRef(Type.getType(array.desc).getInternalName(), array.getOpcode(), false,
                        "multianewarray " + array.desc);
            }
            default -> {
                // labels, frames, jumps, stack manipulation: nothing to link
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private void constant(Object value, boolean soft, String detail) {
        if (value instanceof Type type) {
            if (type.getSort() == Type.METHOD) {
                descriptorTypes(type.getDescriptor(), 0, soft, detail + " (MethodType)");
            } else if (type.getSort() == Type.OBJECT || type.getSort() == Type.ARRAY) {
                classRef(type.getInternalName(), Opcodes.LDC, soft, detail + " (class literal)");
            }
        } else if (value instanceof Handle handle) {
            handle(handle, soft, detail);
        } else if (value instanceof ConstantDynamic dynamic) {
            descriptorTypes(dynamic.getDescriptor(), 0, soft, detail + " (ConstantDynamic)");
            handle(dynamic.getBootstrapMethod(), soft, detail + " (ConstantDynamic bootstrap)");
            for (int i = 0; i < dynamic.getBootstrapMethodArgumentCount(); i++) {
                constant(dynamic.getBootstrapMethodArgument(i), soft, detail + " (ConstantDynamic 参数)");
            }
        }
    }

    private void handle(Handle handle, boolean soft, String detail) {
        int opcode = switch (handle.getTag()) {
            case Opcodes.H_GETFIELD -> Opcodes.GETFIELD;
            case Opcodes.H_GETSTATIC -> Opcodes.GETSTATIC;
            case Opcodes.H_PUTFIELD -> Opcodes.PUTFIELD;
            case Opcodes.H_PUTSTATIC -> Opcodes.PUTSTATIC;
            case Opcodes.H_INVOKEVIRTUAL, Opcodes.H_INVOKEINTERFACE -> Opcodes.INVOKEVIRTUAL;
            case Opcodes.H_INVOKESTATIC -> Opcodes.INVOKESTATIC;
            case Opcodes.H_INVOKESPECIAL, Opcodes.H_NEWINVOKESPECIAL -> Opcodes.INVOKESPECIAL;
            default -> 0;
        };
        boolean isField = handle.getTag() >= Opcodes.H_GETFIELD && handle.getTag() <= Opcodes.H_PUTSTATIC;
        RefKind kind = isField ? RefKind.FIELD : RefKind.METHOD;
        boolean itf = handle.getTag() == Opcodes.H_INVOKEINTERFACE;
        add(new SymbolicRef(kind, handle.getOwner(), handle.getName(), handle.getDesc(), opcode, itf, soft,
                site(detail)));
    }

    private void classRef(@Nullable String internalName, int opcode, boolean soft, String detail) {
        if (internalName == null || internalName.isEmpty()) {
            return;
        }
        add(new SymbolicRef(RefKind.CLASS, internalName, null, null, opcode, false, soft, site(detail)));
    }

    /** Extracts every class type mentioned by a field or method descriptor. */
    private void descriptorTypes(@Nullable String descriptor, int opcode, boolean soft, String detail) {
        if (descriptor == null) {
            return;
        }
        int i = 0;
        while (i < descriptor.length()) {
            char c = descriptor.charAt(i);
            if (c == 'L' || c == 'Q') {
                int end = descriptor.indexOf(';', i);
                if (end < 0) {
                    return;
                }
                classRef(descriptor.substring(i + 1, end), opcode, soft, detail);
                i = end + 1;
            } else {
                i++;
            }
        }
    }

    private void annotations(@Nullable List<? extends AnnotationNode> annotations, boolean soft, String detail) {
        if (annotations == null) {
            return;
        }
        for (AnnotationNode annotation : annotations) {
            annotation(annotation, soft, detail);
        }
    }

    private void typeAnnotations(@Nullable List<? extends AnnotationNode> annotations, String detail) {
        annotations(annotations, true, detail);
    }

    private void annotation(AnnotationNode annotation, boolean soft, String detail) {
        if (annotation.desc != null) {
            Type type = Type.getType(annotation.desc);
            if (type.getSort() == Type.OBJECT) {
                classRef(type.getInternalName(), 0, soft, detail);
            }
        }
        if (annotation.values != null) {
            for (Object value : annotation.values) {
                annotationValue(value, soft, detail);
            }
        }
    }

    private void annotationValue(@Nullable Object value, boolean soft, String detail) {
        if (value instanceof Type type) {
            if (type.getSort() == Type.OBJECT || type.getSort() == Type.ARRAY) {
                classRef(type.getInternalName(), 0, true, detail);
            }
        } else if (value instanceof AnnotationNode nested) {
            annotation(nested, true, detail);
        } else if (value instanceof List<?> list) {
            list.forEach(element -> annotationValue(element, true, detail));
        } else if (value instanceof String[] enumConstant && enumConstant.length == 2) {
            Type type = Type.getType(enumConstant[0]);
            if (type.getSort() == Type.OBJECT) {
                classRef(type.getInternalName(), 0, true, detail + " (枚举 " + enumConstant[1] + ")");
            }
        }
    }

    private RefSite site(String detail) {
        return new RefSite(programJar, className, methodName, methodDescriptor, line, detail);
    }

    private void add(SymbolicRef ref) {
        if (seen.add(ref.dedupeKey())) {
            refs.add(ref);
        }
    }

    /**
     * Straight-line tracking of "this local slot definitely holds {@code null}" for one method.
     *
     * <p>{@code checkcast} and {@code instanceof} never resolve their type when the operand is
     * {@code null}, so such references cannot cause a {@code NoClassDefFoundError} — reporting them
     * as definite problems would be a false positive. The state is cleared at every jump target,
     * exception handler and stack map frame, so the tracking stays sound without a full verifier.</p>
     */
    private static final class NullTracking {
        private final Set<AbstractInsnNode> boundaries = new HashSet<>();
        private final Set<Integer> nullSlots = new HashSet<>();
        private boolean stackTopNull;

        NullTracking(MethodNode method) {
            for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                switch (insn) {
                    case JumpInsnNode jump -> boundaries.add(jump.label);
                    case TableSwitchInsnNode table -> {
                        boundaries.add(table.dflt);
                        boundaries.addAll(table.labels);
                    }
                    case LookupSwitchInsnNode lookup -> {
                        boundaries.add(lookup.dflt);
                        boundaries.addAll(lookup.labels);
                    }
                    default -> {
                    }
                }
            }
            if (method.tryCatchBlocks != null) {
                for (TryCatchBlockNode block : method.tryCatchBlocks) {
                    boundaries.add(block.start);
                    boundaries.add(block.end);
                    boundaries.add(block.handler);
                }
            }
        }

        boolean stackTopIsNull() {
            return stackTopNull;
        }

        void accept(AbstractInsnNode insn) {
            int opcode = insn.getOpcode();
            if (insn instanceof LabelNode label) {
                // only labels another instruction can jump to may introduce a different value
                if (boundaries.contains(label)) {
                    nullSlots.clear();
                    stackTopNull = false;
                }
                return;
            }
            if (insn instanceof FrameNode) {
                nullSlots.clear();
                stackTopNull = false;
                return;
            }
            boolean wasNull = stackTopNull;
            // ASM normalises the compact load/store forms, so only the generic opcodes appear here
            switch (opcode) {
                case Opcodes.ACONST_NULL -> stackTopNull = true;
                case Opcodes.ALOAD -> stackTopNull = nullSlots.contains(((VarInsnNode) insn).var);
                case Opcodes.ASTORE -> setSlot(((VarInsnNode) insn).var, wasNull);
                case Opcodes.ISTORE, Opcodes.FSTORE -> setSlot(((VarInsnNode) insn).var, false);
                case Opcodes.LSTORE, Opcodes.DSTORE -> {
                    setSlot(((VarInsnNode) insn).var, false);
                    setSlot(((VarInsnNode) insn).var + 1, false);
                }
                default -> stackTopNull = false;
            }
        }

        private void setSlot(int slot, boolean isNull) {
            if (isNull) {
                nullSlots.add(slot);
            } else {
                nullSlots.remove(slot);
            }
            stackTopNull = false;
        }
    }

    private static String opcodeName(int opcode) {
        return switch (opcode) {
            case Opcodes.GETFIELD -> "getfield";
            case Opcodes.PUTFIELD -> "putfield";
            case Opcodes.GETSTATIC -> "getstatic";
            case Opcodes.PUTSTATIC -> "putstatic";
            case Opcodes.INVOKEVIRTUAL -> "invokevirtual";
            case Opcodes.INVOKESPECIAL -> "invokespecial";
            case Opcodes.INVOKESTATIC -> "invokestatic";
            case Opcodes.INVOKEINTERFACE -> "invokeinterface";
            default -> "opcode " + opcode;
        };
    }
}
