package xland.ioutils.jarcompat.api;

/**
 * Strategy applied when the very same class name is defined by more than one JAR on the same side
 * (program, lib-a or lib-b). The JVM only ever sees one of them, so the situation is inherently
 * fragile; this policy decides how JarCompat reports it.
 */
public enum ClasspathOrder {
    /** The first JAR in classpath order wins; the shadowed definitions are reported as {@code WARN}. */
    FIRST_WINS,
    /** The first JAR in classpath order wins; the shadowed definitions are reported as {@code ERROR}. */
    STRICT,
    /** The check aborts immediately by throwing {@link ClasspathConflictException}. */
    ERROR
}
