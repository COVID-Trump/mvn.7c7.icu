package xland.ioutils.jarcompat.engine;

import java.util.LinkedHashSet;
import java.util.Set;

import org.jspecify.annotations.Nullable;

import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.Location;
import xland.ioutils.jarcompat.api.Severity;
import xland.ioutils.jarcompat.asm.ProgramIndex;
import xland.ioutils.jarcompat.model.Access;
import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.Descriptors;
import xland.ioutils.jarcompat.model.MethodInfo;
import xland.ioutils.jarcompat.model.Repo;
import xland.ioutils.jarcompat.reach.Reachability;
import xland.ioutils.jarcompat.resolve.AccessCheck;
import xland.ioutils.jarcompat.resolve.Certainty;
import xland.ioutils.jarcompat.resolve.Hierarchy;
import xland.ioutils.jarcompat.resolve.Resolver;

/**
 * Class-shape checks that are about the program's own types rather than about a single reference:
 *
 * <ul>
 *   <li>program types extending/implementing a lib-a type: does that supertype still exist, is it
 *       still a class / an interface, is it still extensible, is it still accessible?</li>
 *   <li>abstract method coverage: a concrete program type must still implement every abstract
 *       method required by the lib-b version of its supertypes. Interfaces that gained an abstract
 *       method break implementing classes that are not recompiled.</li>
 * </ul>
 */
final class HierarchyChecker {

    private final ProgramIndex program;
    private final Repo repoA;
    private final Repo repoB;
    private final Resolver resolverA;
    private final Resolver resolverB;
    private final Reachability reach;
    private final Findings findings;
    private int abstractChecks;

    HierarchyChecker(ProgramIndex program, Repo repoA, Repo repoB, Resolver resolverA, Resolver resolverB,
                     Reachability reach, Findings findings) {
        this.program = program;
        this.repoA = repoA;
        this.repoB = repoB;
        this.resolverA = resolverA;
        this.resolverB = resolverB;
        this.reach = reach;
        this.findings = findings;
    }

    int abstractChecks() {
        return abstractChecks;
    }

    void checkAll() {
        for (ClassInfo programClass : program.repo().classes()) {
            checkSupertypes(programClass);
            checkFinalMethodOverrides(programClass);
            checkAbstractMethods(programClass);
        }
    }

    // ------------------------------------------------------------------ supertypes

    private void checkSupertypes(ClassInfo programClass) {
        @Nullable String superName = programClass.superName();
        if (superName != null && repoA.contains(superName)) {
            @Nullable ClassInfo inA = repoA.find(superName);
            @Nullable ClassInfo inB = repoB.find(superName);
            Location location = classLocation(programClass, "superclass 声明");
            if (inB == null) {
                missingSupertype(programClass, inA, "superclass", location);
            } else {
                if (!inA.isInterface() && inB.isInterface()) {
                    findings.item(IncompatibilityKind.SUPERCLASS_INCOMPATIBLE, classSeverity(programClass),
                                    superName)
                            .at(location)
                            .sideA(inA.originJar(), inA.declaration())
                            .sideB(inB.originJar(), inB.declaration())
                            .expected("java.lang.IncompatibleClassChangeError",
                                    "java.lang.IncompatibleClassChangeError: class " + programClass.dottedName()
                                            + " has interface " + inB.dottedName() + " as super class")
                            .reason("program 的类 " + programClass.dottedName() + " 继承自 " + inA.dottedName()
                                    + "（A 中是类），B 中它变成了接口，类不能以接口作为父类，加载 program 类时即失败。")
                            .suggestion("让 lib-b 保持该类为普通类，或重编译 program。")
                            .submit();
                }
                if (!inA.isFinal() && inB.isFinal()) {
                    findings.item(IncompatibilityKind.FINAL_VIOLATION, classSeverity(programClass),
                                    superName)
                            .at(location)
                            .sideA(inA.originJar(), inA.declaration())
                            .sideB(inB.originJar(), inB.declaration())
                            .expected("java.lang.IncompatibleClassChangeError",
                                    "java.lang.IncompatibleClassChangeError: class " + programClass.dottedName()
                                            + " cannot inherit from final class " + inB.dottedName())
                            .reason("A 中该父类不是 final，B 中变成了 final；program 的类仍在继承它，"
                                    + "JVM 在定义 program 类时校验失败。")
                            .suggestion("让 lib-b 去掉 final 修饰符，或重编译 program。")
                            .submit();
                }
                if (inB.isSealed() && !inB.permits(programClass.name())) {
                    findings.item(IncompatibilityKind.SUPERCLASS_INCOMPATIBLE, classSeverity(programClass),
                                    superName)
                            .at(location)
                            .sideA(inA.originJar(), inA.declaration())
                            .sideB(inB.originJar(), inB.declaration() + "  （permits "
                                    + inB.permittedSubclasses().stream()
                                    .map(Descriptors::toDotted).collect(java.util.stream.Collectors.joining(", "))
                                    + "）")
                            .expected("java.lang.IncompatibleClassChangeError",
                                    "java.lang.IncompatibleClassChangeError: Failed listed permitted subclass check: class "
                                            + programClass.dottedName() + " is not a permitted subclass of "
                                            + inB.dottedName())
                            .reason("A 中父类 " + inA.dottedName() + " 不是 sealed，B 中变成了 sealed 且 permits 列表（"
                                    + inB.permittedSubclasses().size() + " 项）不包含 program 的子类 "
                                    + programClass.dottedName() + "；JVM 在定义该类时校验 permitted subclass 失败。")
                            .suggestion("让 lib-b 的 permits 列表包含该子类、去掉 sealed，或重编译 program。")
                            .submit();
                }
                Certainty accessA = AccessCheck.classAccess(resolverA, programClass, inA);
                Certainty accessB = AccessCheck.classAccess(resolverB, programClass, inB);
                if (accessA.isYes() && accessB == Certainty.NO) {
                    findings.item(IncompatibilityKind.ACCESS_REDUCED, classSeverity(programClass),
                                    superName)
                            .at(location)
                            .sideA(inA.originJar(), inA.declaration())
                            .sideB(inB.originJar(), inB.declaration())
                            .expected("java.lang.IllegalAccessError",
                                    "java.lang.IllegalAccessError: class " + programClass.dottedName()
                                            + " tried to access superclass " + inB.dottedName())
                            .reason("父类在 B 中不再可访问（" + Access.visibility(inA.access()) + " -> "
                                    + Access.visibility(inB.access()) + "），program 的子类无法加载。")
                            .suggestion("恢复 B 中该类的可见性，或重编译 program。")
                            .submit();
                }
            }
        }
        for (String interfaceName : programClass.interfaces()) {
            if (!repoA.contains(interfaceName)) {
                continue;
            }
            @Nullable ClassInfo inA = repoA.find(interfaceName);
            @Nullable ClassInfo inB = repoB.find(interfaceName);
            Location location = classLocation(programClass, "implements/extends 声明");
            if (inB == null) {
                missingSupertype(programClass, inA, "接口", location);
            } else if (inA.isInterface() && !inB.isInterface()) {
                findings.item(IncompatibilityKind.SUPERCLASS_INCOMPATIBLE, classSeverity(programClass),
                                interfaceName)
                        .at(location)
                        .sideA(inA.originJar(), inA.declaration())
                        .sideB(inB.originJar(), inB.declaration())
                        .expected("java.lang.IncompatibleClassChangeError",
                                "java.lang.IncompatibleClassChangeError: class " + programClass.dottedName()
                                        + " can not implement " + inB.dottedName()
                                        + ", because it is not an interface (" + inB.dottedName()
                                        + " is in unnamed module of loader 'app')")
                        .reason("program 的类声明实现 " + inA.dottedName() + "（A 中是接口），但 B 中它变成了类，"
                                + "类不能出现在 implements 列表中，加载 program 类时即失败。")
                        .suggestion("让 lib-b 保持该类型为接口，或重编译 program。")
                        .submit();
            }
        }
    }

    private void missingSupertype(ClassInfo programClass, ClassInfo inA, String role, Location location) {
        findings.item(IncompatibilityKind.MISSING_CLASS, classSeverity(programClass), inA.dottedName())
                .at(location)
                .sideA(inA.originJar(), inA.declaration())
                .sideB(repoB.label(), null)
                .expected("java.lang.NoClassDefFoundError", "java.lang.NoClassDefFoundError: " + inA.name())
                .reason("program 的类 " + programClass.dottedName() + " 的" + role + " " + inA.dottedName()
                        + " 在 B 侧不存在，加载 program 类时会先失败于该类。")
                .suggestion("在 lib-b 中保留该类型（类名不变即可，放在哪个 JAR 都行），或重编译 program。")
                .submit();
    }

    /**
     * A program method that overrides a library method which became {@code final} in lib-b fails at
     * class definition time: {@code IncompatibleClassChangeError: class X overrides final method Y}.
     */
    private void checkFinalMethodOverrides(ClassInfo programClass) {
        for (MethodInfo method : programClass.methods()) {
            if (method.isStatic() || method.isConstructor() || method.isClassInitializer()
                    || Access.isPrivate(method.access())) {
                continue;
            }
            for (String superName : resolverB.hierarchyOf(programClass).reachable()) {
                if (superName.equals(programClass.name()) || !repoA.contains(superName)) {
                    continue;
                }
                @Nullable ClassInfo superB = repoB.find(superName);
                @Nullable ClassInfo superA = repoA.find(superName);
                if (superB == null || superA == null) {
                    continue;
                }
                MethodInfo inheritedB = superB.findMethod(method.name(), method.descriptor());
                if (inheritedB == null || inheritedB.isStatic() || !Access.isFinal(inheritedB.access())) {
                    continue;
                }
                MethodInfo inheritedA = superA.findMethod(method.name(), method.descriptor());
                if (inheritedA != null && Access.isFinal(inheritedA.access())) {
                    continue; // was already final against lib-a: not a regression
                }
                findings.item(IncompatibilityKind.FINAL_VIOLATION, classSeverity(programClass),
                                "program 方法 " + programClass.dottedName() + "." + method.name() + method.descriptor())
                        .at(new Location(programClass.originJar(), programClass.dottedName(), method.name(),
                                method.descriptor(), -1, "覆盖了 lib-b 中的 final 方法"))
                        .sideA(superA.originJar(), inheritedA == null
                                ? superA.declaration() + "  （A 中没有同名方法）" : inheritedA.declaration())
                        .sideB(superB.originJar(), inheritedB.declaration())
                        .expected("java.lang.IncompatibleClassChangeError",
                                "java.lang.IncompatibleClassChangeError: class " + programClass.dottedName()
                                        + " overrides final method " + Descriptors.toDotted(superB.name()) + "."
                                        + method.name() + method.descriptor())
                        .reason("A 中 " + superA.dottedName() + " 的 " + method.name() + method.descriptor()
                                + " 不是 final，program 的 " + programClass.dottedName()
                                + " 覆盖了它；B 中它变成了 final，JVM 在定义 program 类时校验失败。")
                        .suggestion("让 lib-b 去掉该方法的 final 修饰符，或重编译 program 去掉覆盖。")
                        .submit();
            }
        }
    }

    // ------------------------------------------------------------------ abstract methods

    private void checkAbstractMethods(ClassInfo programClass) {
        if (programClass.isInterface() || programClass.isAbstract()) {
            return;
        }
        abstractChecks++;
        Hierarchy hierarchy = resolverB.hierarchyOf(programClass);
        Set<String> reported = new LinkedHashSet<>();
        for (String superName : hierarchy.reachable()) {
            if (superName.equals(programClass.name()) || !repoA.contains(superName)) {
                continue;
            }
            @Nullable ClassInfo inA = repoA.find(superName);
            @Nullable ClassInfo inB = repoB.find(superName);
            if (inB == null) {
                continue; // already reported as a missing supertype
            }
            for (MethodInfo method : inB.methods()) {
                if (!method.isAbstract() || method.isStatic() || Access.isPrivate(method.access())) {
                    continue;
                }
                if (method.isConstructor() || method.isClassInitializer()) {
                    continue;
                }
                MethodInfo old = inA == null ? null : inA.findMethod(method.name(), method.descriptor());                boolean isNew = old == null;
                boolean becameAbstract = old != null && !old.isAbstract();
                if (!isNew && !becameAbstract) {
                    continue;
                }
                if (!reported.add(method.key())) {
                    continue;
                }
                if (isImplemented(programClass, method, inB.isInterface())) {
                    continue;
                }
                reportAbstractMethod(programClass, inA, inB, method, isNew);
            }
        }
    }

    private void reportAbstractMethod(ClassInfo programClass, ClassInfo inA, ClassInfo inB, MethodInfo method,
                                      boolean isNew) {
        Severity severity = reach.instantiatedClasses().contains(programClass.name())
                || reach.reachableClasses().contains(programClass.name())
                ? Severity.ERROR : Severity.WARN;
        String signature = Descriptors.returnTypeName(method.descriptor()) + " " + method.name()
                + Descriptors.parameterList(method.descriptor());
        String reason = (isNew
                ? "B 中 " + inB.dottedName() + " 新增了抽象方法 " + signature + "，"
                : "B 中 " + inB.dottedName() + " 的方法 " + signature + " 由默认方法变成了抽象方法，")
                + "而 program 的 " + programClass.dottedName() + " 仍在实现它但没有实现该方法。"
                + (severity == Severity.ERROR
                ? "该类在可达代码中被使用/实例化，一旦有人调用该抽象方法（lib-b 内部、其它调用方或未来代码）"
                + "就会在本类实例上抛 AbstractMethodError。"
                + "注意：JVM 允许具体类不实现接口的全部抽象方法，因此只要没有任何代码调用这个新方法，"
                + "程序仍可能正常运行；本项按“确定不兼容”报告是因为该契约一旦被行使就必然失败，"
                + "而这无法仅从 program 侧静态判定。"
                : "（该类当前不可达或可达性未知，属于潜在风险。）");
        findings.item(IncompatibilityKind.ABSTRACT_METHOD_MISSING, severity,
                        "program 类 " + programClass.dottedName() + " 未实现 " + inB.dottedName() + "."
                                + method.name() + method.descriptor())
                .at(classLocation(programClass, "实现类缺少抽象方法"))
                .sideA(inA.originJar(), inA.declaration())
                .sideB(inB.originJar(), inB.declaration())
                .expected("java.lang.AbstractMethodError",
                        "java.lang.AbstractMethodError: Receiver class " + programClass.dottedName()
                                + " does not define or inherit an implementation of the resolved method 'abstract "
                                + signature + "' of "
                                + (inB.isInterface() ? "interface " : inB.isAbstract() ? "abstract class " : "class ")
                                + inB.dottedName() + ".")
                .reason(reason)
                .suggestion("重编译 program 以实现该方法；若 lib-b 可以调整，为该方法提供默认实现（default method）"
                        + "也能恢复兼容。")
                .submit();
    }

    /**
     * Whether the (concrete) program class provides an implementation for {@code required}.
     * Interface methods require a {@code public} implementation; abstract class methods may be
     * implemented with any non-private access.
     */
    private boolean isImplemented(ClassInfo programClass, MethodInfo required, boolean requirePublic) {
        Hierarchy hierarchy = resolverB.hierarchyOf(programClass);
        for (String superName : hierarchy.reachable()) {
            ClassInfo info = resolverB.findClass(superName);
            if (info == null) {
                continue;
            }
            for (MethodInfo candidate : info.methods()) {
                if (!candidate.name().equals(required.name())
                        || !candidate.descriptor().equals(required.descriptor())) {
                    continue;
                }
                if (candidate.isStatic() || candidate.isAbstract() || Access.isPrivate(candidate.access())) {
                    continue;
                }
                if (info.isInterface()) {
                    return true; // a default method satisfies the requirement
                }
                if (!requirePublic || Access.isPublic(candidate.access())) {
                    return true;
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ helpers

    private Location classLocation(ClassInfo programClass, String detail) {
        return new Location(programClass.originJar(), programClass.dottedName(), null, null, -1, detail);
    }

    private Severity classSeverity(ClassInfo programClass) {
        if (!reach.entryKnown()) {
            return Severity.WARN;
        }
        return reach.reachableClasses().contains(programClass.name())
                || reach.instantiatedClasses().contains(programClass.name())
                ? Severity.ERROR : Severity.WARN;
    }
}
