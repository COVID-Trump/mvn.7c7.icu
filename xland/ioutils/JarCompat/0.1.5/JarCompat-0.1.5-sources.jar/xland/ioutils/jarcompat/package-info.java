/**
 * JarCompat command line entry point ({@code xland.ioutils.jarcompat.Main}).
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable}.</p>
 */
@NullMarked
package xland.ioutils.jarcompat;

import org.jspecify.annotations.NullMarked;
