package xland.ioutils.jarcompat.model;

import java.util.Objects;

import org.jspecify.annotations.Nullable;

/**
 * Descriptor and name helpers (JVMS §4.3). Self contained: no bytecode library involved.
 *
 * <p>Several helpers accept and propagate {@code null} on purpose: they sit on paths where a name
 * legitimately may be absent (a class with no superclass, a reference without a member name).</p>
 */
public final class Descriptors {

    private Descriptors() {
    }

    /**
     * {@code com/foo/Bar} to {@code com.foo.Bar}, and an array type to its readable form:
     * {@code [B} to {@code byte[]}, {@code [Ljava/util/List;} to {@code java.util.List[]}.
     *
     * @return the dotted name, or {@code null} when {@code internalName} is {@code null}
     */
    public static @Nullable String toDotted(@Nullable String internalName) {
        if (internalName == null) {
            return null;
        }
        return isArray(internalName) ? typeName(internalName) : internalName.replace('/', '.');
    }

    /** Whether a (possibly array) name is an array type: {@code [B}, {@code [Ljava/lang/String;}, ... */
    public static boolean isArray(@Nullable String internalName) {
        return internalName != null && !internalName.isEmpty() && internalName.charAt(0) == '[';
    }

    /**
     * Class a reference to an array type really depends on, i.e. the innermost element type:
     * {@code [Ljava/util/List;} and {@code [[Ljava/util/List;} to {@code java/util/List}.
     *
     * <p>Array classes have no binary representation: the JVM creates them on demand and resolves
     * only their element type (JVMS §5.3.3, §5.4.3.1), and an array of a primitive type
     * ({@code [B}) resolves nothing at all.</p>
     *
     * @return the element class internal name, or {@code null} when there is no class to resolve
     *         (primitive element type, malformed descriptor, or not an array type at all)
     */
    public static @Nullable String arrayElementClass(@Nullable String internalName) {
        if (!isArray(internalName)) {
            return null;
        }
        int i = 0;
        while (i < internalName.length() && internalName.charAt(i) == '[') {
            i++;
        }
        if (i >= internalName.length()) {
            return null;
        }
        char element = internalName.charAt(i);
        if (element != 'L' && element != 'Q') {
            return null; // primitive element type
        }
        int end = internalName.indexOf(';', i);
        return end < 0 ? null : internalName.substring(i + 1, end);
    }

    /** {@code com.foo.Bar} to {@code com/foo/Bar} (already slashed names are returned unchanged). */
    public static @Nullable String toInternal(@Nullable String name) {
        return name == null ? null : name.replace('.', '/');
    }

    /** Package part of an internal name, or {@code ""} for the default package. */
    public static String packageOf(String internalName) {
        int idx = Objects.requireNonNull(internalName, "internalName").lastIndexOf('/');
        return idx < 0 ? "" : internalName.substring(0, idx);
    }

    /** Simple name of an internal name. */
    public static String simpleName(String internalName) {
        int idx = Objects.requireNonNull(internalName, "internalName").lastIndexOf('/');
        return idx < 0 ? internalName : internalName.substring(idx + 1);
    }

    /** Package part of a descriptor's class type, e.g. {@code Ljava/util/List;} to {@code java.util}. */
    public static String packageOfDotted(String dottedClassName) {
        int idx = dottedClassName.lastIndexOf('.');
        return idx < 0 ? "" : dottedClassName.substring(0, idx);
    }

    /** Human readable name of a type descriptor: {@code I} to {@code int}, {@code [Ljava/lang/String;} to {@code java.lang.String[]}. */
    public static String typeName(String descriptor) {
        int dims = 0;
        int i = 0;
        Objects.requireNonNull(descriptor, "descriptor");
        while (i < descriptor.length() && descriptor.charAt(i) == '[') {
            dims++;
            i++;
        }
        String base = descriptor.substring(i);
        String name;
        switch (base) {
            case "V" -> name = "void";
            case "Z" -> name = "boolean";
            case "B" -> name = "byte";
            case "C" -> name = "char";
            case "S" -> name = "short";
            case "I" -> name = "int";
            case "J" -> name = "long";
            case "F" -> name = "float";
            case "D" -> name = "double";
            default -> {
                if (base.startsWith("L") && base.endsWith(";")) {
                    name = toDotted(base.substring(1, base.length() - 1));
                } else if (base.startsWith("Q") && base.endsWith(";")) {
                    // Q-type descriptor (Valhalla preview): treat like a class type
                    name = toDotted(base.substring(1, base.length() - 1));
                } else {
                    name = base;
                }
            }
        }
        return name + "[]".repeat(dims);
    }

    /** Number of method parameters encoded in a method descriptor. */
    public static int parameterCount(String methodDescriptor) {
        int count = 0;
        int i = 1;
        while (i < methodDescriptor.length() && methodDescriptor.charAt(i) != ')') {
            while (methodDescriptor.charAt(i) == '[') {
                i++;
            }
            if (methodDescriptor.charAt(i) == 'L' || methodDescriptor.charAt(i) == 'Q') {
                i = methodDescriptor.indexOf(';', i) + 1;
            } else {
                i++;
            }
            count++;
        }
        return count;
    }

    /** Parameter type list of a method descriptor: {@code (I;Ljava/lang/String;)V} to {@code (int, java.lang.String)}. */
    public static String parameterList(String methodDescriptor) {
        StringBuilder sb = new StringBuilder("(");
        int i = 1;
        boolean first = true;
        while (i < methodDescriptor.length() && methodDescriptor.charAt(i) != ')') {
            int start = i;
            while (methodDescriptor.charAt(i) == '[') {
                i++;
            }
            if (methodDescriptor.charAt(i) == 'L' || methodDescriptor.charAt(i) == 'Q') {
                i = methodDescriptor.indexOf(';', i) + 1;
            } else {
                i++;
            }
            if (!first) {
                sb.append(", ");
            }
            sb.append(typeName(methodDescriptor.substring(start, i)));
            first = false;
        }
        return sb.append(')').toString();
    }

    /** Return type of a method descriptor. */
    public static String returnTypeName(String methodDescriptor) {
        return typeName(methodDescriptor.substring(methodDescriptor.indexOf(')') + 1));
    }

    /**
     * Human readable declaration of a method, e.g.
     * {@code public java.lang.String lib.a.Service.run(int)}.
     */
    public static String methodDeclaration(int access, String owner, String name, String descriptor) {
        String ret = returnTypeName(descriptor);
        String ownerDotted = toDotted(owner);
        if ("<init>".equals(name)) {
            ownerDotted = simpleName(owner);
            ret = "";
        } else if ("<clinit>".equals(name)) {
            return Access.describeMethod(access) + " (static initializer of " + ownerDotted + ")";
        }
        return (Access.describeMethod(access) + " " + ret + " " + ownerDotted + "." + name
                + parameterList(descriptor)).replace("  ", " ");
    }

    /**
     * Human readable declaration of a field, e.g.
     * {@code public static final java.lang.String lib.a.Config.VERSION}.
     */
    public static String fieldDeclaration(int access, String owner, String name, String descriptor) {
        return Access.describeField(access) + " " + typeName(descriptor) + " " + toDotted(owner) + "." + name;
    }

    /**
     * HotSpot style method signature used in {@code NoSuchMethodError} messages:
     * {@code java.lang.String lib.a.Service.run(int)}.
     */
    public static String linkageMethodSignature(String owner, String name, String descriptor) {
        if ("<init>".equals(name)) {
            return "void " + toDotted(owner) + ".<init>" + parameterList(descriptor);
        }
        return returnTypeName(descriptor) + " " + toDotted(owner) + "." + name + parameterList(descriptor);
    }

    /**
     * HotSpot style field signature used in {@code NoSuchFieldError} messages:
     * {@code java.lang.String lib.a.Config.VERSION}.
     */
    public static String linkageFieldSignature(String owner, String name, String descriptor) {
        return typeName(descriptor) + " " + toDotted(owner) + "." + name;
    }

    /** Human readable symbol of a method reference, e.g. {@code lib/a/Service.run(I)Ljava/lang/String;}. */
    public static String methodSymbol(String owner, String name, String descriptor) {
        return owner + "." + name + descriptor;
    }

    /** Human readable symbol of a field reference, e.g. {@code lib/a/Config.VERSION:Ljava/lang/String;}. */
    public static String fieldSymbol(String owner, String name, String descriptor) {
        return owner + "." + name + ":" + descriptor;
    }
}
