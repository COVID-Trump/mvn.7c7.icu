package xland.ioutils.jarcompat.api;

/**
 * Severity of a single finding.
 *
 * <ul>
 *   <li>{@link #ERROR} — definite incompatibility: the reference is statically reachable and the JVM
 *       would fail to link it when running the program on the new library set.</li>
 *   <li>{@link #WARN} — potential incompatibility: unreachable / unknown-reachability references,
 *       duplicated classes, classpath hygiene problems, uncovered dynamic calls. The program may
 *       still run fine, but the situation deserves attention.</li>
 *   <li>{@link #INFO} — informational, never affects the verdict.</li>
 * </ul>
 */
public enum Severity {
    ERROR,
    WARN,
    INFO
}
