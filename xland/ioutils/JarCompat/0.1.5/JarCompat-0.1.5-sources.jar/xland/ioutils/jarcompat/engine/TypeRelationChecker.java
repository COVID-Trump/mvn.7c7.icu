package xland.ioutils.jarcompat.engine;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.jspecify.annotations.Nullable;

import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LineNumberNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;

import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.Location;
import xland.ioutils.jarcompat.api.Severity;
import xland.ioutils.jarcompat.asm.ProgramIndex;
import xland.ioutils.jarcompat.asm.RefKind;
import xland.ioutils.jarcompat.asm.SymbolicRef;
import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.Repo;
import xland.ioutils.jarcompat.reach.Reach;
import xland.ioutils.jarcompat.reach.Reachability;
import xland.ioutils.jarcompat.resolve.Resolver;

/**
 * Checks subtype relations the program relies upon between two <em>library</em> types — a case that
 * plain reference checking misses because the JVM resolves the member fine and only fails on the
 * concrete receiver.
 *
 * <p>Two flavours are covered:</p>
 * <ol>
 *   <li><b>Cast sites</b>: {@code checkcast}/{@code instanceof} to a type {@code T} where the
 *       operand is produced by a known expression of library type {@code S}. If {@code S <: T} held
 *       against lib-a but no longer holds against lib-b, the cast fails at run time
 *       ({@link ClassCastException}, or {@code IncompatibleClassChangeError} for the following
 *       interface call). When the operand is the result of a constructor call the runtime type is
 *       exactly {@code S}, so the finding is definite.</li>
 *   <li><b>Lost interface implementations</b>: the program constructs instances of the lib-a class
 *       {@code C} and calls methods through the lib-a interface {@code I}. If {@code C implements I}
 *       in lib-a but not in lib-b, instances of {@code C} that flow into {@code I} make the call
 *       fail with {@code IncompatibleClassChangeError: Class C does not implement the requested
 *       interface I}. javac emits no cast for such an assignment, so this cannot be seen at a cast
 *       site.</li>
 * </ol>
 */
final class TypeRelationChecker {

    private final ProgramIndex program;
    private final Repo repoA;
    private final Repo repoB;
    private final Resolver resolverA;
    private final Resolver resolverB;
    private final Reachability reach;
    private final Findings findings;

    TypeRelationChecker(ProgramIndex program, Repo repoA, Repo repoB, Resolver resolverA, Resolver resolverB,
                        Reachability reach, Findings findings) {
        this.program = program;
        this.repoA = repoA;
        this.repoB = repoB;
        this.resolverA = resolverA;
        this.resolverB = resolverB;
        this.reach = reach;
        this.findings = findings;
    }

    void checkAll() {
        checkCastSites();
        checkLostInterfaceImplementations();
    }

    // ------------------------------------------------------------------ cast sites

    private void checkCastSites() {
        for (ClassInfo programClass : program.repo().classes()) {
            @Nullable ClassNode node = program.node(programClass.name());
            if (node == null || node.methods == null) {
                continue;
            }
            for (MethodNode method : node.methods) {
                if (method.instructions == null) {
                    continue;
                }
                int line = -1;
                for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    if (insn instanceof LineNumberNode lineNumber) {
                        line = lineNumber.line;
                    } else if (insn instanceof TypeInsnNode typeInsn
                            && (typeInsn.getOpcode() == Opcodes.CHECKCAST
                            || typeInsn.getOpcode() == Opcodes.INSTANCEOF)) {
                        checkCast(programClass, method, typeInsn, line);
                    }
                }
            }
        }
    }

    private void checkCast(ClassInfo programClass, MethodNode method, TypeInsnNode cast, int line) {
        String target = cast.desc;
        if (target.startsWith("[")) {
            return;
        }
        @Nullable ClassInfo targetA = repoA.find(target);
        if (targetA == null) {
            return; // not a lib-a type
        }
        SourceType source = sourceTypeOf(cast);
        if (source == null || source.name().equals(target)) {
            return;
        }
        @Nullable ClassInfo sourceA = repoA.find(source.name());
        if (sourceA == null || sourceA.isInterface()) {
            return;
        }
        if (!resolverA.isSubtypeOf(sourceA, target)) {
            return; // the relation never held against lib-a: not a regression
        }
        @Nullable ClassInfo sourceB = repoB.find(source.name());
        @Nullable ClassInfo targetB = repoB.find(target);
        if (sourceB == null || targetB == null) {
            return; // class removal / kind change is reported by the reference checker
        }
        if (targetA.isInterface() != targetB.isInterface() || resolverB.isSubtypeOf(sourceB, target)) {
            return;
        }
        boolean exact = source.exact();
        boolean instanceOf = cast.getOpcode() == Opcodes.INSTANCEOF;
        Severity severity = exact && !instanceOf ? severityFor(programClass, method) : Severity.WARN;
        Location location = new Location(programClass.originJar(), programClass.dottedName(), method.name,
                method.desc, line, instanceOf ? "instanceof " + target : "checkcast " + target);
        findings.item(IncompatibilityKind.HIERARCHY_RELATION_LOST, severity, sourceA.name() + " -> " + target)
                .at(location)
                .sideA(sourceA.originJar(), relationDeclaration(sourceA, targetA, true))
                .sideB(sourceB.originJar(), relationDeclaration(sourceB, targetB, false))
                .expected(expectedError(targetA), expectedMessage(sourceA, targetA, instanceOf))
                .reason("program 在此处把 " + sourceA.dottedName() + " 的值当作 "
                        + (targetA.isInterface() ? "接口 " : "父类 ") + targetA.dottedName()
                        + " 使用；A 中二者存在子类型关系，B 中已不存在。"
                        + (instanceOf
                        ? "instanceof 不会抛异常，但结果会由 true 变成 false（行为变化）。"
                        : "运行期该转换会失败。")
                        + (exact ? "" : "（操作数不是刚构造的实例，其运行期类型可能是仍实现该接口的子类，故按潜在问题报告。）")
                        + reachabilityNote(programClass, method))
                .suggestion("在 lib-b 中恢复 " + sourceA.dottedName() + " 与 " + targetA.dottedName()
                        + " 的子类型关系（类放在哪个 JAR 都可以），或重编译 program。")
                .submit();
    }

    // ------------------------------------------------------------------ lost interface implementations

    private void checkLostInterfaceImplementations() {
        Map<String, List<SymbolicRef>> interfaceCalls = new LinkedHashMap<>();
        Set<String> touched = new LinkedHashSet<>();
        for (SymbolicRef ref : program.references()) {
            if (ref.kind() == RefKind.CLASS) {
                if (repoA.contains(ref.owner())) {
                    touched.add(ref.owner());
                }
                continue;
            }
            if (!repoA.contains(ref.owner()) && !program.repo().contains(ref.owner())) {
                continue;
            }
            if (ref.kind() == RefKind.METHOD && ref.interfaceRef() && repoA.contains(ref.owner())) {
                interfaceCalls.computeIfAbsent(ref.owner(), key -> new ArrayList<>()).add(ref);
            }
            if (repoA.contains(ref.owner())) {
                touched.add(ref.owner());
            }
        }
        if (interfaceCalls.isEmpty() || touched.isEmpty()) {
            return;
        }
        for (String className : touched) {
            @Nullable ClassInfo classA = repoA.find(className);
            @Nullable ClassInfo classB = repoB.find(className);
            if (classA == null || classB == null || classA.isInterface()) {
                continue;
            }
            Set<String> interfacesA = interfaceClosure(resolverA, classA);
            if (interfacesA.isEmpty()) {
                continue;
            }
            Set<String> interfacesB = interfaceClosure(resolverB, classB);
            for (String interfaceName : interfacesA) {
                if (interfacesB.contains(interfaceName)) {
                    continue;
                }
                List<SymbolicRef> calls = interfaceCalls.get(interfaceName);
                if (calls == null) {
                    continue; // the program never calls through that interface
                }
                reportLostImplementation(classA, classB, interfaceName, calls);
            }
        }
    }

    private void reportLostImplementation(ClassInfo classA, ClassInfo classB, String interfaceName,
                                          List<SymbolicRef> calls) {
        @Nullable ClassInfo interfaceA = repoA.find(interfaceName);
        @Nullable ClassInfo interfaceB = repoB.find(interfaceName);
        if (interfaceA == null || interfaceB == null) {
            return;
        }
        boolean instantiated = reach.instantiatedClasses().contains(classA.name());
        boolean anyReachable = !reach.entryKnown()
                || calls.stream().anyMatch(call -> reach.reachabilityOf(call) == Reach.REACHABLE);
        Severity severity = instantiated && anyReachable ? Severity.ERROR : Severity.WARN;
        Findings.Item item = findings.item(IncompatibilityKind.HIERARCHY_RELATION_LOST, severity,
                        classA.name() + " -> " + interfaceName)
                .sideA(classA.originJar(), relationDeclaration(classA, interfaceA, true))
                .sideB(classB.originJar(), relationDeclaration(classB, interfaceB, false))
                .expected("java.lang.IncompatibleClassChangeError",
                        "java.lang.IncompatibleClassChangeError: Class " + classA.dottedName()
                                + " does not implement the requested interface " + interfaceA.dottedName())
                .reason("A 中 " + classA.dottedName() + " 实现了接口 " + interfaceA.dottedName()
                        + "，B 中不再实现；而 program "
                        + (instantiated ? "在可达代码中构造了该类的实例" : "引用了该类")
                        + "，并在 " + calls.size() + " 处通过该接口调用方法。"
                        + (instantiated
                        ? "这些实例一旦作为 " + interfaceA.dottedName() + " 使用（javac 对「类 -> 接口」赋值不生成 checkcast，"
                        + "因此字节码里看不到转换点），调用点就会抛 IncompatibleClassChangeError。"
                        : "（未能证明实例确实流向该接口，属于潜在风险。）"))
                .suggestion("在 lib-b 中恢复 " + classA.dottedName() + " 对 " + interfaceA.dottedName()
                        + " 的实现，或重编译 program。");
        for (SymbolicRef call : calls) {
            item.at(call);
        }
        item.submit();
    }

    /** All interfaces (transitively) implemented by a class. */
    private Set<String> interfaceClosure(Resolver resolver, ClassInfo start) {
        Set<String> result = new LinkedHashSet<>();
        Set<String> visited = new LinkedHashSet<>();
        Deque<ClassInfo> queue = new ArrayDeque<>();
        queue.add(start);
        while (!queue.isEmpty()) {
            ClassInfo current = queue.poll();
            if (current == null || !visited.add(current.name())) {
                continue;
            }
            if (current.isInterface()) {
                result.add(current.name());
            }
            for (String interfaceName : current.interfaces()) {
                @Nullable ClassInfo info = resolver.findClass(interfaceName);
                if (info != null) {
                    queue.add(info);
                }
            }
            ClassInfo superClass = resolver.superclassOf(current);
            if (superClass != null) {
                queue.add(superClass);
            }
        }
        return result;
    }

    // ------------------------------------------------------------------ helpers

    private Severity severityFor(ClassInfo programClass, MethodNode method) {
        if (!reach.entryKnown()) {
            return Severity.WARN;
        }
        return reach.isMethodReachable(programClass.name(), method.name, method.desc)
                ? Severity.ERROR : Severity.WARN;
    }

    private String reachabilityNote(ClassInfo programClass, MethodNode method) {
        if (!reach.entryKnown()) {
            return "（可达性未知：未找到入口点。）";
        }
        return reach.isMethodReachable(programClass.name(), method.name, method.desc)
                ? "" : "（该代码从入口点不可达，属于潜在问题。）";
    }

    private static String relationDeclaration(ClassInfo type, ClassInfo supertype, boolean holds) {
        String relation = supertype.isInterface() ? "实现" : "继承";
        return type.declaration() + "  （" + (holds ? "" : "不再") + relation + " " + supertype.dottedName() + "）";
    }

    private static String expectedError(ClassInfo target) {
        return target.isInterface() ? "java.lang.IncompatibleClassChangeError" : "java.lang.ClassCastException";
    }

    private static String expectedMessage(ClassInfo source, ClassInfo target, boolean instanceOf) {
        if (target.isInterface()) {
            return "java.lang.IncompatibleClassChangeError: Class " + source.dottedName()
                    + " does not implement the requested interface " + target.dottedName();
        }
        return "java.lang.ClassCastException: class " + source.dottedName()
                + " cannot be cast to class " + target.dottedName();
    }

    private record SourceType(String name, boolean exact) {
    }

    /**
     * Recovers the static (and, for constructor calls, exact) type of the value a cast is applied
     * to, by looking at the instruction that produced it.
     */
    private SourceType sourceTypeOf(TypeInsnNode cast) {
        AbstractInsnNode previous = previousRealInstruction(cast);
        if (previous instanceof MethodInsnNode call) {
            if (call.getOpcode() == Opcodes.INVOKESPECIAL && "<init>".equals(call.name)) {
                // NEW S; ...; invokespecial S.<init> -> the runtime type is exactly S
                return new SourceType(call.owner, true);
            }
            Type returnType = Type.getReturnType(call.desc);
            return returnType.getSort() == Type.OBJECT
                    ? new SourceType(returnType.getInternalName(), false) : null;
        }
        if (previous instanceof FieldInsnNode field) {
            Type fieldType = Type.getType(field.desc);
            return fieldType.getSort() == Type.OBJECT ? new SourceType(fieldType.getInternalName(), false) : null;
        }
        if (previous instanceof TypeInsnNode typeInsn && typeInsn.getOpcode() == Opcodes.CHECKCAST) {
            return typeInsn.desc.startsWith("[") ? null : new SourceType(typeInsn.desc, false);
        }
        return null;
    }

    private AbstractInsnNode previousRealInstruction(AbstractInsnNode insn) {
        AbstractInsnNode previous = insn.getPrevious();
        while (previous instanceof LabelNode || previous instanceof LineNumberNode || previous instanceof FrameNode) {
            previous = previous.getPrevious();
        }
        return previous;
    }
}
