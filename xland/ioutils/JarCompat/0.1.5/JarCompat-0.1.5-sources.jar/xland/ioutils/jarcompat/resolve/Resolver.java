package xland.ioutils.jarcompat.resolve;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.jspecify.annotations.Nullable;

import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.FieldInfo;
import xland.ioutils.jarcompat.model.MethodInfo;
import xland.ioutils.jarcompat.model.Repo;

/**
 * Simulates the JVM's linkage-time resolution (JVMS §5.4.3) on a logical repository: class lookup,
 * field resolution, method resolution (class and interface flavours) plus the hierarchy walks the
 * access checks need.
 *
 * <p>Nothing is loaded: the repository plus {@code jrt:/} metadata is all that is consulted.</p>
 */
public final class Resolver {

    private final Repo repo;
    private final JdkMetadata jdk;

    public Resolver(Repo repo, JdkMetadata jdk) {
        this.repo = repo;
        this.jdk = jdk;
    }

    public Repo repo() {
        return repo;
    }

    /** Class lookup: repository first, then the JDK image. */
    public @Nullable ClassInfo findClass(@Nullable String internalName) {
        if (internalName == null) {
            return null;
        }
        ClassInfo info = repo.find(internalName);
        return info != null ? info : jdk.find(internalName);
    }

    /** Whether a class exists in the repository or the JDK image. */
    public boolean exists(String internalName) {
        return findClass(internalName) != null;
    }

    /** Resolved superclass, or {@code null} for {@code Object} / unknown classes. */
    public @Nullable ClassInfo superclassOf(@Nullable ClassInfo info) {
        return info == null || info.superName() == null ? null : findClass(info.superName());
    }

    /** Resolved directly implemented interfaces (unresolvable ones are skipped). */
    public List<ClassInfo> interfacesOf(@Nullable ClassInfo info) {
        List<ClassInfo> result = new ArrayList<>();
        if (info != null) {
            for (String name : info.interfaces()) {
                ClassInfo resolved = findClass(name);
                if (resolved != null) {
                    result.add(resolved);
                }
            }
        }
        return result;
    }

    /** Transitive supertype closure of a class; {@code null} {@code start} yields an empty hierarchy. */
    public Hierarchy hierarchyOf(@Nullable ClassInfo start) {
        Set<String> reachable = new LinkedHashSet<>();
        Set<String> missing = new LinkedHashSet<>();
        Set<String> sides = new LinkedHashSet<>();
        if (start == null) {
            return new Hierarchy(null, reachable, missing, sides);
        }
        Deque<String> queue = new ArrayDeque<>();
        queue.add(start.name());
        reachable.add(start.name());
        if (start.origin() != null) {
            sides.add(start.origin().side());
        }
        while (!queue.isEmpty()) {
            String name = queue.poll();
            ClassInfo info = findClass(name);
            if (info == null) {
                missing.add(name);
                continue;
            }
            if (info.origin() != null) {
                sides.add(info.origin().side());
            }
            List<String> supertypes = new ArrayList<>();
            if (info.superName() != null) {
                supertypes.add(info.superName());
            }
            supertypes.addAll(info.interfaces());
            for (String supertype : supertypes) {
                if (reachable.add(supertype)) {
                    queue.add(supertype);
                }
            }
        }
        return new Hierarchy(start.name(), reachable, missing, sides);
    }

    /** Whether {@code sub} is provably a subtype of {@code candidate}. */
    public boolean isSubtypeOf(@Nullable ClassInfo sub, String candidate) {
        return sub != null && hierarchyOf(sub).contains(candidate);
    }

    /** Whether {@code sub} is a subtype of {@code candidate}, with an explicit unknown state. */
    public Certainty subtypeCertainty(@Nullable ClassInfo sub, String candidate) {
        if (sub == null) {
            return Certainty.UNKNOWN;
        }
        return hierarchyOf(sub).certaintyAbout(candidate);
    }

    // ------------------------------------------------------------------ field resolution

    /**
     * JVMS §5.4.3.2: the declaring class itself, then its superinterfaces (recursively), then its
     * superclass (recursively).
     */
    public Resolution<FieldInfo> resolveField(String owner, String name, String descriptor) {
        Set<String> sides = new LinkedHashSet<>();
        Set<String> missing = new LinkedHashSet<>();
        ClassInfo ownerClass = findClass(owner);
        if (ownerClass == null) {
            return Resolution.ownerMissing(null, owner, sides);
        }
        noteSide(sides, ownerClass);
        Set<String> visited = new LinkedHashSet<>();
        ClassInfo declaring = lookupField(ownerClass, name, descriptor, sides, missing, visited);
        if (declaring != null) {
            FieldInfo field = declaring.findField(name, descriptor);
            return Resolution.resolved(ownerClass, declaring, field, sides);
        }
        if (!missing.isEmpty()) {
            return Resolution.hierarchyMissing(ownerClass, missing.iterator().next(), sides);
        }
        return Resolution.memberMissing(ownerClass, sides);
    }

    private @Nullable ClassInfo lookupField(@Nullable ClassInfo info, String name, String descriptor,
                                            Set<String> sides, Set<String> missing, Set<String> visited) {
        if (info == null || !visited.add(info.name())) {
            return null;
        }
        noteSide(sides, info);
        if (info.findField(name, descriptor) != null) {
            return info;
        }
        for (String interfaceName : info.interfaces()) {
            ClassInfo itf = findClass(interfaceName);
            if (itf == null) {
                missing.add(interfaceName);
                continue;
            }
            ClassInfo found = lookupField(itf, name, descriptor, sides, missing, visited);
            if (found != null) {
                return found;
            }
        }
        if (info.superName() != null) {
            ClassInfo superClass = findClass(info.superName());
            if (superClass == null) {
                missing.add(info.superName());
                return null;
            }
            return lookupField(superClass, name, descriptor, sides, missing, visited);
        }
        return null;
    }

    // ------------------------------------------------------------------ method resolution

    /**
     * JVMS §5.4.3.3 (class flavour, used by {@code invokestatic}, {@code invokevirtual} and
     * {@code invokespecial} with a {@code Methodref}): owner, superclasses, then default methods of
     * the superinterfaces.
     */
    public Resolution<MethodInfo> resolveClassMethod(String owner, String name, String descriptor) {
        Set<String> sides = new LinkedHashSet<>();
        Set<String> missing = new LinkedHashSet<>();
        ClassInfo ownerClass = findClass(owner);
        if (ownerClass == null) {
            return Resolution.ownerMissing(null, owner, sides);
        }
        noteSide(sides, ownerClass);
        ClassInfo current = ownerClass;
        Set<String> guard = new LinkedHashSet<>();
        while (current != null && guard.add(current.name())) {
            noteSide(sides, current);
            MethodInfo method = current.findMethod(name, descriptor);
            if (method != null) {
                return Resolution.resolved(ownerClass, current, method, sides);
            }
            if (current.superName() == null) {
                break;
            }
            ClassInfo superClass = findClass(current.superName());
            if (superClass == null) {
                missing.add(current.superName());
                break;
            }
            current = superClass;
        }
        MethodInfo defaultMethod = lookupInterfaceMethod(ownerClass, name, descriptor, sides, missing,
                new LinkedHashSet<>(), true);
        if (defaultMethod != null) {
            ClassInfo declaring = findClass(defaultMethod.owner());
            return Resolution.resolved(ownerClass, declaring, defaultMethod, sides);
        }
        if (!missing.isEmpty()) {
            return Resolution.hierarchyMissing(ownerClass, missing.iterator().next(), sides);
        }
        return Resolution.memberMissing(ownerClass, sides);
    }

    /**
     * JVMS §5.4.3.4 (interface flavour, used when the constant pool entry is an
     * {@code InterfaceMethodref}): the interface itself, its superinterfaces, then the public
     * instance methods of {@code Object}.
     */
    public Resolution<MethodInfo> resolveInterfaceMethod(String owner, String name, String descriptor) {
        Set<String> sides = new LinkedHashSet<>();
        Set<String> missing = new LinkedHashSet<>();
        ClassInfo ownerClass = findClass(owner);
        if (ownerClass == null) {
            return Resolution.ownerMissing(null, owner, sides);
        }
        noteSide(sides, ownerClass);
        MethodInfo declared = ownerClass.findMethod(name, descriptor);
        if (declared != null) {
            return Resolution.resolved(ownerClass, ownerClass, declared, sides);
        }
        MethodInfo inherited = lookupInterfaceMethod(ownerClass, name, descriptor, sides, missing,
                new LinkedHashSet<>(), false);
        if (inherited != null) {
            return Resolution.resolved(ownerClass, findClass(inherited.owner()), inherited, sides);
        }
        ClassInfo object = findClass("java/lang/Object");
        if (object != null) {
            MethodInfo objectMethod = object.findMethod(name, descriptor);
            if (objectMethod != null && xland.ioutils.jarcompat.model.Access.isPublic(objectMethod.access())
                    && !objectMethod.isStatic()) {
                noteSide(sides, object);
                return Resolution.resolved(ownerClass, object, objectMethod, sides);
            }
        }
        if (!missing.isEmpty()) {
            return Resolution.hierarchyMissing(ownerClass, missing.iterator().next(), sides);
        }
        return Resolution.memberMissing(ownerClass, sides);
    }

    /**
     * Searches the transitive superinterfaces of {@code info}. When {@code onlyNonAbstract} is set
     * (class flavour, step 3 of JVMS §5.4.3.3) only non-abstract, non-static methods are accepted.
     */
    private @Nullable MethodInfo lookupInterfaceMethod(@Nullable ClassInfo info, String name, String descriptor,
                                                       Set<String> sides, Set<String> missing, Set<String> visited,
                                                       boolean onlyNonAbstract) {
        if (info == null) {
            return null;
        }
        for (String interfaceName : info.interfaces()) {
            ClassInfo itf = findClass(interfaceName);
            if (itf == null) {
                missing.add(interfaceName);
                continue;
            }
            if (!visited.add(itf.name())) {
                continue;
            }
            noteSide(sides, itf);
            MethodInfo method = itf.findMethod(name, descriptor);
            if (method != null && (!onlyNonAbstract || (!method.isAbstract() && !method.isStatic()))) {
                return method;
            }
            MethodInfo nested = lookupInterfaceMethod(itf, name, descriptor, sides, missing, visited,
                    onlyNonAbstract);
            if (nested != null) {
                return nested;
            }
        }
        return null;
    }

    private static void noteSide(Set<String> sides, @Nullable ClassInfo info) {
        if (info != null && info.origin() != null && info.origin().side() != null) {
            sides.add(info.origin().side());
        }
    }
}
