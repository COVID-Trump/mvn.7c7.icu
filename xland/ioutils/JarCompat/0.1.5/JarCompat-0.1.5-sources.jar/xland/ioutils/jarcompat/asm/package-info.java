/**
 * Program-side scanning: turns class files into {@code model} entries and extracts every symbolic
 * reference that the JVM may have to link. This is the only package that touches the ASM node tree.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable}. ASM itself is not annotated,
 * so values read out of it are treated as unspecified, never as nullable-by-default.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.asm;

import org.jspecify.annotations.NullMarked;
