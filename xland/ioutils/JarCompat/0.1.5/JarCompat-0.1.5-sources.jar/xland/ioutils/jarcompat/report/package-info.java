/**
 * Report rendering: the human readable text format and the dependency-free JSON format.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable}.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.report;

import org.jspecify.annotations.NullMarked;
