package xland.ioutils.jarcompat.api;

/**
 * How JarCompat decides which references a program can actually execute.
 *
 * <ul>
 *   <li>{@link #ENTRY} (default): a reference is only a <em>definite</em> incompatibility when it
 *       sits in a method that is statically reachable from the entry point
 *       ({@code --entry}/{@code Main-Class}). References in code that never runs — a deprecated
 *       helper that nothing calls, a lambda that is created and dropped — stay potential problems.
 *       This mirrors the JVM, which resolves a constant-pool entry the first time the instruction
 *       executes, and it answers "will this program still run?".</li>
 *   <li>{@link #ALL}: <em>no reachability analysis at all</em> — every class, field and method of the
 *       program counts as an entry point, so every reference that could ever be linked is judged on
 *       its own. This is stricter and answers "does the program still contain any reference that
 *       would fail to link if it were executed?". Use it for CI gates, for programs whose real
 *       entry points cannot be seen statically (reflection, {@code ServiceLoader}, framework
 *       callbacks, JNI, tests, host-loaded plugins) or for program-as-library artifacts.</li>
 * </ul>
 *
 * <p>References that the JVM never resolves — annotations, {@code throws} clauses, nest/inner-class
 * attributes, {@code checkcast}/{@code instanceof} on a {@code null} operand, and the descriptors a
 * class declares for its own fields and methods — are <em>not</em> affected by this setting: they are
 * reported as potential problems in both modes, because no execution of them can raise a
 * {@link LinkageError}.</p>
 */
public enum ReachabilityScope {
    /** Entry-point driven analysis (default): only reachable references are definite problems. */
    ENTRY,
    /** No reachability analysis: every program member counts as an entry point. */
    ALL
}
