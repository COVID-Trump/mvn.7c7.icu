package xland.ioutils.jarcompat;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import xland.ioutils.jarcompat.api.CheckReport;
import xland.ioutils.jarcompat.api.CheckRequest;
import xland.ioutils.jarcompat.api.JarCompat;
import xland.ioutils.jarcompat.api.JarCompatException;
import xland.ioutils.jarcompat.cli.CliOptions;
import xland.ioutils.jarcompat.cli.CliParser;
import xland.ioutils.jarcompat.cli.ExitCodes;
import xland.ioutils.jarcompat.cli.UsageException;

/**
 * Command line entry point.
 *
 * <pre>{@code
 * java -jar build/libs/JarCompat-0.1.0.jar \
 *   --program program-a.jar \
 *   --lib-a lib-a-core.jar --lib-a lib-a-http.jar \
 *   --lib-b lib-b-core.jar --lib-b lib-b-http.jar
 * }</pre>
 *
 * <p>The CLI is a thin wrapper around the public API: it parses the arguments, builds a
 * {@link CheckRequest}, calls {@link JarCompat#check(CheckRequest)} and renders the resulting
 * {@link CheckReport}.</p>
 */
public final class Main {

    private Main() {
    }

    public static void main(String[] args) {
        int code = run(args, System.out, System.err);
        if (code != 0) {
            System.exit(code);
        }
    }

    /**
     * Runs the CLI without calling {@link System#exit(int)}, which makes it testable.
     *
     * @param args command line arguments
     * @param out  standard output stream
     * @param err  standard error stream
     * @return the process exit code
     */
    public static int run(String[] args, PrintStream out, PrintStream err) {
        CliOptions options;
        try {
            options = CliParser.parse(args);
        } catch (UsageException e) {
            err.println("参数错误: " + e.getMessage());
            err.println();
            err.println(CliParser.usage());
            return ExitCodes.USAGE;
        }
        if (options.help()) {
            out.println(CliParser.usage());
            return ExitCodes.OK;
        }
        if (options.version()) {
            out.println(JarCompat.TOOL_NAME + " " + JarCompat.TOOL_VERSION);
            return ExitCodes.OK;
        }

        try {
            CheckRequest request = JarCompat.request()
                    .program(options.programJars().toArray(Path[]::new))
                    .libA(options.libAJars().toArray(Path[]::new))
                    .libB(options.libBJars().toArray(Path[]::new))
                    .entry(options.entryClass())
                    .entryMethod(options.entryMethod())
                    .classpathOrder(options.classpathOrder())
                    .runtimeVersion(options.runtimeVersion())
                    .reachability(options.reachability())
                    .build();
            if (options.reachability() == xland.ioutils.jarcompat.api.ReachabilityScope.ALL
                    && options.entryClass() != null) {
                err.println("提示: --reachability all 下忽略 --entry/--entry-method（所有 program 成员都视为入口）。");
            }
            CheckReport report = JarCompat.check(request);
            String rendered = JarCompat.render(report, options.format());
            out.print(rendered);
            out.flush();
            Path output = options.output();
            if (output != null) {
                Path parent = output.toAbsolutePath().getParent();
                if (parent != null) {
                    Files.createDirectories(parent);
                }
                Files.writeString(output, rendered, StandardCharsets.UTF_8);
                err.println("报告已写入 " + output.toAbsolutePath());
            }
            // Keep stdout machine readable when JSON is requested: the summary goes to stderr.
            if (options.format() == xland.ioutils.jarcompat.api.ReportFormat.TEXT) {
                out.println();
                out.println(summaryLine(report));
            } else {
                err.println(summaryLine(report));
            }
            if (report.errorCount() > 0 && options.failOnError()) {
                return ExitCodes.INCOMPATIBLE;
            }
            return ExitCodes.OK;
        } catch (JarCompatException e) {
            err.println("分析失败: " + e.getMessage());
            return ExitCodes.FAILURE;
        } catch (java.io.IOException e) {
            err.println("无法写入报告: " + e.getMessage());
            return ExitCodes.FAILURE;
        } catch (IllegalArgumentException e) {
            err.println("参数错误: " + e.getMessage());
            return ExitCodes.USAGE;
        } catch (RuntimeException e) {
            err.println("内部错误: " + e);
            return ExitCodes.FAILURE;
        }
    }

    private static String summaryLine(CheckReport report) {
        List<String> parts = List.of(
                "检查结果: " + switch (report.verdict()) {
                    case COMPATIBLE -> "兼容";
                    case INCOMPATIBLE -> "不兼容";
                    case UNKNOWN -> "无法判定";
                },
                "确定不兼容项: " + report.errorCount(),
                "潜在不兼容项: " + report.warningCount(),
                "未发现问题的引用: " + report.compatibleReferenceCount());
        if (report.reachability() == xland.ioutils.jarcompat.api.ReachabilityScope.ALL) {
            return "检查模式: all（全量可达）    " + String.join("    ", parts);
        }
        return String.join("    ", parts);
    }
}
