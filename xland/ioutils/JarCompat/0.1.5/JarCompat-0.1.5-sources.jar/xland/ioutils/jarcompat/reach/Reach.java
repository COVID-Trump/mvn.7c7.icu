package xland.ioutils.jarcompat.reach;

/**
 * How reachable a reference is from the entry point.
 */
public enum Reach {
    /** Statically reachable from the entry method: a broken reference is a definite failure. */
    REACHABLE,
    /** Not reachable from the entry method: a broken reference is only a latent problem. */
    UNREACHABLE,
    /** No entry point was available, so nothing can be said. */
    UNKNOWN
}
