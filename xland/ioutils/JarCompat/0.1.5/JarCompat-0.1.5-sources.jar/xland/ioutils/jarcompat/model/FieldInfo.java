package xland.ioutils.jarcompat.model;

/**
 * A field as declared by a class file.
 */
public record FieldInfo(String owner, String name, String descriptor, int access) {

    /**
     * Internal name of the declaring class.
     */
    @Override
    public String owner() {
        return owner;
    }

    /**
     * Erased field descriptor.
     */
    @Override
    public String descriptor() {
        return descriptor;
    }

    public boolean isStatic() {
        return Access.isStatic(access);
    }

    public boolean isFinal() {
        return Access.isFinal(access);
    }

    /**
     * Lookup key: {@code name:descriptor}.
     */
    public String key() {
        return name + ':' + descriptor;
    }

    /**
     * Human readable declaration, e.g. {@code public static final java.lang.String lib.a.Config.VERSION}.
     */
    public String declaration() {
        return Descriptors.fieldDeclaration(access, owner, name, descriptor);
    }

    @Override
    public String toString() {
        return declaration();
    }

}
