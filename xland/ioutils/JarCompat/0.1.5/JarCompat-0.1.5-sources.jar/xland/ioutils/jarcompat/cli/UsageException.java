package xland.ioutils.jarcompat.cli;

/**
 * Thrown when the command line cannot be parsed; the message is shown to the user.
 */
public final class UsageException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public UsageException(String message) {
        super(message);
    }
}
