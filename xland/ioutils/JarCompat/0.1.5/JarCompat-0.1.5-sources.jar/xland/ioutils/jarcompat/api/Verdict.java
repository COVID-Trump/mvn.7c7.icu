package xland.ioutils.jarcompat.api;

/**
 * Overall outcome of a compatibility check.
 */
public enum Verdict {
    /** No {@link Severity#ERROR} finding: the program links against the new library set. */
    COMPATIBLE,
    /** At least one {@link Severity#ERROR} finding: the program cannot run unchanged. */
    INCOMPATIBLE,
    /**
     * The check could not be carried out (for example no program classes were found). Consult
     * {@link CheckReport#notes()}.
     */
    UNKNOWN
}
