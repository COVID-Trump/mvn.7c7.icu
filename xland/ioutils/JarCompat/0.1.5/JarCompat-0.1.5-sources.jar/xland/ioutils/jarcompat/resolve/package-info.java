/**
 * JVM linkage-time resolution (JVMS §5.4.3) over a logical repository, plus access control and
 * {@code jrt:/} JDK metadata lookup.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable} — a lookup may find nothing,
 * and a resolution may fail to locate the owner, the declaring class or the member.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.resolve;

import org.jspecify.annotations.NullMarked;
