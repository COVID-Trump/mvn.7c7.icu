package xland.ioutils.jarcompat.cli;

import java.nio.file.Path;
import java.util.List;

import org.jspecify.annotations.Nullable;

import xland.ioutils.jarcompat.api.ClasspathOrder;
import xland.ioutils.jarcompat.api.ReachabilityScope;
import xland.ioutils.jarcompat.api.ReportFormat;

/**
 * Parsed command line.
 *
 * @param programJars    {@code --program}, in order
 * @param libAJars       {@code --lib-a}, in order (defines the A-side classpath)
 * @param libBJars       {@code --lib-b}, in order (defines the B-side classpath)
 * @param entryClass     {@code --entry}, or {@code null}
 * @param entryMethod    {@code --entry-method}, {@code main} by default
 * @param classpathOrder {@code --classpath-order}
 * @param output         {@code --output}, or {@code null}
 * @param format         {@code --format}
 * @param failOnError    {@code --fail-on-error}
 * @param reachability   {@code --reachability entry|all}
 * @param runtimeVersion Java version used for multi-release JAR selection
 * @param help           {@code --help} was requested
 * @param version        {@code --version} was requested
 */
public record CliOptions(List<Path> programJars, List<Path> libAJars, List<Path> libBJars,
                         @Nullable String entryClass, String entryMethod, ClasspathOrder classpathOrder,
                         @Nullable Path output, ReportFormat format, boolean failOnError, int runtimeVersion,
                         ReachabilityScope reachability, boolean help, boolean version) {
}
