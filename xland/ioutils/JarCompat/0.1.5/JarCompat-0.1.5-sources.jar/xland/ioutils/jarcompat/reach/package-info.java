/**
 * Conservative static reachability: which program methods can run from the entry point, and which
 * references therefore count as definite incompatibilities.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable} — an entry point is not always
 * known, and references may come from class level metadata without a method context.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.reach;

import org.jspecify.annotations.NullMarked;
