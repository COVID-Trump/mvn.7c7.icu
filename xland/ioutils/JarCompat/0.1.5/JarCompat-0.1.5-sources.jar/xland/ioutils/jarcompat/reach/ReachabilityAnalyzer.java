package xland.ioutils.jarcompat.reach;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LineNumberNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

import org.jspecify.annotations.Nullable;

import xland.ioutils.jarcompat.asm.ProgramIndex;
import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.Descriptors;
import xland.ioutils.jarcompat.model.MethodInfo;
import xland.ioutils.jarcompat.resolve.Resolver;

/**
 * Conservative static reachability analysis.
 *
 * <p>The JVM links lazily: a broken reference only hurts when the instruction that carries it is
 * executed. JarCompat therefore builds the program's internal call graph from an entry point and
 * only marks references inside reachable methods as definite incompatibilities.</p>
 *
 * <p>The call graph is deliberately conservative: virtual and interface calls are propagated to
 * every program subtype of the static receiver type, class initializers of touched classes are
 * included, and calls into libraries are propagated to program overrides.</p>
 */
public final class ReachabilityAnalyzer {

    private final ProgramIndex program;
    private final Resolver runtime;
    private final Set<String> reachable = new LinkedHashSet<>();
    private final Set<String> instantiated = new LinkedHashSet<>();
    private final Deque<String[]> worklist = new ArrayDeque<>();
    private final Map<String, List<String>> subtypeCache = new HashMap<>();
    private final Set<String> initialized = new HashSet<>();
    private @Nullable List<ClassNode> programNodes;

    private ReachabilityAnalyzer(ProgramIndex program, Resolver runtime) {
        this.program = program;
        this.runtime = runtime;
    }

    /**
     * Builds the "all reachable" result used by {@link
     * xland.ioutils.jarcompat.api.ReachabilityScope#ALL}: every program class, field, method (and
     * therefore every class initializer) counts as an entry point, so no call-graph traversal is
     * needed and no reference can be "unreachable".
     *
     * <p>Instantiated classes are still collected, by scanning every program method for
     * {@code new} instructions, because the class-shape checks use that to decide how concrete a
     * finding is — with the whole program considered live, every instantiation counts.</p>
     *
     * @param program scanned program side
     */
    public static Reachability all(ProgramIndex program) {
        Set<String> methods = new LinkedHashSet<>();
        Set<String> classes = new LinkedHashSet<>();
        Set<String> instantiated = new LinkedHashSet<>();
        for (ClassInfo info : program.repo().classes()) {
            classes.add(info.name());
            for (MethodInfo method : info.methods()) {
                methods.add(Reachability.key(info.name(), method.name(), method.descriptor()));
            }
            @Nullable ClassNode node = program.node(info.name());
            if (node == null || node.methods == null) {
                continue;
            }
            for (MethodNode method : node.methods) {
                if (method.instructions == null) {
                    continue;
                }
                for (AbstractInsnNode insn = method.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                    if (insn instanceof TypeInsnNode typeInsn && typeInsn.getOpcode() == Opcodes.NEW) {
                        instantiated.add(typeInsn.desc);
                    }
                }
            }
        }
        return new Reachability(methods, classes, instantiated, true,
                "全量模式（program 的 " + classes.size() + " 个类 / " + methods.size() + " 个方法全部视为入口）",
                null, true);
    }

    /**
     * Analyses reachability starting at {@code entryClass#entryMethod}.
     *
     * @param program      scanned program side
     * @param runtime      resolver over (program ∪ lib-b), used for subtype questions
     * @param entryClass   explicit entry class (dotted or slashed), or {@code null}
     * @param entryMethod  entry method name (usually {@code main})
     */
    public static Reachability analyze(ProgramIndex program, Resolver runtime,
                                       @Nullable String entryClass, String entryMethod) {
        ReachabilityAnalyzer analyzer = new ReachabilityAnalyzer(program, runtime);
        return analyzer.run(entryClass, entryMethod);
    }

    private Reachability run(@Nullable String requestedEntry, String entryMethod) {
        @Nullable String entry = requestedEntry != null ? Descriptors.toInternal(requestedEntry)
                : (program.mainClass() != null ? Descriptors.toInternal(program.mainClass()) : null);
        String source = requestedEntry != null ? "--entry" : "program 的 Main-Class";
        @Nullable String failure = null;
        @Nullable MethodInfo entryPoint = null;

        if (entry == null) {
            failure = "未指定入口类，且 program JAR 的清单中没有 Main-Class 属性";
        } else {
            @Nullable ClassInfo info = program.repo().find(entry);
            if (info == null) {
                failure = "入口类 " + Descriptors.toDotted(entry) + " 不在 program 中（来源：" + source + "）";
            } else {
                entryPoint = pickEntryMethod(info, entryMethod);
                if (entryPoint == null) {
                    failure = "入口类 " + info.dottedName() + " 中找不到方法 " + entryMethod + "（来源：" + source + "）";
                }
            }
        }

        if (entryPoint == null) {
            return new Reachability(Set.of(), Set.of(), Set.of(), false, null, failure, false);
        }

        String description = Descriptors.toDotted(entryPoint.owner()) + "." + entryPoint.name() + entryPoint.descriptor();
        addMethod(entryPoint.owner(), entryPoint.name(), entryPoint.descriptor());
        addClassInitializer(entryPoint.owner());
        drain();

        // Classes with a reachable method are reachable types; their initializers run as well.
        boolean changed = true;
        while (changed) {
            changed = false;
            for (String key : new ArrayList<>(reachable)) {
                String owner = key.substring(0, key.indexOf('#'));
                if (initialized.add(owner)) {
                    changed = true;
                }
                addClassInitializer(owner);
            }
            int before = reachable.size();
            drain();
            if (reachable.size() != before) {
                changed = true;
            }
        }

        return new Reachability(reachable, reachableOwners(), instantiated, true, description, failure, false);
    }

    private Set<String> reachableOwners() {
        Set<String> owners = new LinkedHashSet<>();
        for (String key : reachable) {
            owners.add(key.substring(0, key.indexOf('#')));
        }
        return owners;
    }

    private @Nullable MethodInfo pickEntryMethod(ClassInfo info, String entryMethod) {
        List<MethodInfo> candidates = info.methodsNamed(entryMethod);
        @Nullable MethodInfo fallback = null;
        for (MethodInfo candidate : candidates) {
            if ("([Ljava/lang/String;)V".equals(candidate.descriptor())) {
                return candidate;
            }
            if (fallback == null) {
                fallback = candidate;
            }
        }
        return fallback;
    }

    private void drain() {
        while (!worklist.isEmpty()) {
            String[] method = worklist.poll();
            @Nullable MethodNode node = program.method(method[0], method[1], method[2]);
            if (node == null || node.instructions == null) {
                continue;
            }
            scan(method[0], node);
        }
    }

    private void scan(String owner, MethodNode node) {
        for (AbstractInsnNode insn = node.instructions.getFirst(); insn != null; insn = insn.getNext()) {
            switch (insn) {
                case MethodInsnNode call -> propagateCall(call);
                case TypeInsnNode typeInsn when typeInsn.getOpcode() == Opcodes.NEW -> {
                    // library types are recorded as well: the program decides which receivers exist
                    instantiated.add(typeInsn.desc);
                    addClassInitializer(typeInsn.desc);
                }
                case FieldInsnNode fieldInsn -> {
                    if (fieldInsn.getOpcode() == Opcodes.GETSTATIC || fieldInsn.getOpcode() == Opcodes.PUTSTATIC) {
                        addClassInitializer(fieldInsn.owner);
                    }
                }
                case InvokeDynamicInsnNode indy ->
                    // Creating a lambda resolves the implementation method handle, but the body itself
                    // only runs once the functional method is invoked (or the instance escapes), so the
                    // body is only reachable when the generated instance is actually used.
                        markIndy(indy, node, insn);
                case LdcInsnNode ldc ->
                    // a MethodHandle constant is resolved eagerly, so its target is reachable
                        markConstant(ldc.cst, true);
                default -> {
                }
            }
        }
    }

    /**
     * Lambda bodies ({@code invokedynamic} bootstrap arguments pointing at synthetic program
     * methods) become reachable only when the generated functional object is used: assigned to a
     * local that is read later, passed somewhere, stored or returned. Creating a lambda and dropping
     * it never executes the body, so its references stay "unreachable" (WARN) — exactly like the
     * real JVM, which resolves the body's references lazily.
     */
    private void markIndy(InvokeDynamicInsnNode indy, MethodNode containing, AbstractInsnNode site) {
        boolean used = instanceIsUsed(containing, site);
        if (indy.bsmArgs == null) {
            return;
        }
        for (Object argument : indy.bsmArgs) {
            markConstant(argument, used);
        }
    }

    /**
     * Whether the value produced by an {@code invokedynamic} is consumed. An instance stored into a
     * local that is never read again is dropped; everything else (arguments to calls, field or array
     * stores, returns) counts as escaping and therefore as potentially executed.
     */
    private boolean instanceIsUsed(MethodNode method, AbstractInsnNode site) {
        AbstractInsnNode next = nextRealInstruction(site.getNext());
        if (next == null) {
            return false;
        }
        int opcode = next.getOpcode();
        if (opcode == Opcodes.POP || opcode == Opcodes.POP2) {
            return false;
        }
        if (opcode == Opcodes.ASTORE) {
            int slot = ((VarInsnNode) next).var;
            for (AbstractInsnNode insn = next.getNext(); insn != null; insn = insn.getNext()) {
                if (insn.getOpcode() == Opcodes.ALOAD && ((VarInsnNode) insn).var == slot) {
                    return true;
                }
            }
            return false; // created and dropped
        }
        return true;
    }

    private AbstractInsnNode nextRealInstruction(AbstractInsnNode insn) {
        AbstractInsnNode current = insn;        while ((current instanceof LabelNode || current instanceof LineNumberNode
                || current instanceof FrameNode)) {
            current = current.getNext();
        }
        return current;
    }

    /** Follows a bootstrap handle / constant so that reachable lambda bodies stay reachable. */
    private void markConstant(Object constant, boolean used) {
        if (constant instanceof Handle handle) {
            if (used && program.repo().contains(handle.getOwner())) {
                addMethod(handle.getOwner(), handle.getName(), handle.getDesc());
                addClassInitializer(handle.getOwner());
            }
        } else if (constant instanceof ConstantDynamic dynamic) {
            markConstant(dynamic.getBootstrapMethod(), used);
            for (int i = 0; i < dynamic.getBootstrapMethodArgumentCount(); i++) {
                markConstant(dynamic.getBootstrapMethodArgument(i), used);
            }
        }
    }

    private void propagateCall(MethodInsnNode call) {
        if (call.getOpcode() == Opcodes.INVOKESTATIC || "<init>".equals(call.name)) {
            addClassInitializer(call.owner);
        }
        if (program.repo().contains(call.owner)) {
            addMethod(call.owner, call.name, call.desc);
        }
        // Virtual/interface dispatch: any program subtype may provide the implementation that runs.
        for (String subtype : programSubtypesOf(call.owner)) {
            addMethodIfDeclared(subtype, call.name, call.desc);
        }
    }

    private void addMethodIfDeclared(String owner, String name, String descriptor) {
        @Nullable ClassInfo info = program.repo().find(owner);
        if (info != null && info.findMethod(name, descriptor) != null) {
            addMethod(owner, name, descriptor);
        }
    }

    private void addMethod(String owner, String name, String descriptor) {
        if (owner == null || name == null || descriptor == null) {
            return;
        }
        String key = Reachability.key(owner, name, descriptor);
        if (reachable.add(key)) {
            worklist.add(new String[]{owner, name, descriptor});
        }
    }

    private void addClassInitializer(String className) {
        if (className == null || !program.repo().contains(className)) {
            return;
        }
        @Nullable ClassInfo info = program.repo().find(className);
        if (info.findMethod("<clinit>", "()V") != null) {
            addMethod(className, "<clinit>", "()V");
        }
        // Initializing a class initializes its superclass first.
        if (info.superName() != null && program.repo().contains(info.superName())) {
            addClassInitializer(info.superName());
        }
    }

    /** Program classes that are subtypes of (or equal to) {@code owner}, cached per owner. */
    private List<String> programSubtypesOf(String owner) {
        return subtypeCache.computeIfAbsent(owner, key -> {
            List<String> result = new ArrayList<>();
            ClassInfo ownerInfo = runtime.findClass(key);
            if (ownerInfo == null) {
                return result;
            }
            for (ClassNode node : programNodes()) {
                String candidate = node.name;
                if (candidate.equals(key)) {
                    continue;
                }
                @Nullable ClassInfo candidateInfo = program.repo().find(candidate);
                if (candidateInfo != null && runtime.isSubtypeOf(candidateInfo, key)) {
                    result.add(candidate);
                }
            }
            return result;
        });
    }

    private List<ClassNode> programNodes() {
        List<ClassNode> cached = programNodes;
        if (cached == null) {
            cached = new ArrayList<>();
            for (String className : program.repo().classNames()) {
                @Nullable ClassNode node = program.node(className);
                if (node != null) {
                    cached.add(node);
                }
            }
            programNodes = cached;
        }
        return cached;
    }
}
