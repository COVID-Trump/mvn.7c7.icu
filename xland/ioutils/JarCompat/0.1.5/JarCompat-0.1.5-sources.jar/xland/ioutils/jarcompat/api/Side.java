package xland.ioutils.jarcompat.api;

import java.util.Objects;

import org.jspecify.annotations.Nullable;

/**
 * One side (lib-a or lib-b) of a symbol: which JAR provides it and how it is declared there.
 *
 * <p>Both halves are optional: a classpath hygiene finding has no JAR to point at, and a symbol that
 * was not found has no declaration — see {@link #missing(String, String)}.</p>
 */
public final class Side {
    private final boolean present;
    private final @Nullable String jar;
    private final @Nullable String declaration;

    private Side(boolean present, @Nullable String jar, @Nullable String declaration) {
        this.present = present;
        this.jar = jar;
        this.declaration = declaration;
    }

    /** The symbol was not found on this side; {@code jar} and {@code declaration} may be {@code null}. */
    public static Side missing(@Nullable String jar, @Nullable String declaration) {
        return new Side(false, jar, declaration);
    }

    /** The symbol was found on this side; {@code jar} and {@code declaration} may be {@code null}. */
    public static Side found(@Nullable String jar, @Nullable String declaration) {
        return new Side(true, jar, declaration);
    }

    /** Whether the symbol exists on this side. */
    public boolean present() {
        return present;
    }

    /** File name of the JAR that declares the symbol, or the JAR that was searched. */
    public @Nullable String jar() {
        return jar;
    }

    /** Human readable declaration, e.g. {@code public java.lang.String lib.a.Service.run(int)}. */
    public @Nullable String declaration() {
        return declaration;
    }

    /** Renders as {@code lib-a-core.jar -> public java.lang.String lib.a.Service.run(int)}. */
    public String describe() {
        if (jar == null) {
            return declaration == null ? "(未知)" : declaration;
        }
        return jar + " -> " + (declaration == null ? "(未找到)" : declaration);
    }

    @Override
    public String toString() {
        return describe();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Side other)) {
            return false;
        }
        return present == other.present
                && Objects.equals(jar, other.jar)
                && Objects.equals(declaration, other.declaration);
    }

    @Override
    public int hashCode() {
        return Objects.hash(present, jar, declaration);
    }
}
