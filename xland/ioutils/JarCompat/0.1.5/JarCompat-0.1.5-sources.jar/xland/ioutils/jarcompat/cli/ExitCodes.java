package xland.ioutils.jarcompat.cli;

/**
 * Process exit codes used by {@code xland.ioutils.jarcompat.Main}.
 */
public final class ExitCodes {

    /** Check ran, no definite incompatibility. */
    public static final int OK = 0;
    /** Command line could not be parsed. */
    public static final int USAGE = 1;
    /** Definite incompatibilities were found and {@code --fail-on-error} was requested. */
    public static final int INCOMPATIBLE = 2;
    /** The analysis itself failed (unreadable JAR, duplicate class with {@code classpath-order=error}, ...). */
    public static final int FAILURE = 3;

    private ExitCodes() {
    }
}
