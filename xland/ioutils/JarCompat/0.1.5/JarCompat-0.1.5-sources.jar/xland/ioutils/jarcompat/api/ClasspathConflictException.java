package xland.ioutils.jarcompat.api;

/**
 * Thrown when the same class name is defined by several JARs of one side and
 * {@link ClasspathOrder#ERROR} was requested.
 */
public class ClasspathConflictException extends JarCompatException {
    private static final long serialVersionUID = 1L;

    private final String className;
    private final String first;
    private final String second;

    public ClasspathConflictException(String className, String first, String second) {
        super("duplicate class " + className.replace('/', '.') + ": defined by both '"
                + first + "' and '" + second + "' (classpath-order=error)");
        this.className = className;
        this.first = first;
        this.second = second;
    }

    /** Internal (slash separated) name of the duplicated class. */
    public String className() {
        return className;
    }

    /** JAR that won (the first one in classpath order). */
    public String firstJar() {
        return first;
    }

    /** JAR that was shadowed. */
    public String secondJar() {
        return second;
    }
}
