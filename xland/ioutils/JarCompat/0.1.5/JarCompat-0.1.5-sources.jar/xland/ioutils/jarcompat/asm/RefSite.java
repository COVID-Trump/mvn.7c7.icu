package xland.ioutils.jarcompat.asm;

import org.jspecify.annotations.Nullable;

import xland.ioutils.jarcompat.api.Location;
import xland.ioutils.jarcompat.model.Descriptors;

/**
 * Where a symbolic reference occurs inside the program: JAR, class, method, source line.
 *
 * <p>References extracted from class level metadata (a superclass name, an annotation, a field
 * descriptor) have no enclosing method, hence the nullable {@code methodName} and
 * {@code methodDescriptor}.</p>
 */
public record RefSite(String programJar, String programClass, @Nullable String methodName,
                      @Nullable String methodDescriptor, int line, String detail) {

    /**
     * Name of the enclosing program method, or {@code null} for class level references.
     */
    @Override
    public @Nullable String methodName() {
        return methodName;
    }

    /**
     * Descriptor of the enclosing program method, or {@code null} for class level references.
     */
    @Override
    public @Nullable String methodDescriptor() {
        return methodDescriptor;
    }

    /**
     * Internal name of the program class containing the reference.
     */
    @Override
    public String programClass() {
        return programClass;
    }

    /**
     * 1-based source line, or {@code -1}.
     */
    @Override
    public int line() {
        return line;
    }

    /**
     * What the reference comes from, e.g. {@code "invokevirtual"} or {@code "method signature"}.
     */
    @Override
    public String detail() {
        return detail;
    }

    /**
     * Converts to the public, ASM-free API value object.
     */
    public Location toLocation() {
        return new Location(programJar, Descriptors.toDotted(programClass), methodName, methodDescriptor, line, detail);
    }

    @Override
    public String toString() {
        return toLocation().describe();
    }
}
