/**
 * JAR archive reading: entry selection (nested/fat JAR layouts, multi-release variants) and the
 * manifest subset JarCompat cares about.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable} — a manifest need not declare
 * {@code Main-Class} or {@code Multi-Release}.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.jar;

import org.jspecify.annotations.NullMarked;
