package xland.ioutils.jarcompat.api;

/**
 * Rendering format of a {@link CheckReport}.
 */
public enum ReportFormat {
    /** Human readable, multi-line, aligned blocks. */
    TEXT,
    /** Machine readable JSON document (UTF-8, no external dependencies). */
    JSON
}
