package xland.ioutils.jarcompat.api;

import java.util.Objects;

import org.jspecify.annotations.Nullable;

/**
 * A location inside the analysed program: which JAR, which class, which method, which source line.
 * Immutable value object; never exposes bytecode-library types.
 */
public record Location(String programJar, String className, @Nullable String methodName,
                       @Nullable String methodDescriptor, int line, @Nullable String detail) {
    public Location(String programJar, String className, @Nullable String methodName,
                    @Nullable String methodDescriptor, int line, @Nullable String detail) {
        this.programJar = Objects.requireNonNullElse(programJar, "?");
        this.className = Objects.requireNonNullElse(className, "?");
        this.methodName = methodName;
        this.methodDescriptor = methodDescriptor;
        this.line = line;
        this.detail = detail;
    }

    /**
     * File name of the program JAR the location belongs to.
     */
    @Override
    public String programJar() {
        return programJar;
    }

    /**
     * Binary (dotted) name of the program class.
     */
    @Override
    public String className() {
        return className;
    }

    /**
     * Name of the program method, or {@code null} for class level locations.
     */
    @Override
    public @Nullable String methodName() {
        return methodName;
    }

    /**
     * Erased descriptor of the program method, or {@code null}.
     */
    @Override
    public @Nullable String methodDescriptor() {
        return methodDescriptor;
    }

    /**
     * 1-based source line, or {@code -1} when the class file carries no line number.
     */
    @Override
    public int line() {
        return line;
    }

    /**
     * Free-form explanation of the location, e.g. {@code "superclass declaration"}.
     */
    @Override
    public @Nullable String detail() {
        return detail;
    }

    /**
     * Human readable one-liner used by the text renderer.
     */
    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append(className);
        if (methodName != null) {
            sb.append('.').append(methodName);
            if (methodDescriptor != null) {
                sb.append(methodDescriptor);
            }
        }
        if (line >= 0) {
            sb.append(" 第 ").append(line).append(" 行");
        } else {
            sb.append(" (行号未知)");
        }
        if (detail != null && !detail.isBlank()) {
            sb.append(" — ").append(detail);
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return describe();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Location other)) {
            return false;
        }
        return line == other.line
                && programJar.equals(other.programJar)
                && className.equals(other.className)
                && Objects.equals(methodName, other.methodName)
                && Objects.equals(methodDescriptor, other.methodDescriptor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(programJar, className, methodName, methodDescriptor, line);
    }
}
