/**
 * The check engine: reference re-resolution, class-shape checks and finding accumulation, all driven
 * by {@link xland.ioutils.jarcompat.engine.CompatibilityEngine}.
 *
 * <p>Nullness: this package is {@link org.jspecify.annotations.NullMarked}; every type use is
 * non-null unless it carries {@link org.jspecify.annotations.Nullable}.</p>
 */
@NullMarked
package xland.ioutils.jarcompat.engine;

import org.jspecify.annotations.NullMarked;
