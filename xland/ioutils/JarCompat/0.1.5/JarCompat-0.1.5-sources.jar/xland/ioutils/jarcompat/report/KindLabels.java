package xland.ioutils.jarcompat.report;

import xland.ioutils.jarcompat.api.IncompatibilityKind;

/**
 * Human readable Chinese labels for the finding kinds; used by the text renderer.
 */
final class KindLabels {

    private KindLabels() {
    }

    static String label(IncompatibilityKind kind) {
        return switch (kind) {
            case MISSING_CLASS -> "类缺失";
            case MISSING_METHOD -> "方法缺失";
            case MISSING_FIELD -> "字段缺失";
            case DESCRIPTOR_CHANGED -> "描述符变化";
            case MEMBER_STATIC_MISMATCH -> "static/实例 变化";
            case CLASS_KIND_CHANGED -> "类/接口 种类变化";
            case ACCESS_REDUCED -> "访问权限降低";
            case FINAL_VIOLATION -> "final 约束冲突";
            case ABSTRACT_METHOD_MISSING -> "抽象方法未实现";
            case SUPERCLASS_INCOMPATIBLE -> "继承关系不兼容";
            case HIERARCHY_RELATION_LOST -> "子类型关系丢失";
            case UNRESOLVED_IN_A -> "A 侧即无法解析";
            case DUPLICATE_CLASS -> "重复类名";
            case SEALED_PACKAGE_SPLIT -> "sealed 包被拆分";
            case NESTED_JAR -> "nested JAR（已跳过）";
            case MULTI_RELEASE -> "多版本 JAR";
            case UNREACHABLE_REFERENCE -> "不可达引用";
            case REACHABILITY_UNKNOWN -> "可达性未知";
            case DYNAMIC_CALLS_NOT_COVERED -> "未覆盖的动态调用";
            case EXTERNAL_DEPENDENCY_UNCHECKED -> "外部依赖未检查";
            case NOTE -> "说明";
        };
    }
}
