package xland.ioutils.jarcompat.asm;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.objectweb.asm.tree.ClassNode;

import xland.ioutils.jarcompat.api.ClasspathOrder;
import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.jar.JarScanner;
import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.ClassOrigin;
import xland.ioutils.jarcompat.model.Repo;
import xland.ioutils.jarcompat.model.RepoBuilder;
import xland.ioutils.jarcompat.model.ScanIssue;

/**
 * Scans the program side: merges the program JARs into one logical repository, keeps the parsed
 * class nodes and extracts every symbolic reference (with line numbers).
 */
public final class ProgramScanner {

    private ProgramScanner() {
    }

    /** Scans the program JARs in classpath order. */
    public static ProgramIndex scan(List<Path> jars, ClasspathOrder order, int runtimeVersion) {
        RepoBuilder repoBuilder = new RepoBuilder(ClassOrigin.PROGRAM, order);
        Map<String, ClassNode> nodes = new LinkedHashMap<>();
        Map<String, List<SymbolicRef>> references = new LinkedHashMap<>();
        List<ScanIssue> issues = new ArrayList<>();

        JarScanner.Request request = new JarScanner.Request(jars, ClassOrigin.PROGRAM, runtimeVersion);
        JarScanner.ScanReport report = JarScanner.scan(request, (internalName, bytes, origin) -> {
            repoBuilder.jar(origin.jar());
            ClassNode node;
            try {
                node = ClassInfoReader.readNode(bytes, ClassInfoReader.FULL);
            } catch (IllegalArgumentException e) {
                issues.add(ScanIssue.warn(IncompatibilityKind.NOTE,
                        "无法解析 program 中的 class 文件 " + internalName.replace('/', '.') + " ("
                                + origin.jar() + "): " + e.getMessage() + "；该类被跳过。", origin.jar()));
                return;
            }
            ClassInfo info = ClassInfoReader.fromNode(node, origin);
            repoBuilder.add(info);
            nodes.put(info.name(), node);
            references.put(info.name(), ReferenceCollector.collect(node, origin.jar()));
        });

        Repo repo = repoBuilder.build();
        issues.addAll(repoBuilder.issues());
        issues.addAll(report.issues());
        return new ProgramIndex(repo, nodes, references, issues, report.mainClass(), report.jars());
    }
}
