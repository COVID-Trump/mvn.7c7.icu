package xland.ioutils.jarcompat.model;

import java.util.Objects;

/**
 * Where a class came from: which side (program / lib-a / lib-b / JDK), which JAR (or {@code jrt:}
 * module) and which archive entry.
 */
public record ClassOrigin(String side, String jar, String path, String entry) {

    /**
     * Side labels used throughout the tool.
     */
    public static final String PROGRAM = "program";
    public static final String LIB_A = "lib-a";
    public static final String LIB_B = "lib-b";
    public static final String JDK = "jdk";

    /**
     * Creates an origin for a class read from the current JDK image.
     */
    public static ClassOrigin jdk(String module, String entry) {
        return new ClassOrigin(JDK, "jrt:/" + module, "jrt:/" + module, entry);
    }

    /**
     * One of {@link #PROGRAM}, {@link #LIB_A}, {@link #LIB_B}, {@link #JDK}.
     */
    @Override
    public String side() {
        return side;
    }

    /**
     * File name of the originating JAR (e.g. {@code lib-a-core.jar}).
     */
    @Override
    public String jar() {
        return jar;
    }

    /**
     * Path the user passed in (kept verbatim for diagnostics).
     */
    @Override
    public String path() {
        return path;
    }

    /**
     * Archive entry, e.g. {@code com/foo/Bar.class} or {@code META-INF/versions/17/com/foo/Bar.class}.
     */
    @Override
    public String entry() {
        return entry;
    }

    public boolean isJdk() {
        return JDK.equals(side);
    }

    @Override
    public String toString() {
        return jar + "!" + entry;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ClassOrigin other)) {
            return false;
        }
        return Objects.equals(side, other.side) && Objects.equals(jar, other.jar)
                && Objects.equals(entry, other.entry);
    }

    @Override
    public int hashCode() {
        return Objects.hash(side, jar, entry);
    }
}
