module com.hixland.jarcompat {
    exports xland.ioutils.jarcompat.api;

    // Internal dependencies
    requires transitive org.objectweb.asm;
    requires transitive org.objectweb.asm.tree;
    requires transitive com.grack.nanojson;

    // JSpecify nullness annotations: class-file retention and compile-time only, so the module is
    // optional at run time (the dependency is declared `compileOnly` in build.gradle.kts).
    requires static org.jspecify;
}
