package xland.ioutils.jarcompat.asm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

import xland.ioutils.jarcompat.model.Repo;
import xland.ioutils.jarcompat.model.ScanIssue;

/**
 * The scanned program side: its merged repository, the parsed class nodes (kept internal to the
 * analysis) and every extracted symbolic reference.
 */
public final class ProgramIndex {

    private final Repo repo;
    private final Map<String, ClassNode> nodes;
    private final Map<String, List<SymbolicRef>> references;
    private final List<ScanIssue> issues;
    private final String mainClass;
    private final List<String> jars;

    ProgramIndex(Repo repo, Map<String, ClassNode> nodes, Map<String, List<SymbolicRef>> references,
                 List<ScanIssue> issues, String mainClass, List<String> jars) {
        this.repo = repo;
        this.nodes = Map.copyOf(nodes);
        this.references = Map.copyOf(references);
        this.issues = List.copyOf(issues);
        this.mainClass = mainClass;
        this.jars = List.copyOf(jars);
    }

    /** Merged program repository, indexed by internal class name. */
    public Repo repo() {
        return repo;
    }

    /** Program JAR file names, in classpath order. */
    public List<String> jars() {
        return jars;
    }

    /** {@code Main-Class} of the first program JAR that declares one, or {@code null}. */
    public String mainClass() {
        return mainClass;
    }

    /** Parsed class node of a program class, or {@code null}. */
    public ClassNode node(String className) {
        return nodes.get(className);
    }

    /** All references of all program classes. */
    public List<SymbolicRef> references() {
        List<SymbolicRef> all = new ArrayList<>();
        references.values().forEach(all::addAll);
        return all;
    }

    /** References of one program class. */
    public List<SymbolicRef> referencesOf(String className) {
        return references.getOrDefault(className, List.of());
    }

    /** Program class names, in classpath order. */
    public List<String> classNames() {
        return new ArrayList<>(repo.classNames());
    }

    /** Looks a method up in the parsed program classes. */
    public MethodNode method(String owner, String name, String descriptor) {
        ClassNode node = nodes.get(owner);
        if (node == null || node.methods == null) {
            return null;
        }
        for (MethodNode method : node.methods) {
            if (method.name.equals(name) && method.desc.equals(descriptor)) {
                return method;
            }
        }
        return null;
    }

    /** Issues discovered while scanning the program side. */
    public List<ScanIssue> issues() {
        return issues;
    }
}
