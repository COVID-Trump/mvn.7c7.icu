package xland.ioutils.jarcompat.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * A logical repository: the merge of one or more JARs indexed by class name.
 *
 * <p>This is the central abstraction of JarCompat: the JVM sees a flat classpath, not a set of
 * named JARs, so every side (program, lib-a, lib-b) is flattened into a {@code Map<String, ClassInfo>}
 * before any resolution happens. Class pairing between JARs is never required — classes may move
 * between JARs, JARs may be split or merged, only class names and shapes matter.</p>
 */
public final class Repo {

    private final String label;
    private final Map<String, ClassInfo> classes;
    private final List<String> jars;

    public Repo(String label, Map<String, ClassInfo> classes, List<String> jars) {
        this.label = label;
        this.classes = Collections.unmodifiableMap(new LinkedHashMap<>(classes));
        this.jars = List.copyOf(jars);
    }

    /** Label of the side, e.g. {@code A}, {@code B}, {@code program}. */
    public String label() {
        return label;
    }

    /** JAR file names of this repository, in classpath order. */
    public List<String> jars() {
        return jars;
    }

    /** Looks a class up by internal name; {@code null} when absent. */
    public ClassInfo find(String internalName) {
        return classes.get(internalName);
    }

    public boolean contains(String internalName) {
        return classes.containsKey(internalName);
    }

    public Collection<ClassInfo> classes() {
        return classes.values();
    }

    public Set<String> classNames() {
        return classes.keySet();
    }

    public int size() {
        return classes.size();
    }

    public boolean isEmpty() {
        return classes.isEmpty();
    }

    /**
     * Merges two repositories. Classes of {@code first} take precedence when a name is defined on
     * both sides (this mirrors classpath order: the first JAR wins) and the collision is reported
     * through {@code collisions}.
     */
    public static Repo merge(String label, Repo first, Repo second, List<String> collisions) {
        Map<String, ClassInfo> merged = new LinkedHashMap<>(first.classes);
        for (Map.Entry<String, ClassInfo> e : second.classes.entrySet()) {
            ClassInfo existing = merged.putIfAbsent(e.getKey(), e.getValue());
            if (existing != null && collisions != null) {
                String message = e.getKey().replace('/', '.') + ": "
                        + existing.originJar() + " (kept) shadows " + e.getValue().originJar();
                if (!collisions.contains(message)) {
                    collisions.add(message);
                }
            }
        }
        List<String> jars = new ArrayList<>(first.jars);
        for (String jar : second.jars) {
            if (!jars.contains(jar)) {
                jars.add(jar);
            }
        }
        return new Repo(label, merged, jars);
    }

    @Override
    public String toString() {
        return "Repo[" + label + ", " + classes.size() + " classes from " + jars + "]";
    }
}
