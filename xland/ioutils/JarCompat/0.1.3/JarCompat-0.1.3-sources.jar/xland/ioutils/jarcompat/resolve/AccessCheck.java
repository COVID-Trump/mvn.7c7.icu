package xland.ioutils.jarcompat.resolve;

import xland.ioutils.jarcompat.model.Access;
import xland.ioutils.jarcompat.model.ClassInfo;

/**
 * JVM access control (JVMS §5.4.4) over a logical repository.
 *
 * <p>Rules implemented:</p>
 * <ul>
 *   <li>{@code public}: accessible everywhere;</li>
 *   <li>{@code private}: only inside the declaring class (and its nestmates);</li>
 *   <li>{@code protected}: same package, or a subclass of the declaring class;</li>
 *   <li>package-private: same package only.</li>
 * </ul>
 *
 * <p>Everything runs on one flat classpath, hence a single runtime package namespace: same package
 * name means same runtime package.</p>
 */
public final class AccessCheck {

    private AccessCheck() {
    }

    /** Class access (JVMS §5.4.4, "class access"). */
    public static Certainty classAccess(Resolver resolver, ClassInfo from, ClassInfo target) {
        if (from == null || target == null) {
            return Certainty.UNKNOWN;
        }
        if (target.isPublic()) {
            return Certainty.YES;
        }
        if (samePackage(from, target)) {
            return Certainty.YES;
        }
        if (target.isPrivate()) {
            return isNestmate(resolver, from, target) ? Certainty.YES : Certainty.NO;
        }
        if (target.isProtected()) {
            if (target.nestHost() == null) {
                return Certainty.UNKNOWN;
            }
            return resolver.subtypeCertainty(from, target.nestHost());
        }
        // package-private
        return Certainty.NO;
    }

    /** Member access (JVMS §5.4.4, "field and method access"). */
    public static Certainty memberAccess(Resolver resolver, ClassInfo from, ClassInfo declaring, int memberAccess) {
        if (from == null || declaring == null) {
            return Certainty.UNKNOWN;
        }
        if (Access.isPublic(memberAccess)) {
            return Certainty.YES;
        }
        if (Access.isPrivate(memberAccess)) {
            if (from.name().equals(declaring.name())) {
                return Certainty.YES;
            }
            return isNestmate(resolver, from, declaring) ? Certainty.YES : Certainty.NO;
        }
        if (Access.isPackagePrivate(memberAccess)) {
            return samePackage(from, declaring) ? Certainty.YES : Certainty.NO;
        }
        // protected
        if (samePackage(from, declaring)) {
            return Certainty.YES;
        }
        return resolver.subtypeCertainty(from, declaring.name());
    }

    /** Whether two classes belong to the same runtime package (same package name, flat classpath). */
    public static boolean samePackage(ClassInfo a, ClassInfo b) {
        return a.packageName().equals(b.packageName());
    }

    /** Whether two classes are nestmates (Java 11+ nest-based access control). */
    public static boolean isNestmate(Resolver resolver, ClassInfo a, ClassInfo b) {
        if (a.name().equals(b.name())) {
            return true;
        }
        String hostA = nestHostOf(a);
        String hostB = nestHostOf(b);
        return hostA != null && hostA.equals(hostB);
    }

    private static String nestHostOf(ClassInfo info) {
        if (info.nestHost() != null) {
            return info.nestHost();
        }
        return info.name();
    }
}
