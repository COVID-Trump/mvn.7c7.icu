package xland.ioutils.jarcompat.cli;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import xland.ioutils.jarcompat.api.ClasspathOrder;
import xland.ioutils.jarcompat.api.ReachabilityScope;
import xland.ioutils.jarcompat.api.ReportFormat;

/**
 * Hand written command line parser.
 *
 * <p>{@code --program}, {@code --lib-a} and {@code --lib-b} may be repeated; their relative order is
 * preserved and defines the classpath order of each side (JarCompat never sorts the inputs, because
 * the order decides which duplicate class wins — exactly like the JVM).</p>
 */
public final class CliParser {

    private CliParser() {
    }

    /** Parses {@code args}; throws {@link UsageException} on malformed input. */
    public static CliOptions parse(String[] args) {
        List<Path> program = new ArrayList<>();
        List<Path> libA = new ArrayList<>();
        List<Path> libB = new ArrayList<>();
        String entry = null;
        String entryMethod = "main";
        ClasspathOrder order = ClasspathOrder.FIRST_WINS;
        Path output = null;
        ReportFormat format = ReportFormat.TEXT;
        boolean failOnError = false;
        int runtimeVersion = Runtime.version().feature();
        ReachabilityScope reachability = ReachabilityScope.ENTRY;
        boolean help = false;
        boolean version = false;

        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            switch (arg) {
                case "--program" -> program.add(Path.of(value(args, ++i, arg)));
                case "--lib-a" -> libA.add(Path.of(value(args, ++i, arg)));
                case "--lib-b" -> libB.add(Path.of(value(args, ++i, arg)));
                case "--entry" -> entry = value(args, ++i, arg);
                case "--entry-method" -> entryMethod = value(args, ++i, arg);
                case "--output" -> output = Path.of(value(args, ++i, arg));
                case "--classpath-order" -> order = parseOrder(value(args, ++i, arg));
                case "--format" -> format = parseFormat(value(args, ++i, arg));
                case "--runtime-version" -> runtimeVersion = parseVersion(value(args, ++i, arg));
                case "--reachability" -> reachability = parseReachability(value(args, ++i, arg));
                case "--fail-on-error" -> failOnError = true;
                case "--help", "-h" -> help = true;
                case "--version", "-V" -> version = true;
                default -> throw new UsageException("未知参数: " + arg);
            }
        }
        if (!help && !version) {
            if (program.isEmpty()) {
                throw new UsageException("缺少 --program <program-a.jar>");
            }
            if (libA.isEmpty()) {
                throw new UsageException("缺少 --lib-a <lib-a.jar>（可重复）");
            }
            if (libB.isEmpty()) {
                throw new UsageException("缺少 --lib-b <lib-b.jar>（可重复）");
            }
        }
        return new CliOptions(program, libA, libB, entry, entryMethod, order, output, format, failOnError,
                runtimeVersion, reachability, help, version);
    }

    private static String value(String[] args, int index, String option) {
        if (index >= args.length) {
            throw new UsageException("参数 " + option + " 缺少取值");
        }
        String value = args[index];
        if (value.startsWith("--")) {
            throw new UsageException("参数 " + option + " 缺少取值（后面跟的是 " + value + "）");
        }
        return value;
    }

    private static ReachabilityScope parseReachability(String raw) {
        return switch (raw.toLowerCase(Locale.ROOT)) {
            case "entry", "entry-driven", "entry_driven" -> ReachabilityScope.ENTRY;
            case "all", "all-reachable", "all_reachable", "whole-program", "whole_program",
                 "all-entrypoints", "all_entrypoints" -> ReachabilityScope.ALL;
            default -> throw new UsageException("非法的 --reachability 取值: " + raw
                    + "（可选 entry | all）");
        };
    }

    private static ClasspathOrder parseOrder(String raw) {
        return switch (raw.toLowerCase(Locale.ROOT)) {
            case "first-wins", "first_wins" -> ClasspathOrder.FIRST_WINS;
            case "strict" -> ClasspathOrder.STRICT;
            case "error" -> ClasspathOrder.ERROR;
            default -> throw new UsageException("非法的 --classpath-order 取值: " + raw
                    + "（可选 first-wins | strict | error）");
        };
    }

    private static ReportFormat parseFormat(String raw) {
        return switch (raw.toLowerCase(Locale.ROOT)) {
            case "text" -> ReportFormat.TEXT;
            case "json" -> ReportFormat.JSON;
            default -> throw new UsageException("非法的 --format 取值: " + raw + "（可选 text | json）");
        };
    }

    private static int parseVersion(String raw) {
        try {
            int value = Integer.parseInt(raw);
            if (value < 1) {
                throw new UsageException("--runtime-version 必须 >= 1");
            }
            return value;
        } catch (NumberFormatException e) {
            throw new UsageException("非法的 --runtime-version 取值: " + raw);
        }
    }

    /** The usage text shown by {@code --help}. */
    public static String usage() {
        return """
                JarCompat — JAR Binary Compatibility Checker

                用法:
                  java -jar JarCompat-0.1.0.jar --program <program-a.jar>
                        --lib-a <jar> [--lib-a <jar> ...]
                        --lib-b <jar> [--lib-b <jar> ...]
                        [--entry <class>] [--entry-method <name>] [--classpath-order <mode>]
                        [--format <text|json>] [--output <path>] [--fail-on-error]

                参数:
                  --program <path>          program-a.jar（可重复，按顺序构成 program classpath）
                  --lib-a <path>            旧库 JAR（可重复，按传入顺序构成 A 侧 classpath）
                  --lib-b <path>            新库 JAR（可重复，按传入顺序构成 B 侧 classpath）
                  --entry <class>           program 入口类（缺省时读取 program JAR 的 Main-Class）
                  --entry-method <name>     入口方法名，默认 main
                  --classpath-order <mode>  重复类名策略: first-wins（默认）| strict | error
                  --output <path>           额外把报告写入文件（UTF-8）
                  --format <text|json>      报告格式，默认 text
                  --runtime-version <n>     多版本 JAR 选择时使用的 Java 版本，默认当前运行版本
                  --reachability <mode>     可达性策略：entry（默认，从入口做调用图分析，不可达引用只报 WARN）
                                            | all（全量：program 的所有 class/field/method 都视为入口，跳过可达性分析）
                  --fail-on-error           发现确定不兼容项时以退出码 2 结束
                  --help, -h                显示本帮助
                  --version, -V             显示版本

                退出码:
                  0 检查完成（未发现确定不兼容项）
                  1 命令行错误
                  2 发现确定不兼容项且指定了 --fail-on-error
                  3 分析失败（JAR 无法读取等）

                说明:
                  --reachability all 回答的是“program 里是否还存在无法链接的引用”，因此死代码中的坏引用也会报 ERROR；
                  它适合 CI 门禁、入口静态不可见的 program（反射/ServiceLoader/框架回调/JNI/测试）以及“program 作为库”的场景。
                  注解、throws、nest/inner 属性、checkcast 的 null 操作数、以及类自身声明的字段/方法描述符不是常量池符号引用，
                  两种模式下都只报 WARN。

                  JVM 看到的是一条扁平的 classpath，因此 lib-a 与 lib-b 之间不需要一一对应：
                  类可以在 JAR 之间搬家、JAR 可以拆分或合并，只要类名与形状不变就是兼容的。
                  工具不会对输入 JAR 排序，--lib-a/--lib-b 的传入顺序即 classpath 顺序。
                """;
    }
}
