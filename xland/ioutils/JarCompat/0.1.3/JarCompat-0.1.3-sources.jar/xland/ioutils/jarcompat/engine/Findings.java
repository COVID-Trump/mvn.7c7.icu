package xland.ioutils.jarcompat.engine;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import xland.ioutils.jarcompat.api.Incompatibility;
import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.Location;
import xland.ioutils.jarcompat.api.Severity;
import xland.ioutils.jarcompat.api.Side;

/**
 * Accumulates findings, grouping identical problems (same kind + same symbol) so that a method
 * referenced from twenty call sites is reported once, with all its program locations.
 *
 * <p>Also keeps the reference counters used by the report summary.</p>
 */
final class Findings {

    private static final int MAX_LOCATIONS = 12;

    private final Map<String, MutableItem> items = new LinkedHashMap<>();
    private int compatibleReferences;
    private int checkedReferences;
    private int externalReferences;

    /** Starts a new finding; chain the setters and finish with {@link Item#submit()}. */
    Item item(IncompatibilityKind kind, Severity severity, String symbol) {
        return new Item(this, kind, severity, symbol);
    }

    void compatibleReference() {
        compatibleReferences++;
    }

    void checkedReference() {
        checkedReferences++;
    }

    void externalReference() {
        externalReferences++;
    }

    int compatibleReferences() {
        return compatibleReferences;
    }

    int checkedReferences() {
        return checkedReferences;
    }

    int externalReferences() {
        return externalReferences;
    }

    private void submit(Item item) {
        String key = item.kind + "|" + item.symbol + "|" + item.expectedError;
        MutableItem existing = items.get(key);
        if (existing == null) {
            items.put(key, new MutableItem(item));
            return;
        }
        existing.merge(item);
    }

    List<Incompatibility> toIncompatibilities() {
        List<Incompatibility> result = new ArrayList<>(items.size());
        for (MutableItem item : items.values()) {
            result.add(item.toIncompatibility());
        }
        return result;
    }

    /** Fluent description of one finding. */
    static final class Item {
        private final Findings owner;
        private final IncompatibilityKind kind;
        private Severity severity;
        private final String symbol;
        private final List<Location> locations = new ArrayList<>();
        private int occurrences;
        private Side sideA;
        private Side sideB;
        private String reason;
        private String suggestion;
        private String expectedError;
        private String expectedMessage;

        Item(Findings owner, IncompatibilityKind kind, Severity severity, String symbol) {
            this.owner = owner;
            this.kind = kind;
            this.severity = severity;
            this.symbol = symbol;
        }

        Item at(Location location) {
            if (location != null && !locations.contains(location) && locations.size() < MAX_LOCATIONS) {
                locations.add(location);
            }
            occurrences++;
            return this;
        }

        Item at(xland.ioutils.jarcompat.asm.SymbolicRef ref) {
            return ref == null || ref.site() == null ? this : at(ref.site().toLocation());
        }

        Item severity(Severity severity) {
            if (severity.ordinal() < this.severity.ordinal()) {
                this.severity = severity;
            }
            return this;
        }

        Item sideA(Side sideA) {
            this.sideA = sideA;
            return this;
        }

        Item sideA(String jar, String declaration) {
            return sideA(declaration == null ? Side.missing(jar, null) : Side.found(jar, declaration));
        }

        Item sideB(Side sideB) {
            this.sideB = sideB;
            return this;
        }

        Item sideB(String jar, String declaration) {
            return sideB(declaration == null ? Side.missing(jar, null) : Side.found(jar, declaration));
        }

        Item reason(String reason) {
            this.reason = reason;
            return this;
        }

        Item suggestion(String suggestion) {
            this.suggestion = suggestion;
            return this;
        }

        Item expected(String error, String message) {
            this.expectedError = error;
            this.expectedMessage = message;
            return this;
        }

        void submit() {
            owner.submit(this);
        }
    }

    private static final class MutableItem {
        private IncompatibilityKind kind;
        private Severity severity;
        private String symbol;
        private final List<Location> locations = new ArrayList<>();
        private int occurrences;
        private Side sideA;
        private Side sideB;
        private String reason;
        private String suggestion;
        private String expectedError;
        private String expectedMessage;

        MutableItem(Item item) {
            this.kind = item.kind;
            this.severity = item.severity;
            this.symbol = item.symbol;
            this.locations.addAll(item.locations);
            this.occurrences = Math.max(item.occurrences, item.locations.size());
            this.sideA = item.sideA;
            this.sideB = item.sideB;
            this.reason = item.reason;
            this.suggestion = item.suggestion;
            this.expectedError = item.expectedError;
            this.expectedMessage = item.expectedMessage;
        }

        void merge(Item item) {
            if (item.severity.ordinal() < severity.ordinal()) {
                severity = item.severity;
            }
            if (item.reason != null && (reason == null || item.reason.length() > reason.length())) {
                reason = item.reason;
            }
            if (item.suggestion != null && suggestion == null) {
                suggestion = item.suggestion;
            }
            if (sideA == null) {
                sideA = item.sideA;
            }
            if (sideB == null) {
                sideB = item.sideB;
            }
            for (Location location : item.locations) {
                if (locations.size() < MAX_LOCATIONS && !locations.contains(location)) {
                    locations.add(location);
                }
            }
            occurrences += Math.max(item.occurrences, item.locations.size());
        }

        Incompatibility toIncompatibility() {
            Incompatibility.Builder builder = new Incompatibility.Builder()
                    .kind(kind)
                    .severity(severity)
                    .symbol(symbol)
                    .locations(locations)
                    .occurrences(occurrences)
                    .sideA(sideA)
                    .sideB(sideB)
                    .reason(reason)
                    .suggestion(suggestion)
                    .expectedError(expectedError)
                    .expectedMessage(expectedMessage);
            return builder.build();
        }
    }
}
