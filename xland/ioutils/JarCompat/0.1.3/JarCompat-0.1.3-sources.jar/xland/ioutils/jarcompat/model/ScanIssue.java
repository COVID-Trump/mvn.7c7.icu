package xland.ioutils.jarcompat.model;

import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.Severity;

/**
 * A problem detected while reading the inputs (duplicate class, nested JAR, sealed package split,
 * multi-release override, ...). Not a program/lib-a/lib-b linkage problem, but worth reporting.
 */
public record ScanIssue(Severity severity, IncompatibilityKind kind, String message, String symbol, String jar) {

    public static ScanIssue warn(IncompatibilityKind kind, String message, String jar) {
        return new ScanIssue(Severity.WARN, kind, message, null, jar);
    }

    public static ScanIssue error(IncompatibilityKind kind, String message, String jar) {
        return new ScanIssue(Severity.ERROR, kind, message, null, jar);
    }

    public static ScanIssue info(IncompatibilityKind kind, String message, String jar) {
        return new ScanIssue(Severity.INFO, kind, message, null, jar);
    }

    /**
     * Groups equal issues so that repeated discoveries are reported once.
     */
    public String groupKey() {
        return severity + "|" + kind + "|" + message;
    }

    @Override
    public String toString() {
        return "[" + severity + "] " + message;
    }
}
