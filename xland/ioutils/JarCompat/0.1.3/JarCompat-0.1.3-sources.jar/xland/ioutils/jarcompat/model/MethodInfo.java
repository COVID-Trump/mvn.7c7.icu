package xland.ioutils.jarcompat.model;

import java.util.List;
import java.util.Objects;

/**
 * A method (or constructor) as declared by a class file.
 */
public record MethodInfo(String owner, String name, String descriptor, int access, List<String> exceptions) {
    public MethodInfo {
        exceptions = List.copyOf(exceptions == null ? List.of() : exceptions);
    }

    /**
     * Internal name of the declaring class.
     */
    @Override
    public String owner() {
        return owner;
    }

    /**
     * Erased method descriptor.
     */
    @Override
    public String descriptor() {
        return descriptor;
    }

    /**
     * Declared checked exceptions (internal names).
     */
    @Override
    public List<String> exceptions() {
        return exceptions;
    }

    public boolean isStatic() {
        return Access.isStatic(access);
    }

    public boolean isAbstract() {
        return Access.isAbstract(access);
    }

    public boolean isBridge() {
        return Access.isBridge(access);
    }

    public boolean isSynthetic() {
        return Access.isSynthetic(access);
    }

    public boolean isConstructor() {
        return "<init>".equals(name);
    }

    public boolean isClassInitializer() {
        return "<clinit>".equals(name);
    }

    /**
     * Lookup key: {@code name+descriptor}.
     */
    public String key() {
        return name + descriptor;
    }

    /**
     * Human readable declaration, e.g. {@code public java.lang.String lib.a.Service.run(int)}.
     */
    public String declaration() {
        return Descriptors.methodDeclaration(access, owner, name, descriptor);
    }

    @Override
    public String toString() {
        return declaration();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MethodInfo other)) {
            return false;
        }
        return access == other.access && owner.equals(other.owner) && name.equals(other.name)
                && descriptor.equals(other.descriptor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(owner, name, descriptor, access);
    }
}
