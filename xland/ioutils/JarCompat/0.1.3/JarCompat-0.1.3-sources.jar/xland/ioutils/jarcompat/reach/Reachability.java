package xland.ioutils.jarcompat.reach;

import java.util.Set;

import xland.ioutils.jarcompat.asm.RefSite;
import xland.ioutils.jarcompat.asm.SymbolicRef;

/**
 * Result of the conservative static reachability analysis: which program methods can run when the
 * program starts at the entry point, and which program types get instantiated.
 */
public final class Reachability {

    private final Set<String> reachableMethods;
    private final Set<String> reachableClasses;
    private final Set<String> instantiatedClasses;
    private final boolean entryKnown;
    private final String entryDescription;
    private final String entryFailureReason;
    private final boolean allReachable;

    Reachability(Set<String> reachableMethods, Set<String> reachableClasses, Set<String> instantiatedClasses,
                 boolean entryKnown, String entryDescription, String entryFailureReason,
                 boolean allReachable) {
        this.reachableMethods = Set.copyOf(reachableMethods);
        this.reachableClasses = Set.copyOf(reachableClasses);
        this.instantiatedClasses = Set.copyOf(instantiatedClasses);
        this.entryKnown = entryKnown;
        this.entryDescription = entryDescription;
        this.entryFailureReason = entryFailureReason;
        this.allReachable = allReachable;
    }

    /**
     * Whether the whole program was treated as an entry point ({@link
     * xland.ioutils.jarcompat.api.ReachabilityScope#ALL}): no reachability analysis happened, so
     * every reference is reachable by construction.
     */
    public boolean allReachable() {
        return allReachable;
    }

    /** Whether an entry point could be determined. */
    public boolean entryKnown() {
        return entryKnown;
    }

    /** Human readable entry point, e.g. {@code com.example.Main.main([Ljava/lang/String;)V}. */
    public String entryDescription() {
        return entryDescription;
    }

    /** Why no entry point was found; {@code null} when the entry is known. */
    public String entryFailureReason() {
        return entryFailureReason;
    }

    /** Reachable program methods, keyed {@code owner#name+descriptor}. */
    public Set<String> reachableMethods() {
        return reachableMethods;
    }

    /** Program classes with at least one reachable method. */
    public Set<String> reachableClasses() {
        return reachableClasses;
    }

    /** Classes (program or library) instantiated by a reachable {@code new} instruction. */
    public Set<String> instantiatedClasses() {
        return instantiatedClasses;
    }

    public static String key(String owner, String name, String descriptor) {
        return owner + '#' + name + descriptor;
    }

    /** Reachability of the program method a reference occurs in. */
    public Reach reachabilityOf(SymbolicRef ref) {
        if (!entryKnown) {
            return Reach.UNKNOWN;
        }
        RefSite site = ref.site();
        if (site == null) {
            return Reach.UNKNOWN;
        }
        if (site.methodName() != null) {
            return reachableMethods.contains(key(site.programClass(), site.methodName(), site.methodDescriptor()))
                    ? Reach.REACHABLE : Reach.UNREACHABLE;
        }
        return reachableClasses.contains(site.programClass()) ? Reach.REACHABLE : Reach.UNREACHABLE;
    }

    /** Whether a program method can run. */
    public boolean isMethodReachable(String owner, String name, String descriptor) {
        return reachableMethods.contains(key(owner, name, descriptor));
    }

    /** Whether a class is instantiated by reachable program code. */
    public boolean isInstantiated(String owner) {
        return instantiatedClasses.contains(owner);
    }

    @Override
    public String toString() {
        return "Reachability[entry=" + (entryKnown ? entryDescription : "unknown")
                + ", methods=" + reachableMethods.size() + "]";
    }
}
