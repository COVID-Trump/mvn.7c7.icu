package xland.ioutils.jarcompat.resolve;

import java.util.Collections;
import java.util.Set;


/**
 * The transitive supertype closure of one class, computed over a {@link Resolver}: which classes are
 * reachable, which supertypes could not be resolved (external black boxes or removed classes) and
 * which sides (program / lib-a / lib-b / jdk) the walk passed through.
 */
public final class Hierarchy {

    private final String start;
    private final Set<String> reachable;
    private final Set<String> missing;
    private final Set<String> sides;

    Hierarchy(String start, Set<String> reachable, Set<String> missing, Set<String> sides) {
        this.start = start;
        this.reachable = Collections.unmodifiableSet(reachable);
        this.missing = Collections.unmodifiableSet(missing);
        this.sides = Collections.unmodifiableSet(sides);
    }

    /** Internal name of the class the walk started at. */
    public String start() {
        return start;
    }

    /** Whether {@code name} is the start class or one of its (transitive) supertypes. */
    public boolean contains(String name) {
        return reachable.contains(name);
    }

    /** All reachable supertype names, including the start class. */
    public Set<String> reachable() {
        return reachable;
    }

    /** Supertype names that could not be resolved on this side. */
    public Set<String> missing() {
        return missing;
    }

    /** Whether the walk hit at least one unresolvable supertype. */
    public boolean hasMissing() {
        return !missing.isEmpty();
    }

    /** Side labels the walk passed through. */
    public Set<String> sides() {
        return sides;
    }

    public boolean traversed(String side) {
        return sides.contains(side);
    }

    /** Answers "is {@code name} a supertype of the start class?" as precisely as possible. */
    public Certainty certaintyAbout(String name) {
        if (reachable.contains(name)) {
            return Certainty.YES;
        }
        return missing.isEmpty() ? Certainty.NO : Certainty.UNKNOWN;
    }

    @Override
    public String toString() {
        return "Hierarchy[" + start + " -> " + reachable + (missing.isEmpty() ? "" : " missing=" + missing) + "]";
    }
}
