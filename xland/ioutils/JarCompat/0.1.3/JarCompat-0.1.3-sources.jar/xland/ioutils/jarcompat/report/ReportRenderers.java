package xland.ioutils.jarcompat.report;

import java.util.List;
import java.util.Map;

import com.grack.nanojson.JsonSink;
import com.grack.nanojson.JsonWriter;
import xland.ioutils.jarcompat.api.CheckReport;
import xland.ioutils.jarcompat.api.Incompatibility;
import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.Location;
import xland.ioutils.jarcompat.api.ReportFormat;
import xland.ioutils.jarcompat.api.Severity;
import xland.ioutils.jarcompat.api.Side;

/**
 * Renders a {@link CheckReport} in the requested format.
 */
public final class ReportRenderers {

    private ReportRenderers() {
    }

    /** Renders {@code report} as text or JSON. */
    public static String render(CheckReport report, ReportFormat format) {
        return switch (format) {
            case TEXT -> renderText(report);
            case JSON -> renderJson(report);
        };
    }

    private static String renderText(CheckReport report) {
        StringBuilder sb = new StringBuilder(4096);
        sb.append("JarCompat — JAR Binary Compatibility Checker\n");
        sb.append("可达性：").append(reachabilityLabel(report)).append('\n');
        sb.append("检查结果：").append(verdictLabel(report)).append('\n');
        sb.append("确定不兼容项：").append(report.errorCount()).append('\n');
        sb.append("潜在不兼容项：").append(report.warningCount()).append('\n');
        sb.append("未发现问题的引用：").append(report.compatibleReferenceCount()).append('\n');
        sb.append("已检查引用：").append(report.checkedReferenceCount())
                .append("    外部（未提供）引用：").append(report.externalReferenceCount()).append('\n');
        sb.append("耗时：").append(report.durationMillis()).append(" ms\n");

        Map<String, Integer> errorsByJar = report.errorsByLibBJar();
        sb.append("\n不兼容来源统计：\n");
        if (errorsByJar.isEmpty()) {
            sb.append("  （无确定不兼容项）\n");
        } else {
            errorsByJar.forEach((jar, count) -> sb.append("  ").append(pad(jar, 24)).append(count).append(" 项\n"));
        }
        Map<String, Integer> warningsByJar = report.warningsByLibBJar();
        if (!warningsByJar.isEmpty()) {
            sb.append("\n潜在不兼容来源统计：\n");
            warningsByJar.forEach((jar, count) -> sb.append("  ").append(pad(jar, 24)).append(count).append(" 项\n"));
        }

        List<Incompatibility> errors = report.errors();
        List<Incompatibility> warnings = report.warnings();
        List<Incompatibility> infos = report.items().stream()
                .filter(item -> item.severity() == Severity.INFO).toList();

        if (!errors.isEmpty()) {
            sb.append("\n================ 确定不兼容项 (ERROR) ================\n");
            for (int i = 0; i < errors.size(); i++) {
                appendItem(sb, errors.get(i), i + 1);
            }
        }
        if (!warnings.isEmpty()) {
            sb.append("\n================ 潜在不兼容项 (WARN) ================\n");
            for (int i = 0; i < warnings.size(); i++) {
                appendItem(sb, warnings.get(i), i + 1);
            }
        }
        if (!infos.isEmpty()) {
            sb.append("\n================ 说明 (INFO) ================\n");
            for (Incompatibility info : infos) {
                sb.append("  - ").append(info.reason() == null ? info.kind().name() : info.reason()).append('\n');
            }
        }
        if (!report.notes().isEmpty()) {
            sb.append("\n================ 备注 ================\n");
            for (String note : report.notes()) {
                sb.append("  - ").append(note).append('\n');
            }
        }
        return sb.toString();
    }

    private static void appendItem(StringBuilder sb, Incompatibility item, int index) {
        String headline = item.expectedError() != null
                ? simpleName(item.expectedError())
                : item.kind().name();
        sb.append('\n').append('[').append(item.severity()).append("] #").append(index).append(' ')
                .append(headline).append(" (").append(KindLabels.label(item.kind())).append(")\n");
        sb.append("  program 位置:\n");
        if (item.locations().isEmpty()) {
            sb.append("    (无具体位置)\n");
        } else {
            for (Location location : item.locations()) {
                sb.append("    ").append(location.programJar()).append(" -> ").append(location.describe()).append('\n');
            }
        }
        if (item.occurrences() > item.locations().size()) {
            sb.append("    ... 共 ").append(item.occurrences()).append(" 处引用\n");
        }
        if (item.symbol() != null) {
            sb.append("  引用符号:\n    ").append(item.symbol()).append('\n');
        }
        if (item.sideA() != null) {
            sb.append("  lib-a 来源:\n    ").append(item.sideA().describe()).append('\n');
        }
        if (item.sideB() != null) {
            sb.append("  lib-b 来源:\n    ").append(item.sideB().describe()).append('\n');
        }
        if (item.reason() != null) {
            sb.append("  原因:\n    ").append(item.reason()).append('\n');
        }
        if (item.expectedMessage() != null) {
            sb.append("  预计运行时错误:\n    ").append(item.expectedMessage()).append('\n');
        } else if (item.expectedError() != null) {
            sb.append("  预计运行时错误:\n    ").append(item.expectedError()).append('\n');
        }
        if (item.suggestion() != null) {
            sb.append("  建议:\n    ").append(item.suggestion()).append('\n');
        }
    }

    private static String renderJson(CheckReport report) {
        var json = JsonWriter.indent("  ").string();
        json.object();
        json.value("tool", "JarCompat");
        json.value("formatVersion", 1);
        json.value("reachability", report.reachability().name());
        json.value("verdict", report.verdict().name());
        json.value("compatible", report.isCompatible());
        json.object("summary");
        json.value("errors", report.errorCount());
        json.value("warnings", report.warningCount());
        json.value("compatibleReferences", report.compatibleReferenceCount());
        json.value("checkedReferences", report.checkedReferenceCount());
        json.value("externalReferences", report.externalReferenceCount());
        json.value("abstractChecks", report.abstractCheckCount());
        json.value("durationMillis", report.durationMillis());
        json.end();
        json.object("errorsByLibBJar");
        report.errorsByLibBJar().forEach((k, v) -> json.value(k, v));
        json.end();
        json.object("warningsByLibBJar");
        report.warningsByLibBJar().forEach((k, v) -> json.value(k, v));
        json.end();
        json.array("notes");
        report.notes().forEach(x -> json.value(x));
        json.end();
        json.array("incompatibilities");
        for (Incompatibility item : report.items()) {
            json.object();
            json.value("severity", item.severity().name());
            json.value("kind", item.kind().name());
            json.value("kindLabel", KindLabels.label(item.kind()));
            json.value("symbol", item.symbol());
            json.value("occurrences", item.occurrences());
            json.value("expectedError", item.expectedError());
            json.value("expectedMessage", item.expectedMessage());
            json.value("reason", item.reason());
            json.value("suggestion", item.suggestion());
            json.array("locations");
            for (Location location : item.locations()) {
                json.object();
                json.value("programJar", location.programJar());
                json.value("class", location.className());
                json.value("method", location.methodName());
                json.value("descriptor", location.methodDescriptor());
                if (location.line() >= 0) {
                    json.value("line", location.line());
                } else {
                    json.nul("line");
                }
                json.value("detail", location.detail());
                json.end();
            }
            json.end();
            writeSide(json, "libA", item.sideA());
            writeSide(json, "libB", item.sideB());
            json.end();
        }
        json.end();
        json.end();
        return json.toString();
    }

    private static void writeSide(JsonSink<?> json, String name, Side side) {
        if (side == null) {
            json.nul(name);
            return;
        }
        json.object(name);
        json.value("present", side.present());
        json.value("jar", side.jar());
        json.value("declaration", side.declaration());
        json.end();
    }

    private static String reachabilityLabel(CheckReport report) {
        return report.reachability() == xland.ioutils.jarcompat.api.ReachabilityScope.ALL
                ? "all（全量：program 的所有 class/field/method 均视为入口，不做可达性分析）"
                : "entry（从入口做静态调用图分析）";
    }

    private static String verdictLabel(CheckReport report) {
        return switch (report.verdict()) {
            case COMPATIBLE -> reachabilityUnknown(report)
                    ? "兼容（未发现确定不兼容项；但可达性未知，见下方 WARN）"
                    : "兼容（可以直接替换 lib-a 运行）";
            case INCOMPATIBLE -> "不兼容";
            case UNKNOWN -> "无法判定";
        };
    }

    private static boolean reachabilityUnknown(CheckReport report) {
        return report.items().stream().anyMatch(item -> item.kind() == IncompatibilityKind.REACHABILITY_UNKNOWN);
    }

    private static String simpleName(String fqcn) {
        int idx = fqcn.lastIndexOf('.');
        return idx < 0 ? fqcn : fqcn.substring(idx + 1);
    }

    private static String pad(String value, int width) {
        if (value.length() >= width) {
            return value + " ";
        }
        return value + " ".repeat(width - value.length());
    }
}
