package xland.ioutils.jarcompat.asm;

import java.util.Objects;

import xland.ioutils.jarcompat.model.Descriptors;

/**
 * One symbolic reference found in a program class file. Plain data: the ASM instruction that
 * produced it is not retained, so the rest of the pipeline never touches bytecode objects.
 */
public record SymbolicRef(RefKind kind, String owner, String name,
                          String descriptor, int opcode, boolean interfaceRef,
                          boolean soft, RefSite site) {

    public SymbolicRef(RefKind kind, String owner, String name, String descriptor, int opcode,
                       boolean interfaceRef, boolean soft, RefSite site) {
        this.kind = Objects.requireNonNull(kind);
        this.owner = Objects.requireNonNull(owner);
        this.name = name;
        this.descriptor = descriptor;
        this.opcode = opcode;
        this.interfaceRef = interfaceRef;
        this.soft = soft;
        this.site = site;
    }

    /**
     * Class name (internal, slash separated) the reference is anchored at.
     */
    @Override
    public String owner() {
        return owner;
    }

    /**
     * Member name, or {@code null} for class references.
     */
    @Override
    public String name() {
        return name;
    }

    /**
     * Member descriptor, or {@code null} for class references.
     */
    @Override
    public String descriptor() {
        return descriptor;
    }

    /**
     * JVM opcode that produced the reference (0 for references coming from signatures/attributes).
     */
    @Override
    public int opcode() {
        return opcode;
    }

    /**
     * For method references: whether the constant pool entry is an {@code InterfaceMethodref}.
     */
    @Override
    public boolean interfaceRef() {
        return interfaceRef;
    }

    /**
     * Whether the reference can never cause a linkage error at run time: metadata references
     * (annotations, {@code throws} clauses, inner-class/nest attributes) are ignored by the JVM
     * when unresolvable, and {@code checkcast}/{@code instanceof} on the {@code null} literal never
     * resolves its type. Such references are reported as potential problems only.
     */
    @Override
    public boolean soft() {
        return soft;
    }

    /**
     * Program location, as string, used in messages.
     */
    public String siteDescription() {
        return site == null ? "?" : site.toString();
    }

    /**
     * Constant-pool style symbol, e.g. {@code lib/a/Service.run(I)Ljava/lang/String;}.
     */
    public String symbol() {
        return switch (kind) {
            case CLASS -> owner;
            case FIELD -> Descriptors.fieldSymbol(owner, name, descriptor);
            case METHOD -> Descriptors.methodSymbol(owner, name, descriptor);
        };
    }

    /**
     * Identity used to deduplicate references inside one program method.
     */
    public String dedupeKey() {
        return kind + "|" + owner + "|" + name + "|" + descriptor + "|" + opcode + "|" + interfaceRef
                + "|" + (site == null ? -1 : site.line()) + "|" + (site == null ? "" : site.detail());
    }

    /**
     * Identity used to group findings in the report (same problem reported once).
     */
    public String groupKey() {
        return kind + "|" + owner + "|" + name + "|" + descriptor;
    }

    @Override
    public String toString() {
        return kind + " " + symbol();
    }
}
