package xland.ioutils.jarcompat.jar;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * The subset of {@code META-INF/MANIFEST.MF} JarCompat cares about.
 */
public final class ManifestInfo {

    private final boolean present;
    private final String mainClass;
    private final boolean multiRelease;
    private final boolean sealed;
    private final Set<String> sealedPackages;
    private final String multiReleaseValue;

    private ManifestInfo(boolean present, String mainClass, boolean multiRelease, String multiReleaseValue,
                         boolean sealed, Set<String> sealedPackages) {
        this.present = present;
        this.mainClass = mainClass;
        this.multiRelease = multiRelease;
        this.multiReleaseValue = multiReleaseValue;
        this.sealed = sealed;
        this.sealedPackages = Collections.unmodifiableSet(sealedPackages);
    }

    /** An archive without a manifest. */
    public static ManifestInfo absent() {
        return new ManifestInfo(false, null, false, null, false, Set.of());
    }

    public static ManifestInfo of(String mainClass, String multiReleaseValue, boolean sealed,
                                  Set<String> sealedPackages) {
        boolean multi = multiReleaseValue != null && Boolean.parseBoolean(multiReleaseValue.trim());
        return new ManifestInfo(true, mainClass, multi, multiReleaseValue, sealed, new LinkedHashSet<>(sealedPackages));
    }

    public boolean present() {
        return present;
    }

    /** {@code Main-Class} attribute, dotted name, or {@code null}. */
    public String mainClass() {
        return mainClass;
    }

    /** Whether {@code Multi-Release: true} is set. */
    public boolean multiRelease() {
        return multiRelease;
    }

    /** Raw {@code Multi-Release} value, for diagnostics. */
    public String multiReleaseValue() {
        return multiReleaseValue;
    }

    /** Whether the whole archive is sealed ({@code Sealed: true} in the main section). */
    public boolean sealed() {
        return sealed;
    }

    /** Packages sealed by individual manifest sections (dotted package names). */
    public Set<String> sealedPackages() {
        return sealedPackages;
    }
}
