package xland.ioutils.jarcompat.asm;

import java.util.List;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.MethodNode;

import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.ClassOrigin;
import xland.ioutils.jarcompat.model.FieldInfo;
import xland.ioutils.jarcompat.model.MethodInfo;

/**
 * Turns a class file into a {@link ClassInfo} symbol-table entry. The class is only <em>parsed</em>;
 * it is never loaded by a class loader.
 *
 * <p>This is the single place where ASM types are converted into the ASM-free domain model.</p>
 */
public final class ClassInfoReader {

    private ClassInfoReader() {
    }

    /** Flags for a full parse (code + debug information, frames skipped). */
    public static final int FULL = ClassReader.SKIP_FRAMES;

    /** Flags for a header-only parse of library classes. */
    public static final int HEADER = ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES;

    /** Parses a class file into an ASM node tree. */
    public static ClassNode readNode(byte[] bytes, int flags) {
        ClassNode node = new ClassNode();
        new ClassReader(bytes).accept(node, flags);
        return node;
    }

    /** Parses a class file header into the domain model. */
    public static ClassInfo read(byte[] bytes, ClassOrigin origin, int flags) {
        return fromNode(readNode(bytes, flags), origin);
    }

    /** Converts an already parsed {@link ClassNode} into the domain model. */
    public static ClassInfo fromNode(ClassNode node, ClassOrigin origin) {
        ClassInfo.Builder builder = ClassInfo.builder(node.name, node.access, origin)
                .superName(node.superName);
        if (node.interfaces != null) {
            builder.interfaces(List.copyOf(node.interfaces));
        }
        if (node.fields != null) {
            for (FieldNode field : node.fields) {
                builder.field(new FieldInfo(node.name, field.name, field.desc, field.access));
            }
        }
        if (node.methods != null) {
            for (MethodNode method : node.methods) {
                builder.method(new MethodInfo(node.name, method.name, method.desc, method.access,
                        method.exceptions));
            }
        }
        if (node.nestHostClass != null) {
            builder.nestHost(node.nestHostClass);
        }
        if (node.nestMembers != null) {
            node.nestMembers.forEach(builder::nestMember);
        }
        if (node.permittedSubclasses != null) {
            node.permittedSubclasses.forEach(builder::permittedSubclass);
        }
        return builder.build();
    }
}
