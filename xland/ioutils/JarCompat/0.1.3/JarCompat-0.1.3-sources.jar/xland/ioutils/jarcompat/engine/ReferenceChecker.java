package xland.ioutils.jarcompat.engine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.objectweb.asm.Opcodes;

import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.Severity;
import xland.ioutils.jarcompat.asm.ProgramIndex;
import xland.ioutils.jarcompat.asm.SymbolicRef;
import xland.ioutils.jarcompat.model.Access;
import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.ClassOrigin;
import xland.ioutils.jarcompat.model.Descriptors;
import xland.ioutils.jarcompat.model.FieldInfo;
import xland.ioutils.jarcompat.model.MethodInfo;
import xland.ioutils.jarcompat.model.Repo;
import xland.ioutils.jarcompat.reach.Reach;
import xland.ioutils.jarcompat.reach.Reachability;
import xland.ioutils.jarcompat.resolve.AccessCheck;
import xland.ioutils.jarcompat.resolve.Certainty;
import xland.ioutils.jarcompat.resolve.Resolution;
import xland.ioutils.jarcompat.resolve.Resolver;

/**
 * Re-resolves every program → lib-a reference inside lib-b and reports what the JVM would do.
 *
 * <p>The check is a <em>regression</em> analysis: something is only reported when it worked against
 * lib-a and no longer works against lib-b. References that were already broken in lib-a, that point
 * into the JDK, or that point into an external black box are not incompatibilities.</p>
 */
final class ReferenceChecker {

    private final ProgramIndex program;
    private final Repo repoA;
    private final Repo repoB;
    private final Resolver resolverA;
    private final Resolver resolverB;
    private final Reachability reach;
    private final Findings findings;
    private final Set<String> externalClasses = new LinkedHashSet<>();
    /** Label used when a symbol is absent from the whole lib-b side. */
    private final String missingBLabel;

    ReferenceChecker(ProgramIndex program, Repo repoA, Repo repoB, Resolver resolverA, Resolver resolverB,
                     Reachability reach, Findings findings) {
        this.program = program;
        this.repoA = repoA;
        this.repoB = repoB;
        this.resolverA = resolverA;
        this.resolverB = resolverB;
        this.reach = reach;
        this.findings = findings;
        this.missingBLabel = repoB.jars().size() == 1 ? repoB.jars().getFirst() : repoB.label();
    }

    /** External classes that were skipped because they are not part of the analysed inputs. */
    Set<String> externalClasses() {
        return externalClasses;
    }

    void checkAll() {
        for (ClassInfo programClass : program.repo().classes()) {
            for (SymbolicRef ref : program.referencesOf(programClass.name())) {
                checkRef(ref, programClass);
            }
        }
    }

    private void checkRef(SymbolicRef ref, ClassInfo programClass) {
        switch (ref.kind()) {
            case CLASS -> checkClassRef(ref, programClass);
            case FIELD -> checkFieldRef(ref, programClass);
            case METHOD -> checkMethodRef(ref, programClass);
        }
    }

    // ------------------------------------------------------------------ class references

    private void checkClassRef(SymbolicRef ref, ClassInfo programClass) {
        String target = ref.owner();
        if (Descriptors.isArray(target)) {
            // An array class has no binary representation: the JVM creates it and resolves only its
            // element type (JVMS §5.4.3.1), which is the only part a library can provide. An array
            // of a primitive type (`[B`) resolves nothing, so it can never fail.
            target = Descriptors.arrayElementClass(target);
            if (target == null) {
                findings.checkedReference();
                findings.compatibleReference();
                return;
            }
        }
        checkClassTarget(ref, programClass, target);
    }

    /**
     * Presence, kind and access of the class behind a class-level reference (the class itself, or
     * the element type of an array).
     */
    private void checkClassTarget(SymbolicRef ref, ClassInfo programClass, String target) {
        if (program.repo().contains(target)) {
            return;
        }
        ClassInfo inA = repoA.find(target);
        if (inA == null) {
            if (resolverA.findClass(target) != null) {
                return; // JDK type: metadata only, always compatible
            }
            external(target);
            return;
        }
        findings.checkedReference();
        ClassInfo inB = repoB.find(target);
        if (inB == null) {
            reportMissingClass(target, inA, ref);
            return;
        }
        Severity severity = severityFor(ref);
        boolean instantiation = ref.opcode() == Opcodes.NEW;
        if (instantiation && !inA.isInterface() && inB.isInterface()) {
            findings.item(IncompatibilityKind.CLASS_KIND_CHANGED, severity, target)
                    .at(ref)
                    .sideA(inA.originJar(), inA.declaration())
                    .sideB(inB.originJar(), inB.declaration())
                    .expected("java.lang.InstantiationError", "java.lang.InstantiationError: " + inB.dottedName())
                    .reason("program 用 new 实例化该类，但 B 中同名的 "
                            + Descriptors.toDotted(target) + " 变成了接口，实例化接口会抛 InstantiationError。"
                            + reachabilityNote(ref))
                    .suggestion("让 lib-b 保持该类为普通类，或重编译 program（并改写为获取实现类实例的方式）。")
                    .submit();
            return;
        }
        if (instantiation && inA.isInterface() && !inB.isInterface()) {
            // Was already illegal against lib-a: not a regression.
            findings.compatibleReference();
            return;
        }
        if (instantiation && !inA.isAbstract() && inB.isAbstract()) {
            findings.item(IncompatibilityKind.CLASS_KIND_CHANGED, severity, target)
                    .at(ref)
                    .sideA(inA.originJar(), inA.declaration())
                    .sideB(inB.originJar(), inB.declaration())
                    .expected("java.lang.InstantiationError", "java.lang.InstantiationError: " + inB.dottedName())
                    .reason("program 用 new 实例化该类，A 中它不是 abstract，B 中变成了 abstract，"
                            + "实例化抽象类会抛 InstantiationError。" + reachabilityNote(ref))
                    .suggestion("让 lib-b 恢复该类的具体性，或重编译 program（改用具体子类）。")
                    .submit();
            return;
        }
        Certainty accessA = AccessCheck.classAccess(resolverA, programClass, inA);
        Certainty accessB = AccessCheck.classAccess(resolverB, programClass, inB);
        if (accessA.isYes() && accessB == Certainty.NO) {
            findings.item(IncompatibilityKind.ACCESS_REDUCED, severity, target)
                    .at(ref)
                    .sideA(inA.originJar(), inA.declaration())
                    .sideB(inB.originJar(), inB.declaration())
                    .expected("java.lang.IllegalAccessError",
                            "java.lang.IllegalAccessError: failed to access class " + inB.dottedName()
                                    + " from class " + programClass.dottedName()
                                    + " (" + programClass.dottedName() + " is in unnamed module of loader 'app'; "
                                    + inB.dottedName() + " is in unnamed module of loader 'app')")
                    .reason("A 中该类可从 program 访问，B 中不再可访问（访问权限降低：" 
                            + Access.visibility(inA.access()) + " -> " + Access.visibility(inB.access()) + "）。"
                            + reachabilityNote(ref))
                    .suggestion("恢复 B 中该类的可见性，或重编译 program。")
                    .submit();
            return;
        }
        findings.compatibleReference();
    }

    private void reportMissingClass(String target, ClassInfo inA, SymbolicRef ref) {
        findings.item(IncompatibilityKind.MISSING_CLASS, severityFor(ref), target)
                .at(ref)
                .sideA(inA.originJar(), inA.declaration())
                .sideB(missingBLabel, null)
                .expected("java.lang.NoClassDefFoundError", "java.lang.NoClassDefFoundError: " + target)
                .reason("A 侧存在类 " + inA.dottedName() + "（" + inA.originJar() + "），但 B 侧的所有 JAR 中都没有这个类。"
                        + "program 引用它的指令/签名在运行期解析时会抛 NoClassDefFoundError。" + reachabilityNote(ref))
                .suggestion("在 lib-b 中保留该类（可以搬到任意 JAR 中，类名不变即可），或重编译 program。")
                .submit();
    }

    // ------------------------------------------------------------------ field references

    private void checkFieldRef(SymbolicRef ref, ClassInfo programClass) {
        String owner = ref.owner();
        if (Descriptors.isArray(owner)) {
            checkArrayOwner(ref, programClass, owner);
            return;
        }
        String name = ref.name();
        String descriptor = ref.descriptor();
        int opcode = ref.opcode();
        boolean refStatic = opcode == Opcodes.GETSTATIC || opcode == Opcodes.PUTSTATIC;
        boolean write = opcode == Opcodes.PUTSTATIC || opcode == Opcodes.PUTFIELD;

        Resolution<FieldInfo> ra = resolverA.resolveField(owner, name, descriptor);
        if (!touchesA(owner, ra)) {
            skipExternal(owner, ra);
            return;
        }
        findings.checkedReference();
        if (!ra.isResolved()) {
            reportUnresolvableInA(ref, ra, owner, false);
            return;
        }
        Resolution<FieldInfo> rb = resolverB.resolveField(owner, name, descriptor);
        Severity severity = severityFor(ref);
        if (!rb.isResolved()) {
            reportUnresolvableInB(ref, ra, rb, owner, false);
            return;
        }
        FieldInfo fa = ra.member();
        FieldInfo fb = rb.member();
        if (fa.isStatic() == refStatic && fb.isStatic() != refStatic) {
            findings.item(IncompatibilityKind.MEMBER_STATIC_MISMATCH, severity, ref.symbol())
                    .at(ref)
                    .sideA(ra.declaringClass().originJar(), fa.declaration())
                    .sideB(rb.declaringClass().originJar(), fb.declaration())
                    .expected("java.lang.IncompatibleClassChangeError",
                            "java.lang.IncompatibleClassChangeError: Expected "
                                    + (refStatic ? "static" : "non-static") + " field "
                                    + Descriptors.toDotted(owner) + "." + name)
                    .reason("program 的字节码使用 " + (refStatic ? "getstatic/putstatic" : "getfield/putfield")
                            + "，A 中该字段是" + (fa.isStatic() ? " static" : " 实例") + "字段，"
                            + "B 中变成了" + (fb.isStatic() ? " static" : " 实例") + "字段。" + reachabilityNote(ref))
                    .suggestion("恢复 B 中字段的 static 修饰符（或新增一个兼容字段），或重编译 program。")
                    .submit();
            return;
        }
        if (write && fb.isFinal() && !fa.isFinal()) {
            findings.item(IncompatibilityKind.FINAL_VIOLATION, severity, ref.symbol())
                    .at(ref)
                    .sideA(ra.declaringClass().originJar(), fa.declaration())
                    .sideB(rb.declaringClass().originJar(), fb.declaration())
                    .expected("java.lang.IllegalAccessError",
                            fb.isStatic()
                                    ? "java.lang.IllegalAccessError: Update to static final field "
                                    + Descriptors.toDotted(rb.declaringClass().name()) + "." + name
                                    + " attempted from a different method"
                                    : "java.lang.IllegalAccessError: Update to non-static final field "
                                    + Descriptors.toDotted(rb.declaringClass().name()) + "." + name
                                    + " attempted from a different class (" + programClass.dottedName()
                                    + ") than the field's declaring class")
                    .reason("program 写入该字段，A 中它不是 final，B 中变成了 final；"
                            + "从声明类之外写入 final 字段会抛 IllegalAccessError。" + reachabilityNote(ref))
                    .suggestion("让 lib-b 不要将该字段声明为 final，或重编译 program。")
                    .submit();
            return;
        }
        Certainty accessA = AccessCheck.memberAccess(resolverA, programClass, ra.declaringClass(), fa.access());
        Certainty accessB = AccessCheck.memberAccess(resolverB, programClass, rb.declaringClass(), fb.access());
        if (accessA.isYes() && accessB == Certainty.NO) {
            findings.item(IncompatibilityKind.ACCESS_REDUCED, severity, ref.symbol())
                    .at(ref)
                    .sideA(ra.declaringClass().originJar(), fa.declaration())
                    .sideB(rb.declaringClass().originJar(), fb.declaration())
                    .expected("java.lang.IllegalAccessError",
                            "java.lang.IllegalAccessError: class " + programClass.dottedName()
                                    + " tried to access " + Access.visibility(fb.access()) + " field '"
                                    + Descriptors.linkageFieldSignature(rb.declaringClass().name(), name, descriptor)
                                    + "' (" + programClass.dottedName() + " and "
                                    + rb.declaringClass().dottedName()
                                    + " are in unnamed module of loader 'app')")
                    .reason("A 中该字段可从 program 访问，B 中访问权限降低（"
                            + Access.visibility(fa.access()) + " -> " + Access.visibility(fb.access()) + "）。"
                            + reachabilityNote(ref))
                    .suggestion("恢复 B 中字段的可见性，或重编译 program。")
                    .submit();
            return;
        }
        findings.compatibleReference();
    }

    // ------------------------------------------------------------------ method references

    private void checkMethodRef(SymbolicRef ref, ClassInfo programClass) {
        String owner = ref.owner();
        if (Descriptors.isArray(owner)) {
            checkArrayOwner(ref, programClass, owner);
            return;
        }
        String name = ref.name();
        String descriptor = ref.descriptor();
        boolean interfaceRef = ref.interfaceRef();
        boolean refStatic = ref.opcode() == Opcodes.INVOKESTATIC;
        boolean constructor = "<init>".equals(name);

        Resolution<MethodInfo> ra = interfaceRef
                ? resolverA.resolveInterfaceMethod(owner, name, descriptor)
                : resolverA.resolveClassMethod(owner, name, descriptor);
        if (!touchesA(owner, ra)) {
            skipExternal(owner, ra);
            return;
        }
        findings.checkedReference();
        if (!ra.isResolved()) {
            reportUnresolvableInA(ref, ra, owner, true);
            return;
        }
        ClassInfo ownerInA = resolverA.findClass(owner);
        Resolution<MethodInfo> rb = interfaceRef
                ? resolverB.resolveInterfaceMethod(owner, name, descriptor)
                : resolverB.resolveClassMethod(owner, name, descriptor);
        Severity severity = severityFor(ref);

        // class/interface kind change of the owner: the constant pool entry no longer matches
        ClassInfo ownerInB = resolverB.findClass(owner);
        if (ownerInA != null && ownerInB != null && ownerInA.isInterface() != ownerInB.isInterface()
                && repoA.contains(owner)) {
            findings.item(IncompatibilityKind.CLASS_KIND_CHANGED, severity, ref.symbol())
                    .at(ref)
                    .sideA(ownerInA.originJar(), ownerInA.declaration())
                    .sideB(ownerInB.originJar(), ownerInB.declaration())
                    .expected("java.lang.IncompatibleClassChangeError",
                            "java.lang.IncompatibleClassChangeError: Method '"
                                    + Descriptors.linkageMethodSignature(owner, name, descriptor)
                                    + (interfaceRef ? "' must be Methodref constant"
                                    : "' must be InterfaceMethodref constant"))
                    .reason("program 用 " + (interfaceRef ? "invokeinterface/InterfaceMethodref" : "类方法引用 (Methodref)")
                            + " 引用 " + Descriptors.toDotted(owner) + "，A 中它是"
                            + (ownerInA.isInterface() ? "接口" : "类") + "，B 中变成了"
                            + (ownerInB.isInterface() ? "接口" : "类") + "。" + reachabilityNote(ref))
                    .suggestion("让 lib-b 保持该类型种类不变，或重编译 program（接口化后需要改写调用点）。")
                    .submit();
            return;
        }
        if (!rb.isResolved()) {
            reportUnresolvableInB(ref, ra, rb, owner, true);
            return;
        }
        MethodInfo fa = ra.member();
        MethodInfo fb = rb.member();
        if (fa.isStatic() == refStatic && fb.isStatic() != refStatic) {
            findings.item(IncompatibilityKind.MEMBER_STATIC_MISMATCH, severity, ref.symbol())
                    .at(ref)
                    .sideA(ra.declaringClass().originJar(), fa.declaration())
                    .sideB(rb.declaringClass().originJar(), fb.declaration())
                    .expected("java.lang.IncompatibleClassChangeError",
                            "java.lang.IncompatibleClassChangeError: "
                                    + (refStatic ? "Expected static method '"
                                    : interfaceRef ? "Expected instance not static method '"
                                    : "Expecting non-static method '")
                                    + Descriptors.linkageMethodSignature(owner, name, descriptor) + "'")
                    .reason("program 使用 " + (refStatic ? "invokestatic" : "invokevirtual/invokeinterface/invokespecial")
                            + "，A 中该方法是" + (fa.isStatic() ? " static" : " 实例") + "方法，B 中变成了"
                            + (fb.isStatic() ? " static" : " 实例") + "方法。" + reachabilityNote(ref))
                    .suggestion("恢复 B 中方法的 static 修饰符（或保留一个兼容的实例/静态桥接方法），或重编译 program。")
                    .submit();
            return;
        }
        if (!fa.isAbstract() && fb.isAbstract()) {
            findings.item(IncompatibilityKind.ABSTRACT_METHOD_MISSING, Severity.WARN, ref.symbol())
                    .at(ref)
                    .sideA(ra.declaringClass().originJar(), fa.declaration())
                    .sideB(rb.declaringClass().originJar(), fb.declaration())
                    .expected("java.lang.AbstractMethodError",
                            "java.lang.AbstractMethodError: '" + Descriptors.linkageMethodSignature(owner, name, descriptor) + "'")
                    .reason("A 中该方法是具体方法，B 中变成了 abstract；若运行期接收者类型没有提供实现，"
                            + "调用点会抛 AbstractMethodError。" + reachabilityNote(ref))
                    .suggestion("让 lib-b 保留默认实现，或重编译 program 以实现新增的抽象方法。")
                    .submit();
            return;
        }
        Certainty accessA = AccessCheck.memberAccess(resolverA, programClass, ra.declaringClass(), fa.access());
        Certainty accessB = AccessCheck.memberAccess(resolverB, programClass, rb.declaringClass(), fb.access());
        if (accessA.isYes() && accessB == Certainty.NO) {
            findings.item(IncompatibilityKind.ACCESS_REDUCED, severity, ref.symbol())
                    .at(ref)
                    .sideA(ra.declaringClass().originJar(), fa.declaration())
                    .sideB(rb.declaringClass().originJar(), fb.declaration())
                    .expected("java.lang.IllegalAccessError",
                            "java.lang.IllegalAccessError: class " + programClass.dottedName()
                                    + " tried to access " + Access.visibility(fb.access()) + " method '"
                                    + Descriptors.linkageMethodSignature(rb.declaringClass().name(), name, descriptor)
                                    + "' (" + programClass.dottedName() + " and "
                                    + rb.declaringClass().dottedName()
                                    + " are in unnamed module of loader 'app')")
                    .reason("A 中该方法可从 program 访问，B 中访问权限降低（"
                            + Access.visibility(fa.access()) + " -> " + Access.visibility(fb.access()) + "）。"
                            + (constructor ? "构造器不可访问同样抛 IllegalAccessError。" : "")
                            + reachabilityNote(ref))
                    .suggestion("恢复 B 中方法/构造器的可见性，或重编译 program。")
                    .submit();
            return;
        }
        findings.compatibleReference();
    }

    // ------------------------------------------------------------------ array owners

    /**
     * Member reference anchored at an array class: {@code array.clone()} shows up as
     * {@code invokevirtual [B.clone()}. Array classes are created by the JVM on demand and are
     * never provided by lib-a or lib-b; the only part of such a reference a library can provide is
     * the element type (JVMS §5.4.3.1), which is checked here at class level.
     */
    private void checkArrayOwner(SymbolicRef ref, ClassInfo programClass, String arrayType) {
        String element = Descriptors.arrayElementClass(arrayType);
        if (element == null) {
            // `[B` and friends: the JVM resolves no class at all, so this can never fail.
            findings.checkedReference();
            findings.compatibleReference();
            return;
        }
        checkClassTarget(ref, programClass, element);
    }

    // ------------------------------------------------------------------ shared helpers

    private void reportUnresolvableInA(SymbolicRef ref, Resolution<?> ra, String owner, boolean method) {
        if (ra.status() == Resolution.Status.HIERARCHY_MISSING && ra.missingClass() != null
                && !repoA.contains(ra.missingClass())) {
            // lib-a itself sits on top of a dependency that was not provided: nothing to conclude.
            external(ra.missingClass());
            findings.item(IncompatibilityKind.EXTERNAL_DEPENDENCY_UNCHECKED, Severity.WARN, ref.symbol())
                    .at(ref)
                    .sideA(repoA.label(), null)
                    .reason("A 侧解析该引用时经过未提供的依赖 " + Descriptors.toDotted(ra.missingClass())
                            + "，无法判断它原本由谁提供，已跳过。")
                    .suggestion("把该依赖一并作为 --lib-a/--lib-b 传入即可获得完整检查。")
                    .submit();
            return;
        }
        findings.item(IncompatibilityKind.UNRESOLVED_IN_A, Severity.WARN, ref.symbol())
                .at(ref)
                .sideA(repoA.label(), null)
                .reason("该引用在 lib-a 中也无法解析（A 侧就不存在对应的" + (method ? "方法" : "字段")
                        + "），因此不能归因于 lib-a -> lib-b 的变化。")
                .suggestion("确认 --lib-a 是否传入了全部旧库 JAR。")
                .submit();
    }

    private void reportUnresolvableInB(SymbolicRef ref, Resolution<?> ra, Resolution<?> rb, String owner,
                                       boolean method) {
        Severity severity = severityFor(ref);
        if (rb.status() == Resolution.Status.HIERARCHY_MISSING && rb.missingClass() != null
                && !repoA.contains(rb.missingClass())) {
            external(rb.missingClass());
            findings.item(IncompatibilityKind.EXTERNAL_DEPENDENCY_UNCHECKED, severity, ref.symbol())
                    .at(ref)
                    .sideA(sideOfA(ra, owner, method))
                    .sideB(missingBLabel, null)
                    .reason("B 侧解析该引用时经过未提供的依赖 " + Descriptors.toDotted(rb.missingClass())
                            + "，无法确定成员是否仍然存在，已按潜在风险报告。")
                    .suggestion("把该依赖一并作为 --lib-b 传入即可获得完整检查。")
                    .submit();
            return;
        }
        if (rb.status() == Resolution.Status.OWNER_MISSING) {
            ClassInfo inA = repoA.find(owner);
            if (inA != null) {
                reportMissingClass(owner, inA, ref);
            }
            return;
        }
        String nearMiss = nearMiss(owner, ref.name(), ref.descriptor(), method);
        IncompatibilityKind kind = nearMiss != null
                ? IncompatibilityKind.DESCRIPTOR_CHANGED
                : (method ? IncompatibilityKind.MISSING_METHOD : IncompatibilityKind.MISSING_FIELD);
        if (method) {
            findings.item(kind, severity, ref.symbol())
                    .at(ref)
                    .sideA(sideOfA(ra, owner, true))
                    .sideB(bSideJar(rb.owner()), null)
                    .expected("java.lang.NoSuchMethodError",
                            "java.lang.NoSuchMethodError: '" + Descriptors.linkageMethodSignature(owner, ref.name(),
                                    ref.descriptor()) + "'")
                    .reason("B 侧沿着 owner 及其父类/父接口都找不到同名且描述符相同的方法。"
                            + (nearMiss != null ? nearMiss : "")
                            + "方法描述符包含参数类型与返回类型，任何一处变化都会导致解析失败。"
                            + reachabilityNote(ref))
                    .suggestion("在 lib-b 中恢复该方法（参数/返回类型必须与 A 完全一致），"
                            + "或提供一个桥接方法（bridge），或重编译 program。")
                    .submit();
        } else {
            findings.item(kind, severity, ref.symbol())
                    .at(ref)
                    .sideA(sideOfA(ra, owner, false))
                    .sideB(bSideJar(rb.owner()), null)
                    .expected("java.lang.NoSuchFieldError",
                            "java.lang.NoSuchFieldError: Class " + Descriptors.toDotted(owner)
                                    + " does not have member field '" + Descriptors.typeName(ref.descriptor())
                                    + " " + ref.name() + "'")
                    .reason("B 侧找不到同名且描述符相同的字段。"
                            + (nearMiss != null ? nearMiss : "") + reachabilityNote(ref))
                    .suggestion("在 lib-b 中恢复该字段（字段类型必须一致），或重编译 program。")
                    .submit();
        }
    }

    /**
     * The lib-b JAR to blame for a symbol that could not be resolved: the class that was searched
     * when it comes from lib-b, otherwise the whole lib-b side. A program JAR is never reported as a
     * lib-b origin.
     */
    private String bSideJar(ClassInfo searched) {
        if (searched != null && searched.origin() != null
                && ClassOrigin.LIB_B.equals(searched.origin().side())) {
            return searched.originJar();
        }
        return missingBLabel;
    }

    private xland.ioutils.jarcompat.api.Side sideOfA(Resolution<?> ra, String owner, boolean method) {
        if (ra.isResolved()) {
            Object member = ra.member();
            String declaration = member instanceof MethodInfo m ? m.declaration()
                    : member instanceof FieldInfo f ? f.declaration() : null;
            return xland.ioutils.jarcompat.api.Side.found(ra.declaringClass().originJar(), declaration);
        }
        ClassInfo inA = repoA.find(owner);
        return xland.ioutils.jarcompat.api.Side.missing(inA == null ? repoA.label() : inA.originJar(), "(未找到)");
    }

    /** Whether the reference involves the lib-a side at all (otherwise it is out of scope). */
    private boolean touchesA(String owner, Resolution<?> ra) {
        if (repoA.contains(owner)) {
            return true;
        }
        if (ra.viaLibA()) {
            return true;
        }
        if (ra.isResolved() && ClassOrigin.LIB_A.equals(ra.declaringSide())) {
            return true;
        }
        return ra.missingClass() != null && repoA.contains(ra.missingClass());
    }

    private void skipExternal(String owner, Resolution<?> ra) {
        if (ra.isResolved()) {
            if (ClassOrigin.PROGRAM.equals(ra.declaringSide())) {
                return; // fully internal to the program: lib-a is not involved
            }
            if (ra.declaringClass() != null && ra.declaringClass().origin().isJdk()) {
                return; // JDK type: provided by the platform, never part of the swap
            }
            external(owner);
            return;
        }
        if (program.repo().contains(owner)) {
            // program class whose hierarchy leaves the analysed inputs
            if (ra.missingClass() != null) {
                external(ra.missingClass());
            }
            return;
        }
        external(owner);
    }

    private void external(String className) {
        findings.externalReference();
        if (className == null) {
            return;
        }
        if (Descriptors.isArray(className)) {
            // A library never provides an array class: report the element type it would have to
            // provide, and nothing at all for an array of a primitive type (`[B`).
            String element = Descriptors.arrayElementClass(className);
            if (element != null) {
                externalClasses.add(Descriptors.toDotted(element));
            }
            return;
        }
        externalClasses.add(Descriptors.toDotted(className));
    }

    private Severity severityFor(SymbolicRef ref) {
        if (ref.soft()) {
            return Severity.WARN;
        }
        Reach reachability = reach.reachabilityOf(ref);
        return reachability == Reach.REACHABLE ? Severity.ERROR : Severity.WARN;
    }

    private String reachabilityNote(SymbolicRef ref) {
        if (ref.soft()) {
            return "（该引用不会触发 JVM 链接错误——例如只出现在注解/元数据中，或操作数是 null 字面量——属于潜在问题。）";
        }
        return switch (reach.reachabilityOf(ref)) {
            case REACHABLE -> "";
            case UNREACHABLE -> "（该引用位于从入口点不可达的代码中：JVM 懒解析，只要不执行到就不会报错，属于潜在不兼容。）";
            case UNKNOWN -> "（无法确定可达性：没有找到入口点，按潜在不兼容处理。）";
        };
    }

    /** Describes the closest member in lib-b that has the right name but the wrong descriptor. */
    private String nearMiss(String owner, String name, String descriptor, boolean method) {
        List<String> visited = new ArrayList<>();
        ClassInfo start = resolverB.findClass(owner);
        if (start == null) {
            return null;
        }
        List<ClassInfo> queue = new ArrayList<>();
        queue.add(start);
        while (!queue.isEmpty()) {
            ClassInfo current = queue.removeFirst();
            if (current == null || !visited.add(current.name())) {
                continue;
            }
            if (method) {
                for (MethodInfo candidate : current.methodsNamed(name)) {
                    if (!candidate.descriptor().equals(descriptor)) {
                        return "B 中存在同名方法 " + candidate.declaration() + "，但描述符不匹配。";
                    }
                }
            } else {
                for (FieldInfo candidate : current.fieldsNamed(name)) {
                    if (!candidate.descriptor().equals(descriptor)) {
                        return "B 中存在同名字段 " + candidate.declaration() + "，但字段类型不匹配。";
                    }
                }
            }
            if (current.superName() != null) {
                queue.add(resolverB.findClass(current.superName()));
            }
            for (String itf : current.interfaces()) {
                queue.add(resolverB.findClass(itf));
            }
        }
        return null;
    }

    /** Set of external (skipped) class names, sorted for stable reports. */
    List<String> externalClassList() {
        List<String> list = new ArrayList<>(new HashSet<>(externalClasses));
        list.sort(String::compareTo);
        return list;
    }
}
