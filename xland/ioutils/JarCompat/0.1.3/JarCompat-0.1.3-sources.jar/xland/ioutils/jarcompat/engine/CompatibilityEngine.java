package xland.ioutils.jarcompat.engine;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import xland.ioutils.jarcompat.api.CheckReport;
import xland.ioutils.jarcompat.api.CheckRequest;
import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.ReachabilityScope;
import xland.ioutils.jarcompat.api.Severity;
import xland.ioutils.jarcompat.api.Verdict;
import xland.ioutils.jarcompat.asm.ProgramIndex;
import xland.ioutils.jarcompat.asm.ProgramScanner;
import xland.ioutils.jarcompat.jar.JarScanner;
import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.ClassOrigin;
import xland.ioutils.jarcompat.model.Repo;
import xland.ioutils.jarcompat.model.RepoBuilder;
import xland.ioutils.jarcompat.model.ScanIssue;
import xland.ioutils.jarcompat.reach.Reachability;
import xland.ioutils.jarcompat.reach.ReachabilityAnalyzer;
import xland.ioutils.jarcompat.resolve.JdkMetadata;
import xland.ioutils.jarcompat.resolve.Resolver;

/**
 * Orchestrates one complete compatibility check:
 *
 * <ol>
 *   <li>flatten program / lib-a / lib-b into three logical repositories (JAR boundaries are
 *       irrelevant to the JVM, so classes may move freely between JARs);</li>
 *   <li>extract every linkable reference from the program side (with line numbers);</li>
 *   <li>compute conservative static reachability from the entry point;</li>
 *   <li>re-resolve every program → lib-a reference inside lib-b, following the JVM's resolution and
 *       access rules;</li>
 *   <li>check class shapes (superclass/interface relations, abstract method coverage);</li>
 *   <li>produce a structured {@link CheckReport}.</li>
 * </ol>
 */
public final class CompatibilityEngine {

    private CompatibilityEngine() {
    }

    /** Runs the check described by {@code request}. */
    public static CheckReport check(CheckRequest request) {
        long started = System.nanoTime();
        List<String> notes = new ArrayList<>();

        // 1. read all inputs (no class is ever loaded)
        ProgramIndex program = ProgramScanner.scan(request.programJars(), request.classpathOrder(),
                request.runtimeVersion());
        LibSide libA = scanLib(request.libAJars(), ClassOrigin.LIB_A, request);
        LibSide libB = scanLib(request.libBJars(), ClassOrigin.LIB_B, request);

        // 2. flatten each side into a logical repository; the JVM only sees class names
        JdkMetadata jdk = new JdkMetadata(request.jdkMetadata());
        List<String> collisions = new ArrayList<>();
        Repo runtimeA = Repo.merge("program ∪ lib-a", program.repo(), libA.repo(), collisions);
        Repo runtimeB = Repo.merge("program ∪ lib-b", program.repo(), libB.repo(), collisions);
        Resolver resolverA = new Resolver(runtimeA, jdk);
        Resolver resolverB = new Resolver(runtimeB, jdk);

        // 3. reachability: call-graph analysis from the entry point, or "everything is an entry point"
        Reachability reach = request.reachability() == ReachabilityScope.ALL
                ? ReachabilityAnalyzer.all(program)
                : ReachabilityAnalyzer.analyze(program, resolverB, request.entryClass(), request.entryMethod());

        Findings findings = new Findings();

        // 4. reference level checks
        ReferenceChecker referenceChecker = new ReferenceChecker(program, libA.repo(), libB.repo(),
                resolverA, resolverB, reach, findings);
        referenceChecker.checkAll();

        // 5. class shape checks
        HierarchyChecker hierarchyChecker = new HierarchyChecker(program, libA.repo(), libB.repo(),
                resolverA, resolverB, reach, findings);
        hierarchyChecker.checkAll();

        // 5b. subtype relations between library types that the program relies on (casts)
        new TypeRelationChecker(program, libA.repo(), libB.repo(), resolverA, resolverB, reach, findings)
                .checkAll();

        // 6. classpath hygiene: duplicated classes, sealed packages, nested JARs, scope notes
        List<ScanIssue> scanIssues = new ArrayList<>();
        scanIssues.addAll(program.issues());
        scanIssues.addAll(libA.issues());
        scanIssues.addAll(libB.issues());
        addScanIssues(findings, scanIssues);
        checkSealedPackages(libA, libB, findings);
        addScopeNotes(notes, findings, request, program, libA, libB, reach, referenceChecker, collisions, jdk);

        boolean hasErrors = findings.toIncompatibilities().stream()
                .anyMatch(item -> item.severity() == Severity.ERROR);
        Verdict verdict;
        if (program.repo().isEmpty()) {
            verdict = Verdict.UNKNOWN;
            notes.add("program 中没有解析到任何 class 文件，无法给出结论。");
        } else {
            verdict = hasErrors ? Verdict.INCOMPATIBLE : Verdict.COMPATIBLE;
        }

        long durationMillis = (System.nanoTime() - started) / 1_000_000L;
        return new CheckReport.Builder()
                .reachability(request.reachability())
                .verdict(verdict)
                .items(findings.toIncompatibilities())
                .notes(notes)
                .compatibleReferences(findings.compatibleReferences())
                .checkedReferences(findings.checkedReferences())
                .externalReferences(findings.externalReferences())
                .abstractChecks(hierarchyChecker.abstractChecks())
                .durationMillis(durationMillis)
                .build();
    }

    private record LibSide(Repo repo, JarScanner.ScanReport report, List<ScanIssue> issues) {
    }

    private static LibSide scanLib(List<java.nio.file.Path> jars, String side, CheckRequest request) {
        RepoBuilder builder = new RepoBuilder(side, request.classpathOrder());
        JarScanner.Request scanRequest = new JarScanner.Request(jars, side, request.runtimeVersion());
        List<ScanIssue> parseIssues = new ArrayList<>();
        JarScanner.ScanReport report = JarScanner.scan(scanRequest, (name, bytes, origin) -> {
            builder.jar(origin.jar());
            ClassInfo info;
            try {
                info = xland.ioutils.jarcompat.asm.ClassInfoReader.read(bytes, origin,
                        xland.ioutils.jarcompat.asm.ClassInfoReader.HEADER);
            } catch (IllegalArgumentException | ArrayIndexOutOfBoundsException e) {
                // unsupported class file version or a corrupted entry: skip the class, keep going
                parseIssues.add(ScanIssue.warn(IncompatibilityKind.NOTE,
                        origin.jar() + ": 无法解析 class 文件 " + origin.entry() + "（" + e.getMessage()
                                + "），该类被跳过；涉及它的引用无法判定。", origin.jar()));
                return;
            }
            builder.add(info);
        });
        List<ScanIssue> issues = new ArrayList<>(builder.issues());
        issues.addAll(parseIssues);
        issues.addAll(report.issues());
        return new LibSide(builder.build(), report, issues);
    }

    private static void addScanIssues(Findings findings, List<ScanIssue> issues) {
        Set<String> seen = new LinkedHashSet<>();
        for (ScanIssue issue : issues) {
            if (!seen.add(issue.groupKey())) {
                continue;
            }
            findings.item(issue.kind(), issue.severity(), issue.symbol())
                    .reason(issue.message())
                    .suggestion(issue.kind() == IncompatibilityKind.NESTED_JAR
                            ? "已知限制：不展开 fat JAR / nested JAR，其中的类不参与分析。"
                            : null)
                    .submit();
        }
    }

    /**
     * Sealing check: a package sealed on the A side that ends up split across several JARs on the B
     * side is a {@code SecurityException} risk (not a {@code LinkageError}).
     */
    private static void checkSealedPackages(LibSide libA, LibSide libB, Findings findings) {
        Set<String> sealedA = expandSealed(libA);
        Set<String> sealedB = expandSealed(libB);
        Map<String, Set<String>> jarsByPackageB = jarsByPackage(libB.repo());
        for (String pkg : sealedA) {
            Set<String> jars = jarsByPackageB.get(pkg);
            if (jars != null && jars.size() > 1) {
                findings.item(IncompatibilityKind.SEALED_PACKAGE_SPLIT, Severity.WARN, pkg)
                        .sideA(libA.repo().label(), "包 " + pkg + " 在 lib-a 侧被 sealed")
                        .sideB(libB.repo().label(), "包 " + pkg + " 分布在 " + jars)
                        .expected("java.lang.SecurityException",
                                "java.lang.SecurityException: sealing violation: package " + pkg + " is sealed")
                        .reason("A 侧包 " + pkg + " 是 sealed 的，B 侧同一个包被拆分到多个 JAR（" + jars
                                + "）。sealed 包要求所有类来自同一个 JAR，否则加载第二个 JAR 中的类时抛 SecurityException。"
                                + "注意：这属于 SecurityException 风险，不是 LinkageError。")
                        .suggestion("把 lib-b 中该包的类放回同一个 JAR，或去掉清单中的 Sealed 属性。")
                        .submit();
            }
        }
        for (String pkg : sealedB) {
            Set<String> jars = jarsByPackageB.get(pkg);
            if (jars != null && jars.size() > 1) {
                findings.item(IncompatibilityKind.SEALED_PACKAGE_SPLIT, Severity.WARN, pkg)
                        .sideB(libB.repo().label(), "包 " + pkg + " 在 lib-b 侧被 sealed 但分布在 " + jars)
                        .expected("java.lang.SecurityException",
                                "java.lang.SecurityException: sealing violation: package " + pkg + " is sealed")
                        .reason("B 侧清单把包 " + pkg + " 声明为 sealed，但该包的类分布在多个 JAR（" + jars
                                + "），运行时会抛 SecurityException。")
                        .suggestion("把该包的类合并到同一个 JAR，或去掉该包的 Sealed 属性。")
                        .submit();
            }
        }
    }

    private static Set<String> expandSealed(LibSide side) {
        Set<String> packages = new LinkedHashSet<>(side.report().sealedPackages().keySet());
        packages.remove("*");
        List<String> globallySealed = side.report().sealedPackages().get("*");
        if (globallySealed != null) {
            for (ClassInfo info : side.repo().classes()) {
                if (globallySealed.contains(info.originJar())) {
                    packages.add(info.packageName());
                }
            }
        }
        return packages;
    }

    private static Map<String, Set<String>> jarsByPackage(Repo repo) {
        Map<String, Set<String>> map = new LinkedHashMap<>();
        for (ClassInfo info : repo.classes()) {
            map.computeIfAbsent(info.packageName(), _ -> new LinkedHashSet<>()).add(info.originJar());
        }
        return map;
    }

    private static void addScopeNotes(List<String> notes, Findings findings, CheckRequest request,
                                      ProgramIndex program, LibSide libA, LibSide libB, Reachability reach,
                                      ReferenceChecker referenceChecker, List<String> collisions,
                                      JdkMetadata jdk) {
        notes.add("JarCompat 只做静态链接兼容性检查：不加载、不初始化、不执行任何被分析的类，"
                + "也不捕获真实运行期 LinkageError。");
        notes.add("未覆盖的动态链接机制：反射 (Class.forName/Method.invoke)、ServiceLoader、动态代理、"
                + "JNI、资源加载、运行期动态生成类（含字节码增强）。这些机制可能引入本报告未列出的不兼容。");
        notes.add("分析规模：program " + program.repo().size() + " 个类，lib-a " + libA.repo().size()
                + " 个类，lib-b " + libB.repo().size() + " 个类；按 classpath 顺序合并，"
                + "classpath-order=" + request.classpathOrder().name().toLowerCase().replace('_', '-') + "。");
        if (jdk.unavailableReason() != null) {
            notes.add("无法读取 jrt:/ JDK 元数据（" + jdk.unavailableReason()
                    + "），继承自 JDK 类型的成员解析可能不完整。");
        }
        if (reach.allReachable()) {
            notes.add("可达性：--reachability all（全量模式）——不分析调用图，program 的每个类/字段/方法都视为入口，"
                    + "因此任何位置上的失效引用都会按确定不兼容报告。它回答的是“program 里是否还存在无法链接的引用”，"
                    + "而不是“某条执行路径是否会崩”；死代码中的坏引用同样会被报出。");
            if (request.entryClass() != null) {
                notes.add("全量模式下忽略 --entry/--entry-method（所有 program 成员都已是入口）。");
            }
        } else if (!reach.entryKnown()) {
            notes.add("可达性：未确定入口点（" + reach.entryFailureReason() + "），所有引用按“可达性未知”处理，"
                    + "只会给出 WARN。可用 --entry/--entry-method 指定入口类，或用 --reachability all 做全量检查。");
            findings.item(IncompatibilityKind.REACHABILITY_UNKNOWN, Severity.WARN, null)
                    .reason("无法确定入口点：" + reach.entryFailureReason()
                            + "。所有引用按可达性未知处理，无法区分“确定不兼容”和“潜在不兼容”。")
                    .suggestion("用 --entry <类名> [--entry-method <方法名>] 指定入口，"
                            + "或确保 program JAR 的 MANIFEST.MF 中有 Main-Class。")
                    .submit();
        } else if (!reach.allReachable()) {
            notes.add("可达性：入口 " + reach.entryDescription() + "，静态可达方法 "
                    + reach.reachableMethods().size() + " 个。");
        }
        List<String> external = referenceChecker.externalClassList();
        if (!external.isEmpty()) {
            findings.item(IncompatibilityKind.EXTERNAL_DEPENDENCY_UNCHECKED, Severity.INFO, null)
                    .reason("有 " + external.size() + " 个被引用但未提供的类被当作外部黑盒跳过，"
                            + "例如：" + String.join(", ", external.subList(0, Math.min(10, external.size())))
                            + (external.size() > 10 ? " ..." : ""))
                    .suggestion("如需检查这些依赖，把对应 JAR 作为 --lib-a/--lib-b 传入。")
                    .submit();
        }
        for (String collision : collisions) {
            notes.add("program 与 lib 侧都定义了同名类：" + collision + "（按 classpath 顺序 program 优先）。");
        }
        if (jdk.enabled()) {
            notes.add("JDK 类型通过 jrt:/ 读取元数据（只读 class 头，不加载类）；其它未提供的依赖视为外部黑盒并已标注。");
        }
    }
}
