package xland.ioutils.jarcompat.api;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import xland.ioutils.jarcompat.engine.CompatibilityEngine;
import xland.ioutils.jarcompat.report.ReportRenderers;

/**
 * Public entry point of JarCompat.
 *
 * <p>JarCompat answers one question: <em>can {@code program-a.jar} — compiled against
 * {@code lib-a-*.jar} — be run, without recompilation, with {@code lib-a-*.jar} replaced by
 * {@code lib-b-*.jar}?</em> The analysis is purely static: no class of the analysed JARs is ever
 * loaded, linked, initialized or executed.</p>
 *
 * <p>Typical use:</p>
 * <pre>{@code
 * CheckReport report = JarCompat.check(JarCompat.request()
 *         .program(Path.of("program-a.jar"))
 *         .libA(Path.of("lib-a.jar"))
 *         .libB(Path.of("lib-b.jar"))
 *         .build());
 *
 * if (!report.isCompatible()) {
 *     System.out.println(report.toText());
 *     report.errors().forEach(e -> System.err.println(e.symbol() + " -> " + e.expectedError()));
 * }
 * }</pre>
 *
 * <p>All methods are stateless and thread safe; the checker keeps no global mutable state, so
 * concurrent {@link #check(CheckRequest)} invocations are independent of each other.</p>
 *
 * <p>The public API deliberately exposes no bytecode-analysis types (no ASM {@code ClassNode},
 * {@code MethodNode}, ...): input and output are plain domain objects.</p>
 */
public final class JarCompat {

    /** Tool name, also used in reports. */
    public static final String TOOL_NAME = "JarCompat";

    /** Tool version; mirrors the Gradle project version. */
    public static final String TOOL_VERSION = resolveVersion();

    private JarCompat() {
    }

    /** Starts a new {@link CheckRequest} builder. */
    public static CheckRequest.Builder request() {
        return new CheckRequest.Builder();
    }

    /**
     * Runs one compatibility check.
     *
     * @param request the check description
     * @return a structured, immutable report
     * @throws JarCompatException       if an input JAR cannot be read
     * @throws ClasspathConflictException if {@link ClasspathOrder#ERROR} is used and a class name is duplicated
     * @throws IllegalArgumentException if the request is incomplete
     */
    public static CheckReport check(CheckRequest request) {
        return CompatibilityEngine.check(request);
    }

    /**
     * Convenience overload for the common single-JAR-per-side case.
     *
     * @param program program JAR
     * @param libA    old library JARs, in classpath order
     * @param libB    new library JARs, in classpath order
     * @return a structured, immutable report
     */
    public static CheckReport check(Path program, List<Path> libA, List<Path> libB) {
        return check(request()
                .program(program)
                .libA(libA.toArray(Path[]::new))
                .libB(libB.toArray(Path[]::new))
                .build());
    }

    /** Renders a report in the requested format. */
    public static String render(CheckReport report, ReportFormat format) {
        return ReportRenderers.render(report, format);
    }

    /** Renders a report and writes it to {@code target} (UTF-8, parent directories are created). */
    public static void write(CheckReport report, ReportFormat format, Path target) {
        try {
            Path parent = target.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(target, render(report, format), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("cannot write report to " + target, e);
        }
    }

    private static String resolveVersion() {
        String v = JarCompat.class.getPackage() == null ? null
                : JarCompat.class.getPackage().getImplementationVersion();
        return v != null ? v : "0.1.0";
    }
}
