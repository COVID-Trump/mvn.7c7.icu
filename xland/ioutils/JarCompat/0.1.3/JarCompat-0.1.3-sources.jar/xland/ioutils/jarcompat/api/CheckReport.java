package xland.ioutils.jarcompat.api;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Structured result of one compatibility check: verdict, findings, statistics and notes.
 *
 * <p>Instances are immutable and can safely be shared between threads.</p>
 */
public final class CheckReport {

    private final ReachabilityScope reachability;
    private final Verdict verdict;
    private final List<Incompatibility> items;
    private final List<String> notes;
    private final int compatibleReferenceCount;
    private final int checkedReferenceCount;
    private final int externalReferenceCount;
    private final int abstractCheckCount;
    private final long durationMillis;

    private CheckReport(Builder b) {
        this.reachability = b.reachability;
        this.verdict = b.verdict;
        this.items = List.copyOf(b.items);
        this.notes = List.copyOf(b.notes);
        this.compatibleReferenceCount = b.compatibleReferenceCount;
        this.checkedReferenceCount = b.checkedReferenceCount;
        this.externalReferenceCount = b.externalReferenceCount;
        this.abstractCheckCount = b.abstractCheckCount;
        this.durationMillis = b.durationMillis;
    }

    /** Which reachability strategy produced this report. */
    public ReachabilityScope reachability() {
        return reachability;
    }

    /** Overall verdict. */
    public Verdict verdict() {
        return verdict;
    }

    /** {@code true} when no {@link Severity#ERROR} finding was produced. */
    public boolean isCompatible() {
        return verdict == Verdict.COMPATIBLE;
    }

    /** All findings, ordered by severity, kind and symbol. */
    public List<Incompatibility> items() {
        return Incompatibility.sorted(items);
    }

    /** Only the definite incompatibilities. */
    public List<Incompatibility> errors() {
        return items().stream().filter(i -> i.severity() == Severity.ERROR).collect(Collectors.toList());
    }

    /** Only the potential incompatibilities (and hygiene warnings). */
    public List<Incompatibility> warnings() {
        return items().stream().filter(i -> i.severity() == Severity.WARN).collect(Collectors.toList());
    }

    /** Number of definite incompatibilities (grouped findings). */
    public int errorCount() {
        return (int) items.stream().filter(i -> i.severity() == Severity.ERROR).count();
    }

    /** Number of potential incompatibilities (grouped findings). */
    public int warningCount() {
        return (int) items.stream().filter(i -> i.severity() == Severity.WARN).count();
    }

    /** Global notes: uncovered dynamic calls, skipped inputs, scope of the analysis, ... */
    public List<String> notes() {
        return notes;
    }

    /** References that were resolved on both sides without any problem. */
    public int compatibleReferenceCount() {
        return compatibleReferenceCount;
    }

    /** References that were actually checked (compatible + incompatible). */
    public int checkedReferenceCount() {
        return checkedReferenceCount;
    }

    /** References whose owner lies outside program/lib-a/lib-b (opaque black boxes). */
    public int externalReferenceCount() {
        return externalReferenceCount;
    }

    /** Number of program types examined by the abstract-method analysis. */
    public int abstractCheckCount() {
        return abstractCheckCount;
    }

    /** Wall clock duration of the check in milliseconds. */
    public long durationMillis() {
        return durationMillis;
    }

    /** Definite incompatibilities per lib-b JAR, biggest first (ties keep insertion order). */
    public Map<String, Integer> errorsByLibBJar() {
        return groupByJar(Severity.ERROR);
    }

    /** Potential incompatibilities per lib-b JAR, biggest first. */
    public Map<String, Integer> warningsByLibBJar() {
        return groupByJar(Severity.WARN);
    }

    private Map<String, Integer> groupByJar(Severity severity) {
        Map<String, Integer> raw = new LinkedHashMap<>();
        for (Incompatibility item : items) {
            if (item.severity() == severity && item.symbol() != null) {
                raw.merge(item.attributedJar(), 1, Integer::sum);
            }
        }
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(raw.entrySet());
        entries.sort((x, y) -> Integer.compare(y.getValue(), x.getValue()));
        Map<String, Integer> sorted = new LinkedHashMap<>();
        entries.forEach(e -> sorted.put(e.getKey(), e.getValue()));
        return Collections.unmodifiableMap(sorted);
    }

    /** Renders this report in the requested format. */
    public String render(ReportFormat format) {
        return JarCompat.render(this, format);
    }

    /** Renders this report as human readable text. */
    public String toText() {
        return JarCompat.render(this, ReportFormat.TEXT);
    }

    /** Renders this report as JSON. */
    public String toJson() {
        return JarCompat.render(this, ReportFormat.JSON);
    }

    @Override
    public String toString() {
        return "CheckReport[" + verdict + ", errors=" + errorCount() + ", warnings=" + warningCount() + "]";
    }

    /** Builder used by the engine. */
    public static final class Builder {
        private ReachabilityScope reachability = ReachabilityScope.ENTRY;
        private Verdict verdict = Verdict.UNKNOWN;
        private final List<Incompatibility> items = new ArrayList<>();
        private final List<String> notes = new ArrayList<>();
        private int compatibleReferenceCount;
        private int checkedReferenceCount;
        private int externalReferenceCount;
        private int abstractCheckCount;
        private long durationMillis;

        public Builder() {
        }

        public Builder reachability(ReachabilityScope reachability) {
            this.reachability = Objects.requireNonNull(reachability);
            return this;
        }

        public Builder verdict(Verdict verdict) {
            this.verdict = Objects.requireNonNull(verdict);
            return this;
        }

        public Builder item(Incompatibility item) {
            this.items.add(Objects.requireNonNull(item));
            return this;
        }

        public Builder items(List<Incompatibility> items) {
            this.items.addAll(items);
            return this;
        }

        public Builder note(String note) {
            if (note != null && !this.notes.contains(note)) {
                this.notes.add(note);
            }
            return this;
        }

        public Builder notes(List<String> notes) {
            notes.forEach(this::note);
            return this;
        }

        public Builder compatibleReferences(int count) {
            this.compatibleReferenceCount = count;
            return this;
        }

        public Builder checkedReferences(int count) {
            this.checkedReferenceCount = count;
            return this;
        }

        public Builder externalReferences(int count) {
            this.externalReferenceCount = count;
            return this;
        }

        public Builder abstractChecks(int count) {
            this.abstractCheckCount = count;
            return this;
        }

        public Builder durationMillis(long durationMillis) {
            this.durationMillis = durationMillis;
            return this;
        }

        public CheckReport build() {
            return new CheckReport(this);
        }
    }
}
