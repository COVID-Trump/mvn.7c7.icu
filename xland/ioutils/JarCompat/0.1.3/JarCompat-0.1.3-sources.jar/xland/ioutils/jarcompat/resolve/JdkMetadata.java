package xland.ioutils.jarcompat.resolve;

import java.io.IOException;
import java.net.URI;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import xland.ioutils.jarcompat.asm.ClassInfoReader;
import xland.ioutils.jarcompat.model.ClassInfo;
import xland.ioutils.jarcompat.model.ClassOrigin;
import xland.ioutils.jarcompat.model.Descriptors;

/**
 * Read-only metadata access to the running JDK image through {@code jrt:/}.
 *
 * <p>Only class file <em>headers</em> are read (no code, no debug info) and nothing is ever loaded
 * or initialized: this is exactly what is needed to resolve references that walk into JDK types,
 * e.g. a library method inherited from {@code java.util.AbstractList}. When the {@code jrt:}
 * file system is unavailable the lookup silently degrades to "unknown".</p>
 */
public final class JdkMetadata {

    private final boolean enabled;
    private final Map<String, Optional<ClassInfo>> cache = new ConcurrentHashMap<>();
    private volatile FileSystem fileSystem;
    private volatile String unavailableReason;

    public JdkMetadata(boolean enabled) {
        this.enabled = enabled;
    }

    /** Whether {@code jrt:/} metadata may be consulted. */
    public boolean enabled() {
        return enabled;
    }

    /** Whether the JDK image could be opened; {@code null} while everything is fine. */
    public String unavailableReason() {
        return unavailableReason;
    }

    /** Finds a JDK class by internal name, or returns {@code null}. */
    public ClassInfo find(String internalName) {
        if (!enabled) {
            return null;
        }
        return cache.computeIfAbsent(internalName, this::load).orElse(null);
    }

    private Optional<ClassInfo> load(String internalName) {
        FileSystem fs = fileSystem();
        if (fs == null) {
            return Optional.empty();
        }
        String packageName = Descriptors.packageOf(internalName).replace('/', '.');
        String packagePath = Descriptors.packageOf(internalName);
        String relative = Descriptors.simpleName(internalName) + ".class";
        try {
            Path packageDir = fs.getPath("/packages", packageName);
            if (!Files.isDirectory(packageDir)) {
                return Optional.empty();
            }
            try (DirectoryStream<Path> modules = Files.newDirectoryStream(packageDir)) {
                for (Path module : modules) {
                    // /packages/<pkg>/<module> is a link to /modules/<module>
                    Path classFile = module.resolve(packagePath).resolve(relative);
                    if (Files.isRegularFile(classFile)) {
                        byte[] bytes = Files.readAllBytes(classFile);
                        ClassInfo info = ClassInfoReader.read(bytes,
                                ClassOrigin.jdk(module.getFileName().toString(), internalName + ".class"),
                                ClassInfoReader.HEADER);
                        return Optional.of(info);
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            markUnavailable(e);
        }
        return Optional.empty();
    }

    private FileSystem fileSystem() {
        FileSystem fs = fileSystem;
        if (fs != null) {
            return fs;
        }
        if (unavailableReason != null) {
            return null;
        }
        synchronized (this) {
            if (fileSystem != null) {
                return fileSystem;
            }
            if (unavailableReason != null) {
                return null;
            }
            try {
                fileSystem = FileSystems.getFileSystem(URI.create("jrt:/"));
                return fileSystem;
            } catch (RuntimeException e) {
                markUnavailable(e);
                return null;
            }
        }
    }

    private void markUnavailable(Exception e) {
        if (unavailableReason == null) {
            unavailableReason = e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }
}
