package xland.ioutils.jarcompat.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import xland.ioutils.jarcompat.api.ClasspathConflictException;
import xland.ioutils.jarcompat.api.ClasspathOrder;
import xland.ioutils.jarcompat.api.IncompatibilityKind;
import xland.ioutils.jarcompat.api.Severity;

/**
 * Accumulates classes into a {@link Repo} while applying the {@link ClasspathOrder} policy to
 * duplicate class names (same class name defined by several JARs of one side).
 */
public final class RepoBuilder {

    private final String label;
    private final ClasspathOrder order;
    private final List<ScanIssue> issues = new ArrayList<>();
    private final List<String> jars = new ArrayList<>();
    private final Map<String, ClassInfo> classes = new LinkedHashMap<>();

    public RepoBuilder(String label, ClasspathOrder order) {
        this.label = label;
        this.order = order;
    }

    /** Registers a JAR that participates in this repository (kept in classpath order). */
    public void jar(String jarName) {
        if (!jars.contains(jarName)) {
            jars.add(jarName);
        }
    }

    /** Adds a class, honouring the duplicate-class policy. */
    public void add(ClassInfo info) {
        ClassInfo existing = classes.get(info.name());
        if (existing == null) {
            classes.put(info.name(), info);
            return;
        }
        String message = "重复类名 " + info.dottedName() + "："
                + existing.originJar() + " 与 " + info.originJar() + " 都定义了该类；";
        switch (order) {
            case FIRST_WINS -> {
                message += "按 classpath-order=first-wins 采用 " + existing.originJar() + "，忽略 " + info.originJar() + "。";
                issues.add(ScanIssue.warn(IncompatibilityKind.DUPLICATE_CLASS, message, existing.originJar()));
            }
            case STRICT -> {
                message += "按 classpath-order=strict 采用 " + existing.originJar() + "，忽略 " + info.originJar()
                        + "（视为 ERROR）。";
                issues.add(ScanIssue.error(IncompatibilityKind.DUPLICATE_CLASS, message, existing.originJar()));
            }
            case ERROR -> throw new ClasspathConflictException(info.name(),
                    existing.originJar(), info.originJar());
        }
    }

    /** Registers an issue discovered while scanning (nested JAR, multi-release override, ...). */
    public void issue(ScanIssue issue) {
        issues.add(issue);
    }

    public void issue(Severity severity, IncompatibilityKind kind, String message, String jar) {
        issues.add(new ScanIssue(severity, kind, message, null, jar));
    }

    public List<ScanIssue> issues() {
        return issues;
    }

    public Repo build() {
        return new Repo(label, classes, jars);
    }
}
