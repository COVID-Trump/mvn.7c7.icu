package xland.ioutils.jarcompat.api;

import java.util.Objects;

/**
 * One side (lib-a or lib-b) of a symbol: which JAR provides it and how it is declared there.
 */
public final class Side {
    private final boolean present;
    private final String jar;
    private final String declaration;

    private Side(boolean present, String jar, String declaration) {
        this.present = present;
        this.jar = jar;
        this.declaration = declaration;
    }

    /** The symbol was not found on this side. */
    public static Side missing(String jar, String declaration) {
        return new Side(false, jar, declaration);
    }

    /** The symbol was found on this side. */
    public static Side found(String jar, String declaration) {
        return new Side(true, jar, declaration);
    }

    /** Whether the symbol exists on this side. */
    public boolean present() {
        return present;
    }

    /** File name of the JAR that declares the symbol, or the JAR that was searched. */
    public String jar() {
        return jar;
    }

    /** Human readable declaration, e.g. {@code public java.lang.String lib.a.Service.run(int)}. */
    public String declaration() {
        return declaration;
    }

    /** Renders as {@code lib-a-core.jar -> public java.lang.String lib.a.Service.run(int)}. */
    public String describe() {
        if (jar == null) {
            return declaration == null ? "(未知)" : declaration;
        }
        return jar + " -> " + (declaration == null ? "(未找到)" : declaration);
    }

    @Override
    public String toString() {
        return describe();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Side other)) {
            return false;
        }
        return present == other.present
                && Objects.equals(jar, other.jar)
                && Objects.equals(declaration, other.declaration);
    }

    @Override
    public int hashCode() {
        return Objects.hash(present, jar, declaration);
    }
}
