package xland.ioutils.jarcompat.api;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Immutable description of one compatibility check: which JARs to analyse, which entry point to use
 * and how to treat classpath corner cases.
 *
 * <p>Build instances with {@link JarCompat#request()} and pass them to {@link JarCompat#check(CheckRequest)}.</p>
 *
 * <pre>{@code
 * CheckRequest request = JarCompat.request()
 *         .program(Path.of("program-a.jar"))
 *         .libA(Path.of("lib-a-core.jar"), Path.of("lib-a-http.jar"))
 *         .libB(Path.of("lib-b-core.jar"), Path.of("lib-b-http.jar"))
 *         .build();
 * CheckReport report = JarCompat.check(request);
 * }</pre>
 */
public final class CheckRequest {

    private final List<Path> programJars;
    private final List<Path> libAJars;
    private final List<Path> libBJars;
    private final String entryClass;
    private final String entryMethod;
    private final ClasspathOrder classpathOrder;
    private final int runtimeVersion;
    private final boolean jdkMetadata;
    private final ReachabilityScope reachability;

    private CheckRequest(Builder b) {
        this.programJars = List.copyOf(b.programJars);
        this.libAJars = List.copyOf(b.libAJars);
        this.libBJars = List.copyOf(b.libBJars);
        this.entryClass = b.entryClass;
        this.entryMethod = b.entryMethod;
        this.classpathOrder = b.classpathOrder;
        this.runtimeVersion = b.runtimeVersion;
        this.jdkMetadata = b.jdkMetadata;
        this.reachability = b.reachability;
    }

    /** Program JARs, in classpath order. */
    public List<Path> programJars() {
        return programJars;
    }

    /** Old library JARs, in classpath order. */
    public List<Path> libAJars() {
        return libAJars;
    }

    /** New library JARs, in classpath order. */
    public List<Path> libBJars() {
        return libBJars;
    }

    /** Explicit entry class (dotted or slashed name), or {@code null} to use {@code Main-Class}. */
    public String entryClass() {
        return entryClass;
    }

    /** Entry method name, {@code main} by default. */
    public String entryMethod() {
        return entryMethod;
    }

    /** Duplicate class policy. */
    public ClasspathOrder classpathOrder() {
        return classpathOrder;
    }

    /** Java runtime version used for multi-release JAR selection (25 by default). */
    public int runtimeVersion() {
        return runtimeVersion;
    }

    /** Whether {@code jrt:/} JDK metadata may be consulted (always safe: no class is loaded). */
    public boolean jdkMetadata() {
        return jdkMetadata;
    }

    /**
     * How reachability is decided: {@link ReachabilityScope#ENTRY} (default) analyses the call graph
     * from the entry point, {@link ReachabilityScope#ALL} treats every program member as an entry
     * point and skips the analysis entirely.
     */
    public ReachabilityScope reachability() {
        return reachability;
    }

    /** Returns a copy of this request with an explicit entry point. */
    public CheckRequest withEntry(String className, String methodName) {
        return new Builder()
                .program(programJars.toArray(Path[]::new))
                .libA(libAJars.toArray(Path[]::new))
                .libB(libBJars.toArray(Path[]::new))
                .entry(className)
                .entryMethod(methodName)
                .classpathOrder(classpathOrder)
                .runtimeVersion(runtimeVersion)
                .jdkMetadata(jdkMetadata)
                .reachability(reachability)
                .build();
    }

    @Override
    public String toString() {
        return "CheckRequest[program=" + programJars + ", libA=" + libAJars + ", libB=" + libBJars + "]";
    }

    /** Fluent builder; see {@link JarCompat#request()}. */
    public static final class Builder {
        private final List<Path> programJars = new ArrayList<>();
        private final List<Path> libAJars = new ArrayList<>();
        private final List<Path> libBJars = new ArrayList<>();
        private String entryClass;
        private String entryMethod = "main";
        private ClasspathOrder classpathOrder = ClasspathOrder.FIRST_WINS;
        private int runtimeVersion = Runtime.version().feature();
        private boolean jdkMetadata = true;
        private ReachabilityScope reachability = ReachabilityScope.ENTRY;

        public Builder() {
        }

        /** Adds one program JAR (repeatable; order defines classpath order). */
        public Builder program(Path jar) {
            programJars.add(Objects.requireNonNull(jar, "jar"));
            return this;
        }

        /** Adds program JARs (order defines classpath order). */
        public Builder program(Path... jars) {
            for (Path jar : jars) {
                program(jar);
            }
            return this;
        }

        /** Adds one lib-a JAR (repeatable; order defines classpath order). */
        public Builder libA(Path jar) {
            libAJars.add(Objects.requireNonNull(jar, "jar"));
            return this;
        }

        /** Adds lib-a JARs (order defines classpath order). */
        public Builder libA(Path... jars) {
            for (Path jar : jars) {
                libA(jar);
            }
            return this;
        }

        /** Adds one lib-b JAR (repeatable; order defines classpath order). */
        public Builder libB(Path jar) {
            libBJars.add(Objects.requireNonNull(jar, "jar"));
            return this;
        }

        /** Adds lib-b JARs (order defines classpath order). */
        public Builder libB(Path... jars) {
            for (Path jar : jars) {
                libB(jar);
            }
            return this;
        }

        /** Entry class (dotted or slashed); {@code null} means "read Main-Class from the program JAR". */
        public Builder entry(String className) {
            this.entryClass = className;
            return this;
        }

        /** Entry method name; {@code main} by default. */
        public Builder entryMethod(String methodName) {
            this.entryMethod = Objects.requireNonNull(methodName, "methodName");
            return this;
        }

        /** Duplicate class policy; {@link ClasspathOrder#FIRST_WINS} by default. */
        public Builder classpathOrder(ClasspathOrder order) {
            this.classpathOrder = Objects.requireNonNull(order, "order");
            return this;
        }

        /** Java runtime version used for multi-release JAR selection. */
        public Builder runtimeVersion(int featureVersion) {
            if (featureVersion < 1) {
                throw new IllegalArgumentException("runtimeVersion must be >= 1");
            }
            this.runtimeVersion = featureVersion;
            return this;
        }

        /** Whether {@code jrt:/} JDK metadata may be consulted. */
        public Builder jdkMetadata(boolean enabled) {
            this.jdkMetadata = enabled;
            return this;
        }

        /**
         * Selects the reachability strategy. {@link ReachabilityScope#ALL} skips the reachability
         * analysis and treats every program class, field and method as an entry point, so a broken
         * reference is reported as a definite problem wherever it sits. See
         * {@link ReachabilityScope} for when that is what you want.
         */
        public Builder reachability(ReachabilityScope scope) {
            this.reachability = Objects.requireNonNull(scope, "reachability");
            return this;
        }

        /** Shorthand for {@code reachability(ReachabilityScope.ALL)}. */
        public Builder allReachable() {
            return reachability(ReachabilityScope.ALL);
        }

        /** Shorthand for {@code reachability(ReachabilityScope.ENTRY)}. */
        public Builder entryReachable() {
            return reachability(ReachabilityScope.ENTRY);
        }

        /** Validates and freezes the request. */
        public CheckRequest build() {
            if (programJars.isEmpty()) {
                throw new IllegalArgumentException("at least one program JAR is required");
            }
            if (libAJars.isEmpty()) {
                throw new IllegalArgumentException("at least one lib-a JAR is required");
            }
            if (libBJars.isEmpty()) {
                throw new IllegalArgumentException("at least one lib-b JAR is required");
            }
            if (entryMethod == null || entryMethod.isBlank()) {
                throw new IllegalArgumentException("entry method name must not be blank");
            }
            return new CheckRequest(this);
        }

        /** Unmodifiable view of the currently configured program JARs. */
        public List<Path> programJars() {
            return Collections.unmodifiableList(programJars);
        }
    }
}
