package xland.ioutils.jarcompat.asm;

import xland.ioutils.jarcompat.api.Location;
import xland.ioutils.jarcompat.model.Descriptors;

/**
 * Where a symbolic reference occurs inside the program: JAR, class, method, source line.
 */
public record RefSite(String programJar, String programClass, String methodName,
                      String methodDescriptor, int line, String detail) {

    /**
     * Internal name of the program class containing the reference.
     */
    @Override
    public String programClass() {
        return programClass;
    }

    /**
     * 1-based source line, or {@code -1}.
     */
    @Override
    public int line() {
        return line;
    }

    /**
     * What the reference comes from, e.g. {@code "invokevirtual"} or {@code "method signature"}.
     */
    @Override
    public String detail() {
        return detail;
    }

    /**
     * Converts to the public, ASM-free API value object.
     */
    public Location toLocation() {
        return new Location(programJar, Descriptors.toDotted(programClass), methodName, methodDescriptor, line, detail);
    }

    @Override
    public String toString() {
        return toLocation().describe();
    }
}
