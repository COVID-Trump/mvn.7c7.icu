package xland.ioutils.jarcompat.api;

import java.util.*;

/**
 * A single finding of a compatibility check. Immutable; built through {@link Builder}.
 *
 * <p>An instance never exposes bytecode-library types: it carries only plain domain values
 * (severity, kind, symbol text, locations, declarations and human readable explanations).</p>
 */
public final class Incompatibility {

    private final Severity severity;
    private final IncompatibilityKind kind;
    private final String symbol;
    private final List<Location> locations;
    private final int occurrences;
    private final Side sideA;
    private final Side sideB;
    private final String reason;
    private final String suggestion;
    private final String expectedError;
    private final String expectedMessage;

    private Incompatibility(Builder b) {
        this.severity = b.severity;
        this.kind = b.kind;
        this.symbol = b.symbol;
        this.locations = List.copyOf(b.locations);
        this.occurrences = Math.max(b.occurrences, this.locations.size());
        this.sideA = b.sideA;
        this.sideB = b.sideB;
        this.reason = b.reason;
        this.suggestion = b.suggestion;
        this.expectedError = b.expectedError;
        this.expectedMessage = b.expectedMessage;
    }

    /** Severity of the finding. */
    public Severity severity() {
        return severity;
    }

    /** Classification of the finding. */
    public IncompatibilityKind kind() {
        return kind;
    }

    /** The referenced symbol as written in the program's constant pool, e.g. {@code lib/a/Service.run(I)Ljava/lang/String;}. */
    public String symbol() {
        return symbol;
    }

    /** Program locations that trigger the finding (possibly truncated, see {@link #occurrences()}). */
    public List<Location> locations() {
        return locations;
    }

    /** Total number of program sites that trigger the finding. */
    public int occurrences() {
        return occurrences;
    }

    /** The lib-a side of the symbol; may be {@code null} for classpath hygiene findings. */
    public Side sideA() {
        return sideA;
    }

    /** The lib-b side of the symbol; may be {@code null} for classpath hygiene findings. */
    public Side sideB() {
        return sideB;
    }

    /** Why this is a problem. */
    public String reason() {
        return reason;
    }

    /** What the user can do about it. */
    public String suggestion() {
        return suggestion;
    }

    /**
     * Fully qualified name of the {@link LinkageError} (or other {@link Throwable}) the JVM is
     * expected to throw, e.g. {@code java.lang.NoSuchMethodError}; {@code null} when the finding
     * does not correspond to a runtime failure.
     */
    public String expectedError() {
        return expectedError;
    }

    /**
     * The expected exception message, e.g. {@code java.lang.NoSuchMethodError: 'java.lang.String lib.a.Service.run(int)'}.
     */
    public String expectedMessage() {
        return expectedMessage;
    }

    /**
     * JAR of the lib-b side the finding is attributed to (used for the per-JAR statistics).
     */
    public String attributedJar() {
        if (sideB != null && sideB.jar() != null) {
            return sideB.jar();
        }
        if (sideA != null && sideA.jar() != null) {
            return sideA.jar();
        }
        return "(unknown)";
    }

    @Override
    public String toString() {
        return "[" + severity + "] " + kind + " " + symbol;
    }

    /** Fluent builder for {@link Incompatibility}. */
    public static final class Builder {
        private Severity severity = Severity.WARN;
        private IncompatibilityKind kind = IncompatibilityKind.NOTE;
        private String symbol;
        private final List<Location> locations = new ArrayList<>();
        private int occurrences;
        private Side sideA;
        private Side sideB;
        private String reason;
        private String suggestion;
        private String expectedError;
        private String expectedMessage;

        public Builder() {
        }

        public Builder severity(Severity severity) {
            this.severity = Objects.requireNonNull(severity);
            return this;
        }

        public Builder kind(IncompatibilityKind kind) {
            this.kind = Objects.requireNonNull(kind);
            return this;
        }

        public Builder symbol(String symbol) {
            this.symbol = symbol;
            return this;
        }

        public Builder location(Location location) {
            if (location != null && !locations.contains(location)) {
                locations.add(location);
            }
            return this;
        }

        public Builder locations(List<Location> locations) {
            locations.forEach(this::location);
            return this;
        }

        public Builder occurrences(int occurrences) {
            this.occurrences = occurrences;
            return this;
        }

        public Builder sideA(Side sideA) {
            this.sideA = sideA;
            return this;
        }

        public Builder sideB(Side sideB) {
            this.sideB = sideB;
            return this;
        }

        public Builder reason(String reason) {
            this.reason = reason;
            return this;
        }

        public Builder suggestion(String suggestion) {
            this.suggestion = suggestion;
            return this;
        }

        public Builder expectedError(String expectedError) {
            this.expectedError = expectedError;
            return this;
        }

        public Builder expectedMessage(String expectedMessage) {
            this.expectedMessage = expectedMessage;
            return this;
        }

        public Incompatibility build() {
            return new Incompatibility(this);
        }
    }

    /** Sorted, unmodifiable view helper used by the renderers. */
    public static List<Incompatibility> sorted(List<Incompatibility> items) {
        List<Incompatibility> copy = new ArrayList<>(items);
        copy.sort(Comparator.comparing((Incompatibility x) -> x.severity)
                .thenComparing(x -> x.kind)
                .thenComparing(x -> String.valueOf(x.symbol))
        );
        return Collections.unmodifiableList(copy);
    }
}
