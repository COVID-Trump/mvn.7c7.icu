module com.hixland.jarcompat {
    exports xland.ioutils.jarcompat.api;

    // Internal dependencies
    requires transitive org.objectweb.asm;
    requires transitive org.objectweb.asm.tree;
    requires transitive com.grack.nanojson;
}