@file:JvmName("StubClassGenKt")

package xland.gradle.forgeInitInjector

import org.gradle.api.DefaultTask
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.TaskAction
import org.gradle.work.DisableCachingByDefault
import org.objectweb.asm.ClassWriter
import org.objectweb.asm.Handle
import org.objectweb.asm.Label
import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes.*
import org.objectweb.asm.Type
import xland.gradle.forgeInitInjector.internal.ByteVec
import java.io.File
import java.security.MessageDigest

@DisableCachingByDefault
abstract class StubClassGenTask : DefaultTask() {
    @Internal lateinit var stubPackage : String
    @Internal lateinit var modId : String
    @Internal var mainEntrypoint : Handle? = null
    @Internal var clientEntrypoint : Handle? = null
    @Internal var serverEntrypoint: Handle? = null
    @Internal val neoFlags: MutableSet<NeoForgeFlag> = mutableSetOf()
    var supportNeo: Boolean
        //@Deprecated("NeoForge Flag provides a more comprehensive toggle", ReplaceWith("neoFlags.isNotEmpty()"))
        @Internal
        get() = neoFlags.isNotEmpty()
        @Deprecated("NeoForge Flag provides a more comprehensive toggle, so process it directly")
        set(value) {
        	neoFlags.clear()
        	if (value)
        		neoFlags.addAll(NeoForgeFlag.entries)
        }
    fun neoFlag(vararg flags: NeoForgeFlag) { neoFlags.addAll(flags) }
    fun neoFlag(vararg flags: String) { flags.forEach { name -> neoFlags.add(NeoForgeFlag.valueOf(name.uppercase())) } }
    @Internal var supportLegacyForgeLifecycle: Boolean = false
    fun setMainEntrypoint(owner: String, name: String = "init", desc: String = "()V", handle: Int = H_INVOKESTATIC, isInterface : Boolean = false) {
        mainEntrypoint = Handle(handle, owner, name, desc, isInterface)
    }
    fun setClientEntrypoint(owner: String, name: String = "init", desc: String = "()V", handle: Int = H_INVOKESTATIC, isInterface : Boolean = false) {
        clientEntrypoint = Handle(handle, owner, name, desc, isInterface)
    }
    fun setServerEntrypoint(owner: String, name: String = "init", desc: String = "()V", handle: Int = H_INVOKESTATIC, isInterface : Boolean = false) {
        serverEntrypoint = Handle(handle, owner, name, desc, isInterface)
    }
    @Internal
    val subscriptions = ModSubscriptions { modId }

    private val rootOutputDir get() =
        project.layout.buildDirectory.dir("forgeInitInjector")
    private val outputDir get() = rootOutputDir.get().file("classes").asFile
    private val checksumDir get() = rootOutputDir.get().file("checksums").asFile

    init {
        this.outputs.upToDateWhen { isUpToDate() }
    }

    @TaskAction
    fun generate() {
        outputDir.deleteRecursively()
        checksumDir.deleteRecursively()
        outputDir.resolve(stubPackage).mkdirs()
        checksumDir.mkdirs()
        val checksumEngine = ByteVec()
        val nameItr = nameItr()
        val newClassAcceptor = NewClassAcceptor { s, classWriter ->
            val b = classWriter.toByteArray()
            outputDir.resolve("${s}.class").writeBytes(b)
            synchronized(checksumEngine) {
                checksumEngine.putUtf8(s)
                checksumEngine.putBytes(b.sha256)
            }
        }

        val modClassName = "$stubPackage/${nameItr.next()}"
        val cw = ClassWriter(3)
        cw.visit(V1_8, ACC_PUBLIC + ACC_SUPER, modClassName, null,
                    "java/lang/Object", null)
        cw.visitSource("generated", null)
        cw.visitAnnotation("Lnet/minecraftforge/fml/common/Mod;", true).run {
            visit("value", modId)
            visitEnd()
        }
        if (supportNeo)
        	cw.visitAnnotation("Lnet/neoforged/fml/common/Mod;", true).run {
            	visit("value", modId)
            	visitEnd()
        	}
        cw.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null).run {
            visitCode()
            visitLineNumber(100, Label().apply(::visitLabel))
            visitVarInsn(ALOAD, 0)
            visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false)
            visitLineNumber(101, Label().apply(::visitLabel))
            subscriptions.insertModConstructor(modClassName, cw, this, newClassAcceptor, nameItr)
            visitInsn(RETURN)
            visitMaxs(-1, -1)
            visitEnd()
        }
        newClassAcceptor.accept(modClassName, cw)

        listOf(
            PresetEntrypointContainer("net/minecraftforge/fml/event/lifecycle/FMLCommonSetupEvent", 0),
            PresetEntrypointContainer("net/minecraftforge/fml/event/lifecycle/FMLClientSetupEvent", -1),
            PresetEntrypointContainer("net/minecraftforge/fml/event/lifecycle/FMLDedicatedServerSetupEvent", 1),
        ).let { containers ->
        	if (!supportNeo) containers
        	else containers + listOf(
        		PresetEntrypointContainer("net/neoforged/fml/event/lifecycle/FMLCommonSetupEvent", 0, "neoforged"),
            	PresetEntrypointContainer("net/neoforged/fml/event/lifecycle/FMLClientSetupEvent", -1, "neoforged"),
            	PresetEntrypointContainer("net/neoforged/fml/event/lifecycle/FMLDedicatedServerSetupEvent", 1, "neoforged"),
        	)
        }.forEach {
            it.writeClass(nameItr::next)?.let { p -> newClassAcceptor.accept(p.first, p.second) }
        }

        // Finalize
        checksumDir.resolve("header.dat").writeBytes(headerToBytes().data)
        checksumDir.resolve("checksum.dat").writeBytes(checksumEngine.data)
    }

    private inner class PresetEntrypointContainer(val lifecycleEvent: String,
                                            val dist: Int /*-1 client, 1 server, 0 normal*/,
                                            val pkg: String = "minecraftforge") {
        fun writeClass(nameGen: () -> String) : Pair<String, ClassWriter>? {
            val handle = entrypoint ?: return null
            val name = "$stubPackage/${nameGen()}"
            val cw = ClassWriter(3)
            cw.visit(V1_8, ACC_PUBLIC + ACC_SUPER, name, null,
                "java/lang/Object", arrayOf("java/lang/Runnable")
            )
            cw.visitSource("generated", null)
            if (pkg != "neoforged" || NeoForgeFlag.PRE_20_5 in neoFlags)
	            cw.visitAnnotation("Lnet/$pkg/fml/common/Mod\$EventBusSubscriber;", true).run {
	                visit("modid", modId)
	                visitEnum("bus", "Lnet/$pkg/fml/common/Mod\$EventBusSubscriber\$Bus;",
	                    "MOD")
	                if (dist != 0) {
	                    visitArray("value").run {
	                        visitEnum(null,
	                            "Lnet/$pkg/api/distmarker/Dist;",
	                            if (dist < 0) "CLIENT" else "SERVER")
	                        visitEnd()
	                    }
	                }
	                visitEnd()
	            }
	        if (pkg == "neoforged" && NeoForgeFlag.POST_20_5 in neoFlags)
                cw.visitAnnotation("Lnet/$pkg/fml/common/EventBusSubscriber;", true).run {
	                visit("modid", modId)
	                visitEnum("bus", "Lnet/$pkg/fml/common/EventBusSubscriber\$Bus;",
	                    "MOD")
	                if (dist != 0) {
	                    visitArray("value").run {
	                        visitEnum(null,
	                            "Lnet/$pkg/api/distmarker/Dist;",
	                            if (dist < 0) "CLIENT" else "SERVER")
	                        visitEnd()
	                    }
	                }
	                visitEnd()
	            }
            val methodNameItr = nameItr()

            cw.visitMethod(ACC_PUBLIC + ACC_STATIC, "ev$${methodNameItr.next()}",
                Type.getMethodDescriptor(Type.VOID_TYPE, Type.getObjectType(lifecycleEvent)),
                    null, null).run {
                subscribeEvent(this, pkg)
                visitCode()
                visitLineNumber(4000, Label().apply(::visitLabel))
                visitTypeInsn(NEW, name)
                visitInsn(DUP)
                visitMethodInsn(INVOKESPECIAL, name, "<init>", "()V", false)
                visitVarInsn(ASTORE, 1)

                val labelBeforeEnqueue = Label()
                val labelAfterEnqueue = Label()
                visitLineNumber(4001, labelBeforeEnqueue)
                visitLabel(labelBeforeEnqueue)
                visitVarInsn(ALOAD, 0)
                visitVarInsn(ALOAD, 1)
                visitMethodInsn(
                    INVOKEVIRTUAL, lifecycleEvent, "enqueueWork",
                    "(Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture;",
                    false
                )
                visitInsn(POP)
                visitInsn(RETURN)
                visitLabel(labelAfterEnqueue)

                // Before MinecraftForge 1.16.2-33.0.30, `::enqueueWork` did not exist.
                // Fallback: Run the work synchronously.
                if (supportLegacyForgeLifecycle) {
                    visitLineNumber(4020, labelAfterEnqueue)
                    visitTryCatchBlock(
                        labelBeforeEnqueue, labelAfterEnqueue, labelAfterEnqueue,
                        // Beware: symbolic invocation throws NSM Error, not NSM Exception
                        Type.getInternalName(NoSuchMethodError::class.java)
                    )
                    visitInsn(POP)
                    visitVarInsn(ALOAD, 1)
                    visitMethodInsn(INVOKEINTERFACE, "java/lang/Runnable", "run", "()V", true)
                    visitInsn(RETURN)
                }
                visitMaxs(-1, -1)
                visitEnd()
            }

            cw.visitMethod(0, "<init>", "()V", null, null).run {
                visitCode()
                visitLineNumber(200, Label().apply(::visitLabel))
                visitVarInsn(ALOAD, 0)
                visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false)
                visitInsn(RETURN)
                visitMaxs(-1, -1)
                visitEnd()
            }

            cw.visitMethod(ACC_PUBLIC, "run", "()V", null, null).run {
                visitCode()
                visitLineNumber(800, Label().apply(::visitLabel))
                handleTag(handle, this, name) { modId }
                visitInsn(RETURN)
                visitMaxs(-1, -1)
                visitEnd()
            }

            return name to cw
        }

        private val entrypoint : Handle? get() =
            if (dist < 0)
                clientEntrypoint
            else if (dist > 0)
                serverEntrypoint
            else mainEntrypoint
    }

    private fun isUpToDate() : Boolean {
        if (subscriptions.isEmpty()) return false   // predicates not serializable
        // verify up-to-date
        return checksumDir.resolve("header.dat").let root@ {
            if (!it.exists()) {
                return@root false
            } else {
                val vec = headerToBytes()
                if (vec.checkEqual(it.readBytes())) {
                    // metadata up-to-date
                    val vec2 = ByteVec(68u)
                    for (file in outputDir.walk()) {
                        if (file.isDirectory) continue
                        val f = file.relativeToOrNull(outputDir)?.name ?: return@root false
                        vec2.putUtf8(f)
                        vec2.putBytes(file.sha256)
                    }
                    return@root vec2.checkEqual(checksumDir.resolve("files.dat").run {
                        if (exists()) readBytes()
                        else ByteArray(0)
                    })
                }
                return@root false
            }
        }
    }

    private fun headerToBytes() : ByteVec {
        return ByteVec().apply {
            putShort(0x99F1)  // magic
            putByte(1)   // schema
            putUtf8(stubPackage)
            putUtf8(modId)
            putStringNullable(mainEntrypoint?.toString())
            putStringNullable(clientEntrypoint?.toString())
            putStringNullable(serverEntrypoint?.toString())
        }
    }
}

private val ByteArray.sha256 : ByteArray get() =
    MessageDigest.getInstance("SHA-256").digest(this)

private val File.sha256 : ByteArray get() {
    inputStream().buffered().use { bis ->
        MessageDigest.getInstance("SHA-256").run {
            val ba = ByteArray(8192)
            while (true) {
                val len = bis.read(ba)
                if (len < 0) break
                update(ba, 0, len)
            }
            return digest()
        }
    }
}

// len: 54
private val nameMap = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$".toCharArray()

fun nameItr() : Iterator<String> {
    return object : Iterator<String> {
        private var nm : ByteArray = ByteArray(0)

        override fun hasNext() = true

        override fun next(): String {
            val i = nm.lastIndex
            if (nm.isEmpty() || nm[i].toInt() == 53 /*nameMap.lastIndex, '$'*/)
                nm = ByteArray(i + 2)   // auto-fill zeros
            else
                nm[i] = (nm[i] + 1).toByte()
            return nm.map { nameMap[it.toInt()].code.toByte() }
                .toByteArray().let { String(it, Charsets.ISO_8859_1) }
        }

    }
}

@JvmSynthetic
internal fun handleTag(handle: Handle, mv: MethodVisitor,
                       className : String, modId: () -> String) {
    val mt = Type.getMethodType(handle.desc)
    mt.argumentTypes.let { argumentTypes ->
        if (argumentTypes.isNotEmpty()) {
            argumentTypes.forEach { typeEach ->
                when (typeEach.descriptor) {
                    "Ljava/lang/String;" -> mv.visitLdcInsn(modId()) /* String mod_id */
                    "Ljava/lang/Class;"  -> mv.visitLdcInsn(Type.getObjectType(className))
                    "Ljava/lang/Object;" -> mv.visitVarInsn(ALOAD, 0) /* this, when not static */
                    "Ljava/lang/invoke/MethodHandles\$Lookup;" ->
                        mv.visitMethodInsn(INVOKESTATIC, "java/lang/invoke/MethodHandles",
                            "lookup", "()Ljava/lang/invoke/MethodHandles\$Lookup;",
                            false)
                    else -> when (typeEach.sort) {
                        Type.ARRAY, Type.OBJECT -> mv.visitInsn(ACONST_NULL)
                        Type.BOOLEAN, Type.CHAR, Type.BYTE, Type.SHORT, Type.INT -> mv.visitInsn(ICONST_0)
                        Type.FLOAT -> mv.visitInsn(FCONST_0)
                        Type.LONG -> mv.visitInsn(LCONST_0)
                        Type.DOUBLE -> mv.visitInsn(DCONST_0)
                    }
                }
            }
        }
    }
    var op = when (handle.tag) {
        H_GETFIELD -> GETFIELD
        H_GETSTATIC -> GETSTATIC
        H_PUTFIELD -> PUTFIELD
        H_PUTSTATIC -> PUTSTATIC
        H_INVOKEVIRTUAL -> INVOKEVIRTUAL
        H_INVOKESTATIC -> INVOKESTATIC
        H_INVOKESPECIAL -> INVOKESPECIAL
        H_INVOKEINTERFACE -> INVOKEINTERFACE
        else -> -1 /* newInvokeSpecial */
    }
    if (op < 0) {
        mv.visitTypeInsn(NEW, handle.owner)
        // cancel DUP: we don't want the returned object
        op = INVOKESPECIAL
    }
    mv.visitMethodInsn(op, handle.owner, handle.name, handle.desc, handle.isInterface)

    mv.visitInsn(when (mt.returnType.size) {
        1 -> POP
        2 -> POP2
        else -> NOP
    })
}

// Stack: -1 object, max +1
fun registerStackTopToModBus(mv: MethodVisitor, pkg: String = "minecraftforge") {
    mv.run {
        visitMethodInsn(INVOKESTATIC, "net/minecraftforge/fml/javafmlmod/FMLJavaModLoadingContext", "get",
            "()Lnet/$pkg/fml/javafmlmod/FMLJavaModLoadingContext;", false)
        visitMethodInsn(INVOKEVIRTUAL, "net/minecraftforge/fml/javafmlmod/FMLJavaModLoadingContext", "getModEventBus",
            "()Lnet/${busPkg(pkg)}/api/IEventBus;", false)
        visitInsn(SWAP)
        visitMethodInsn(INVOKEINTERFACE, "net/${busPkg(pkg)}/api/IEventBus", "register",
            "(Ljava/lang/Object;)V", true)
    }
}

fun subscribeEvent(mv: MethodVisitor, pkg: String = "minecraftforge") {
    mv.visitAnnotation("Lnet/${busPkg(pkg)}/api/SubscribeEvent;", true)
        .visitEnd()
    if (pkg == "minecraftforge") {
        // In net.minecraftforge:eventbus:10.+, @SubscribeEvent is repackaged
        mv.visitAnnotation("Lnet/minecraftforge/eventbus/api/listener/SubscribeEvent;", true)
            .visitEnd()
    }
}

private fun busPkg(pkg: String) : String = when (pkg) {
    "neoforged" -> "neoforged/bus"
   	"minecraftforge" -> "minecraftforge/eventbus"
    else -> "$pkg/bus"
}
